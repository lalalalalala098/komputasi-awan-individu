/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type WasteCategory = 'PLASTIC' | 'PAPER' | 'ORGANIC' | 'METAL_GLASS' | 'SPECIAL_WASTE';

export interface WasteItem {
  id: string;
  name: string;
  category: WasteCategory;
  weightGrams: number;
  pointsValue: number;
  iconName: string;
}

export interface Inventory {
  PLASTIC: number; // in grams
  PAPER: number; // in grams
  ORGANIC: number; // in grams
  METAL_GLASS: number; // in grams
  SPECIAL_WASTE: number; // in grams
  ecoTokens: number;
}

export interface PetState {
  name: string;
  level: number;
  xp: number;
  maxXp: number;
  hunger: number; // 0 - 100
  happiness: number; // 0 - 100
  cleanliness: number; // 0 - 100
  evolutionStage: 'EGG' | 'BABY' | 'TEEN' | 'GUARDIAN';
}

export interface Neighbor {
  id: string;
  name: string;
  avatar: string;
  role: string; // e.g. "Pakar Kompos", "Pengepul Kreatif"
  distanceMeters: number;
  trashNeeds: {
    category: WasteCategory;
    amountGrams: number;
  };
  rewardOffer: {
    itemName: string;
    points: number;
  };
  greeting: string;
  address?: string;
}

export interface BarterListing {
  id: string;
  ownerId: string; // "player" or neighborId
  ownerName: string;
  ownerAvatar: string;
  offeredItem: string;
  offeredCategory: WasteCategory | 'REWARD_ITEM';
  offeredAmount: string; // e.g. "3 Kg" or "1 Botol Kaca"
  wantedItem: string;
  wantedCategory: WasteCategory | 'REWARD_ITEM';
  wantedAmount: string; // e.g. "2 Kg"
  status: 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  timePosted: string;
  description: string;
}

export interface MissionPartner {
  name: string;
  categoryName: string;
  avatar: string;
  cashPerKg: number; // Rupiah rate per Kg
}

export interface MissionDonor {
  name: string;
  avatar: string;
  weightGrams: number;
  cashEarned: number;
  tokensEarned: number;
  timestamp: string;
}

export interface CommunityMission {
  id: string;
  title: string;
  description: string;
  targetGrams: number;
  currentGrams: number;
  category: WasteCategory;
  rewardTokens: number;
  daysRemaining: number;
  partner?: MissionPartner;
  donors?: MissionDonor[];
}

export interface LeaderboardUser {
  id: string;
  name: string;
  avatar: string;
  totalRecycledGrams: number;
  ecoRank: number;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'pet' | 'neighbor';
  senderName: string;
  text: string;
  timestamp: string;
}

export interface WasteLog {
  id: string;
  category: WasteCategory;
  weightGrams: number;
  points: number;
  timestamp: string;
  photoUrl?: string;
  status: 'Tersimpan' | 'Terbarter' | 'Diolah' | 'Disetorkan';
}

export interface DonationPickup {
  id: string;
  missionId: string;
  missionTitle: string;
  category: WasteCategory;
  weightGrams: number;
  cashEarned: number;
  status: 'BELUM_DIKUMPULKAN' | 'SUDAH_DIKUMPULKAN';
  address: string;
  timestamp: string;
  paymentMethod: 'GoPay' | 'OVO';
  paymentPhone: string;
}

