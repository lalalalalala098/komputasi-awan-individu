/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Leaf, 
  Sparkles, 
  Scale, 
  ArrowLeftRight, 
  Award, 
  MessageSquare, 
  TrendingUp, 
  HelpCircle, 
  User, 
  Users,
  Info, 
  Coins,
  LogOut,
  Lock,
  Menu,
  X,
  Upload,
  MapPin
} from "lucide-react";

import { 
  PetState, 
  Inventory, 
  Neighbor, 
  BarterListing, 
  CommunityMission, 
  LeaderboardUser, 
  ChatMessage, 
  WasteCategory,
  WasteLog,
  DonationPickup
} from "./types";

import PetDashboard from "./components/PetDashboard";
import WasteLogger from "./components/WasteLogger";
import BarterHub from "./components/BarterHub";
import MissionsLeaderboard from "./components/MissionsLeaderboard";
import ChatAdvisor from "./components/ChatAdvisor";

// Initial Neighbors Mock Data
const INITIAL_NEIGHBORS: Neighbor[] = [
  {
    id: "bu-retno",
    name: "Bu Retno",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80",
    role: "Pakar Kompos Kampung",
    distanceMeters: 120,
    trashNeeds: { category: "PLASTIC", amountGrams: 1000 },
    rewardOffer: { itemName: "Pupuk Kompos Organik (1Kg)", points: 80 },
    greeting: "Sore nak! Ibu butuh botol plastik bersih untuk wadah semai cabai di kebun RT. Mari tukarkan sediaan botolmu dengan Kompos murni hasil pupuk cacing madu Ibu!",
    address: "Jl. Puti Anggrek No. 12, Kel. Bubutan, Surabaya"
  },
  {
    id: "kak-agus",
    name: "Kak Agus",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80",
    role: "Pengepul Kreatif RT",
    distanceMeters: 280,
    trashNeeds: { category: "PAPER", amountGrams: 1500 },
    rewardOffer: { itemName: "Super Eco-Seeds (x1)", points: 150 },
    greeting: "Halo dek! Kakak sedang merangkai kotak tisu dan anyaman tas dari kardus keras bekas. Barter kardusmu dengan bibit khusus penambah level Eco-Guardian?",
    address: "Jl. Puti Anggrek No. 45, Kel. Bubutan, Surabaya"
  },
  {
    id: "dek-susi",
    name: "Dek Susi",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
    role: "Aktivis Cilik Plastik",
    distanceMeters: 75,
    trashNeeds: { category: "METAL_GLASS", amountGrams: 1000 },
    rewardOffer: { itemName: "Eco-Tokens Ekstra", points: 120 },
    greeting: "Kak! Kaleng-kaleng soda alumunium bekas marjan bisa kita bawa ke bank sampah lho, daripada mencemari got warga. Sini barter sama aku, ku kasih Token!",
    address: "Jl. Puti Anggrek Gg. Hijau I No. 4, Kel. Bubutan, Surabaya"
  },
  {
    id: "pak-budi",
    name: "Pak Budi",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
    role: "Pensiunan Hijau",
    distanceMeters: 310,
    trashNeeds: { category: "SPECIAL_WASTE", amountGrams: 500 },
    rewardOffer: { itemName: "Minyak Saringan Lilin", points: 100 },
    greeting: "Minyak goreng bekas jelantah istrimu jangan dibuang sembarangan ke selokan yaw nak. Bapak saring untuk anyaman lilin RT, mari kumpul kemari bapak bayari.",
    address: "Jl. Puti Anggrek No. 8, Kel. Bubutan, Surabaya"
  }
];

// Initial Barter Bulletin Listings
const INITIAL_BARTER_LISTINGS: BarterListing[] = [
  {
    id: "swap-1",
    ownerId: "bu-retno",
    ownerName: "Bu Retno",
    ownerAvatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80",
    offeredItem: "Pupuk Kompos Organik",
    offeredCategory: "REWARD_ITEM",
    offeredAmount: "1 Kg",
    wantedItem: "Botol Plastik PET",
    wantedCategory: "PLASTIC",
    wantedAmount: "1.0 Kg",
    status: "ACTIVE",
    timePosted: "2 jam yang lalu",
    description: "Kompos subur organik siap tabur buat hiasan tamanmu, ditukar botol plastik mineral ukuran besar ya."
  },
  {
    id: "swap-2",
    ownerId: "kak-agus",
    ownerName: "Kak Agus",
    ownerAvatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80",
    offeredItem: "Super Eco-Seeds (Benih Khusus)",
    offeredCategory: "REWARD_ITEM",
    offeredAmount: "1 Pot",
    wantedItem: "Kardus Keras",
    wantedCategory: "PAPER",
    wantedAmount: "1.5 Kg",
    status: "ACTIVE",
    timePosted: "5 jam yang lalu",
    description: "Punya sisa dus kulkas atau kardus packing tebal? Tukar saja dengan benih tanaman bernutrisi klorofil buat pakan hewan setiamu!"
  }
];

// Initial Collaborative Campaigns
const INITIAL_MISSIONS: CommunityMission[] = [
  {
    id: "campaign-1",
    title: "Sirkulasi Plastik Kelurahan",
    description: "Kampanye swadaya warga menimbun botol plastik tipis bekas detergen & air mineral agar dilebur serentak ke pabrik sanitasi lingkungan.",
    targetGrams: 15000, // 15 Kg
    currentGrams: 10400, // 10.4 Kg
    category: "PLASTIC",
    rewardTokens: 250,
    daysRemaining: 3,
    partner: {
      name: "PT Daur Ulang Plastik Perkasa",
      categoryName: "Pabrik Industri Daur Ulang Plastik Kemasan",
      avatar: "https://images.unsplash.com/photo-1516214104703-d870798883c5?w=120&auto=format&fit=crop&q=80",
      cashPerKg: 4000
    },
    donors: [
      {
        name: "Pak Budi",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80",
        weightGrams: 2200,
        cashEarned: 8800,
        tokensEarned: 220,
        timestamp: "Kemarin"
      },
      {
        name: "Bu Retno",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80",
        weightGrams: 4500,
        cashEarned: 18000,
        tokensEarned: 450,
        timestamp: "2 hari yang lalu"
      },
      {
        name: "Kak Agus",
        avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80",
        weightGrams: 3700,
        cashEarned: 14800,
        tokensEarned: 370,
        timestamp: "3 hari yang lalu"
      }
    ]
  },
  {
    id: "campaign-2",
    title: "Kedaulatan Pupuk Kompos RT",
    description: "Kumpulkan bahan sisa makanan dapur organik basah untuk tong komposter gotong royong warga di pojok balai desa.",
    targetGrams: 20000, // 20 Kg
    currentGrams: 12100, // 12.1 Kg
    category: "ORGANIC",
    rewardTokens: 350,
    daysRemaining: 6,
    partner: {
      name: "CV Pupuk Kompos Makmur Gembira",
      categoryName: "Penyalur Organik & Pupuk Pertanian Kelurahan",
      avatar: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=120&auto=format&fit=crop&q=80",
      cashPerKg: 3000
    },
    donors: [
      {
        name: "Pak RT Budi",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80",
        weightGrams: 5100,
        cashEarned: 15300,
        tokensEarned: 510,
        timestamp: "Kemarin"
      },
      {
        name: "Siti Rahma",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80",
        weightGrams: 3500,
        cashEarned: 10500,
        tokensEarned: 350,
        timestamp: "2 hari yang lalu"
      },
      {
        name: "Pak Wahyu",
        avatar: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=120&auto=format&fit=crop&q=80",
        weightGrams: 3500,
        cashEarned: 10500,
        tokensEarned: 350,
        timestamp: "4 hari yang lalu"
      }
    ]
  }
];

// Initial Forum chat data
const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: "c1",
    sender: "neighbor",
    senderName: "Bu Retno",
    text: "Ada warga Kelurahan Hijau yang punya sisa wadah plastik telur puyuh? Mau disemai benih kangkung hidroponik nih.",
    timestamp: "10:15"
  },
  {
    id: "c2",
    sender: "neighbor",
    senderName: "Kak Agus",
    text: "Baru saja mengantarkan saringan minyak jelantah sisa gorengan Bu RT ke pengepul biodiesel, Eco-Guardian-ku langsung bertenaga dan level up!",
    timestamp: "10:30"
  },
  {
    id: "c3",
    sender: "neighbor",
    senderName: "Pak Budi",
    text: "Keren sekali gotong royongnya de' Agus. Kertas kardus bekas bapak menumpuk nih, ntar malam tolong diswap ya.",
    timestamp: "10:48"
  }
];

// Initial Leaderboard Users
const INITIAL_LEADERBOARD: LeaderboardUser[] = [
  { id: "bu-retno", name: "Bu Retno", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80", totalRecycledGrams: 18500, ecoRank: 1 },
  { id: "kak-agus", name: "Kak Agus", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&auto=format&fit=crop&q=80", totalRecycledGrams: 15000, ecoRank: 2 },
  { id: "player", name: "Saya (Eco-Ranger)", avatar: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=120&auto=format&fit=crop&q=80", totalRecycledGrams: 11200, ecoRank: 3 },
  { id: "dek-susi", name: "Dek Susi", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80", totalRecycledGrams: 9000, ecoRank: 4 },
  { id: "pak-budi", name: "Pak Budi", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80", totalRecycledGrams: 7500, ecoRank: 5 }
];

// Cute and playful plant avatar presets
const PLANT_AVATARS = [
  { url: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=150&auto=format&fit=crop&q=80", label: "Tunas Hijau 🌱" },
  { url: "https://images.unsplash.com/photo-1545241047-6083a3684587?w=150&auto=format&fit=crop&q=80", label: "Sukulen Imut 🌵" },
  { url: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=150&auto=format&fit=crop&q=80", label: "Daun Rimbun 🌿" },
  { url: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=150&auto=format&fit=crop&q=80", label: "Kaktus Ceria 🌲" }
];

/**
 * Formats a given Date to a beautiful Indonesian Date & Time string.
 */
function formatIndonesianDateTime(dateStrOrObj?: string | Date): string {
  const date = dateStrOrObj ? (typeof dateStrOrObj === 'string' ? new Date(dateStrOrObj) : dateStrOrObj) : new Date();
  if (isNaN(date.getTime())) {
    return "Baru saja";
  }
  const months = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  const day = date.getDate();
  const month = months[date.getMonth()];
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return `${day} ${month} ${year}, ${hours}:${minutes}`;
}

export default function App() {
  // Custom Player Profile State (saved in localStorage)
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem("eco_pet_profile");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { 
          name: parsed.name,
          avatar: parsed.avatar || "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=120&auto=format&fit=crop&q=80",
          neighborhood: parsed.neighborhood || "Jakarta",
          address: parsed.address || "Jl. Puti Anggrek No. 25, Kel. Bubutan, Surabaya",
          gender: parsed.gender || "Laki-laki",
          registered: true 
        };
      } catch (e) {}
    }
    return {
      name: "",
      avatar: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=120&auto=format&fit=crop&q=80",
      neighborhood: "Jakarta",
      address: "Jl. Puti Anggrek No. 25, Kel. Bubutan, Surabaya",
      gender: "Laki-laki",
      registered: false
    };
  });

  const [isProfileEditOpen, setIsProfileEditOpen] = useState(false);
  const [showResetConfirmationModal, setShowResetConfirmationModal] = useState(false);

  // Sidebar Menu hamburger state
  const [isOpenMenu, setIsOpenMenu] = useState(false);

  // Current tab state: 'dashboard' | 'pelihara' | 'catat' | 'barter' | 'event' | 'ai-chat'
  const [activeTab, setActiveTab] = useState<'dashboard' | 'pelihara' | 'catat' | 'barter' | 'event' | 'ai-chat'>(() => {
    const saved = localStorage.getItem("eco_pet_profile");
    return saved ? 'pelihara' : 'dashboard';
  });

  // Auth modal window state: 'login' | 'register' | null
  const [authModal, setAuthModal] = useState<'login' | 'register' | null>(null);

  // Field for simulation login input
  const [loginInputName, setLoginInputName] = useState("");
  const [loginInputRT, setLoginInputRT] = useState("Jakarta");
  const [loginInputPassword, setLoginInputPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Egg Hatching / Registration Steps
  const [isHatching, setIsHatching] = useState(false);
  const [hatchingProgress, setHatchingProgress] = useState(0);
  const [hatchingStatus, setHatchingStatus] = useState("Menyelaraskan bio-sintesis klorofil...");

  // Temporary signup fields
  const [regName, setRegName] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regAvatar, setRegAvatar] = useState("https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=120&auto=format&fit=crop&q=80");
  const [regGender, setRegGender] = useState<'Laki-laki' | 'Perempuan'>('Laki-laki');
  const [regNeighborhood, setRegNeighborhood] = useState("Jakarta");
  const [regPetName, setRegPetName] = useState("Sprouty");
  const [regError, setRegError] = useState("");

  // App core states loaded from LocalStorage
  const [pet, setPet] = useState<PetState>(() => {
    const saved = localStorage.getItem("eco_pet_pet");
    let loadedPet: PetState;
    if (saved) {
      try {
        loadedPet = JSON.parse(saved);
      } catch (e) {
        loadedPet = {
          name: "Sprouty",
          level: 1,
          xp: 250,
          maxXp: 1000,
          hunger: 65,
          cleanliness: 75,
          happiness: 55,
          evolutionStage: 'EGG'
        };
      }
    } else {
      loadedPet = {
        name: "Sprouty",
        level: 1,
        xp: 250,
        maxXp: 1000,
        hunger: 65,
        cleanliness: 75,
        happiness: 55,
        evolutionStage: 'EGG'
      };
    }

    // Auto-evolve if they are already higher level but desynchronized!
    let nextStage = loadedPet.evolutionStage;
    let nextName = loadedPet.name;

    if (loadedPet.level >= 5 && (nextStage === 'EGG' || nextStage === 'BABY' || nextStage === 'TEEN')) {
      nextStage = 'GUARDIAN';
      if (nextName === "Sprouty" || nextName === "Sprouty (Bayi)" || nextName === "Leafy Elf (Remaja)") {
        nextName = "Eco Titan Guardian (Pelindung)";
      }
    } else if (loadedPet.level >= 3 && (nextStage === 'EGG' || nextStage === 'BABY')) {
      nextStage = 'TEEN';
      if (nextName === "Sprouty" || nextName === "Sprouty (Bayi)") {
        nextName = "Leafy Elf (Remaja)";
      }
    } else if (loadedPet.level >= 2 && nextStage === 'EGG') {
      nextStage = 'BABY';
      if (nextName === "Sprouty") {
        nextName = "Sprouty (Bayi)";
      }
    }

    return {
      ...loadedPet,
      evolutionStage: nextStage,
      name: nextName
    };
  });

  const [inventory, setInventory] = useState<Inventory>(() => {
    const saved = localStorage.getItem("eco_pet_inventory");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      PLASTIC: 1500, // gr
      PAPER: 1000, // gr
      ORGANIC: 800, // gr
      METAL_GLASS: 500, // gr
      SPECIAL_WASTE: 300, // gr
      ecoTokens: 250 // virtual tokens currency
    };
  });

  const [neighbors, setNeighbors] = useState<Neighbor[]>(INITIAL_NEIGHBORS);
  
  const [barterListings, setBarterListings] = useState<BarterListing[]>(() => {
    const saved = localStorage.getItem("eco_pet_barterListings");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_BARTER_LISTINGS;
  });

  const [missions, setMissions] = useState<CommunityMission[]>(() => {
    const saved = localStorage.getItem("eco_pet_missions");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_MISSIONS;
  });
  
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem("eco_pet_chatMessages");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_CHAT_MESSAGES;
  });

  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>(() => {
    const saved = localStorage.getItem("eco_pet_leaderboard");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_LEADERBOARD;
  });

  const [wasteLogs, setWasteLogs] = useState<WasteLog[]>(() => {
    // Generate fresh dates relative to real-time to avoid "tgl dan jam nya masih salah"
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    const formattedToday1HourAgo = formatIndonesianDateTime(new Date(today.getTime() - 1 * 60 * 60 * 1000));
    const formattedToday4HoursAgo = formatIndonesianDateTime(new Date(today.getTime() - 4 * 60 * 60 * 1000));
    const formattedYesterday = formatIndonesianDateTime(new Date(yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate(), 10, 15));

    const saved = localStorage.getItem("eco_pet_wasteLogs");
    if (saved) {
      try { 
        const logs: WasteLog[] = JSON.parse(saved); 
        // Migrate legacy logs to use real dates as well
        return logs.map(log => {
          if (log.id === "log-1") return { ...log, timestamp: formattedYesterday };
          if (log.id === "log-2") return { ...log, timestamp: formattedToday4HoursAgo };
          if (log.id === "log-3") return { ...log, timestamp: formattedToday1HourAgo };
          return log;
        });
      } catch (e) {}
    }
    return [
      { id: "log-1", category: "PLASTIC", weightGrams: 1200, points: 120, timestamp: formattedYesterday, status: "Tersimpan", photoUrl: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=300&auto=format&fit=crop&q=80" },
      { id: "log-2", category: "ORGANIC", weightGrams: 800, points: 96, timestamp: formattedToday4HoursAgo, status: "Diolah", photoUrl: "https://images.unsplash.com/photo-1592417817098-8f3d6eb19675?w=300&auto=format&fit=crop&q=80" },
      { id: "log-3", category: "PAPER", weightGrams: 1500, points: 120, timestamp: formattedToday1HourAgo, status: "Terbarter", photoUrl: "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=300&auto=format&fit=crop&q=80" }
    ];
  });

  // App notification box (shown at top)
  const [appAlert, setAppAlert] = useState<{ message: string; type: 'success' | 'info' | 'warning' } | null>(() => {
    const saved = localStorage.getItem("eco_pet_profile");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          message: `Selamat datang kembali, Ranger ${parsed.name}! Lanjutkan memisahkan sampah nyata dan rawat pet setiamu!`,
          type: "success"
        };
      } catch (e) {}
    }
    return {
      message: "Selamat datang di Eco-Guardian! Silakan daftarkan akun wargamu untuk mengadopsi Eco-Guardian pertama!",
      type: "info"
    };
  });

  // Save states to local storage on changes
  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_pet", JSON.stringify(pet));
    }
  }, [pet, profile.registered]);

  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_inventory", JSON.stringify(inventory));
    }
  }, [inventory, profile.registered]);

  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_barterListings", JSON.stringify(barterListings));
    }
  }, [barterListings, profile.registered]);

  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_chatMessages", JSON.stringify(chatMessages));
    }
  }, [chatMessages, profile.registered]);

  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_leaderboard", JSON.stringify(leaderboard));
    }
  }, [leaderboard, profile.registered]);

  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_wasteLogs", JSON.stringify(wasteLogs));
    }
  }, [wasteLogs, profile.registered]);

  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_missions", JSON.stringify(missions));
    }
  }, [missions, profile.registered]);

  const [wallet, setWallet] = useState<{method: 'GoPay' | 'OVO' | null; phone: string}>(() => {
    const saved = localStorage.getItem("eco_pet_wallet");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && (parsed.method === 'GoPay' || parsed.method === 'OVO')) {
          return parsed;
        }
      } catch (e) {}
    }
    return { method: null, phone: "" };
  });

  const [pickups, setPickups] = useState<DonationPickup[]>(() => {
    const saved = localStorage.getItem("eco_pet_pickups");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [];
  });

  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_wallet", JSON.stringify(wallet));
    }
  }, [wallet, profile.registered]);

  useEffect(() => {
    if (profile.registered) {
      localStorage.setItem("eco_pet_pickups", JSON.stringify(pickups));
    }
  }, [pickups, profile.registered]);

  // Handle Account Signup and Egg Hatching simulation
  const handleRegister = (name: string, avatar: string, neighborhood: string, petNameValue: string, gender: 'Laki-laki' | 'Perempuan', passwordText?: string) => {
    setRegError("");
    if (!name.trim()) {
      setRegError("Harap masukkan nama lengkap atau nama panggilan anda!");
      return;
    }
    const finalPassword = passwordText !== undefined ? passwordText : regPassword;
    if (!finalPassword.trim()) {
      setRegError("Harap masukkan kata sandi (password) untuk mengamankan akun!");
      return;
    }
    if (!petNameValue.trim()) {
      setRegError("Harap beri nama yang unyu untuk Eco-Guardian telurmu!");
      return;
    }

    // Begin beautiful Hatching Animation Sequence
    setIsHatching(true);
    setHatchingProgress(10);
    setHatchingStatus("Menganalisis profil warga...");

    setTimeout(() => {
      setHatchingProgress(35);
      setHatchingStatus("Menyiapkan incubator klorofil...");
    }, 600);

    setTimeout(() => {
      setHatchingProgress(65);
      setHatchingStatus(`Menyalurkan nutrisi sirkulasi ke telur ${petNameValue}...`);
    }, 1300);

    setTimeout(() => {
      setHatchingProgress(90);
      setHatchingStatus(`Cangkang mulai retak! 🌱`);
    }, 2000);

    setTimeout(() => {
      setHatchingProgress(100);
      setHatchingStatus("Sprout berhasil menetas dengan megah!");
      
      const defaultAddress = "Jl. Puti Anggrek No. 25, Kel. Bubutan, Surabaya";
      const newProfile = { 
        name, 
        avatar, 
        neighborhood, 
        address: defaultAddress, 
        gender,
        password: finalPassword,
        registered: true 
      };
      
      // Multi-profile lists
      try {
        const existingList = JSON.parse(localStorage.getItem("eco_guardian_profile_list") || "[]") as string[];
        if (!existingList.includes(name)) {
          existingList.push(name);
          localStorage.setItem("eco_guardian_profile_list", JSON.stringify(existingList));
        }
        localStorage.setItem(`eco_guardian_profile_data_${name}`, JSON.stringify(newProfile));
        localStorage.setItem(`eco_guardian_pet_data_${name}`, JSON.stringify({
          name: petNameValue,
          level: 1,
          xp: 250,
          maxXp: 1000,
          hunger: 65,
          cleanliness: 75,
          happiness: 55,
          evolutionStage: 'EGG'
        }));
        localStorage.setItem(`eco_guardian_inventory_data_${name}`, JSON.stringify(inventory));
      } catch (e) {}

      localStorage.setItem("eco_pet_profile", JSON.stringify({ 
        name, 
        avatar, 
        neighborhood, 
        address: defaultAddress,
        gender,
        password: finalPassword
      }));
      setProfile(newProfile);

      setPet(prev => {
        const nextPet = { ...prev, name: petNameValue };
        localStorage.setItem("eco_pet_pet", JSON.stringify(nextPet));
        return nextPet;
      });

      // Update player profile in leaderboard
      setLeaderboard(prev => {
        const nextLeaderboard = prev.map(user => {
          if (user.id === "player") {
            return {
              ...user,
              name: `${name} (Saya)`,
              avatar: avatar
            };
          }
          return user;
        });
        localStorage.setItem("eco_pet_leaderboard", JSON.stringify(nextLeaderboard));
        return nextLeaderboard;
      });

      setIsHatching(false);
      setAppAlert({
        message: `🎉 Berhasil! Selamat datang di komunitas ${neighborhood}, Kak ${name}! Rawat ${petNameValue} dengan gizi sampah pilihan!`,
        type: "success"
      });
    }, 2700);
  };

  // Automatically fade out notification alerts after 6s
  useEffect(() => {
    if (appAlert) {
      const timer = setTimeout(() => {
        setAppAlert(null);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [appAlert]);

  // Helper handling level ups
  const gainXp = (amount: number, currentPet: PetState) => {
    let newXp = currentPet.xp + amount;
    let newLevel = currentPet.level;
    let newMaxXp = currentPet.maxXp;
    let leveledUp = false;

    while (newXp >= newMaxXp) {
      newXp = newXp - newMaxXp;
      newLevel += 1;
      // Formula for next level requirement is smoothly scaled
      newMaxXp = Math.round((newMaxXp * 1.18) / 50) * 50;
      leveledUp = true;
    }

    let nextStage = currentPet.evolutionStage;
    let nextName = currentPet.name;

    if (leveledUp) {
      // Check if they hit a milestone level for evolution
      let milestoneMsg = "";
      if (newLevel >= 5 && (nextStage === 'EGG' || nextStage === 'BABY' || nextStage === 'TEEN')) {
        nextStage = 'GUARDIAN';
        if (nextName === "Sprouty" || nextName === "Sprouty (Bayi)" || nextName === "Leafy Elf (Remaja)") {
          nextName = "Eco Titan Guardian (Pelindung)";
        }
        milestoneMsg = " 👑 Energi murni meluap! Pet kamu berhasil BER-EVOLUSI menjadi PELINDUNG UTAMA (GUARDIAN)!";
      } else if (newLevel >= 3 && (nextStage === 'EGG' || nextStage === 'BABY')) {
        nextStage = 'TEEN';
        if (nextName === "Sprouty" || nextName === "Sprouty (Bayi)") {
          nextName = "Leafy Elf (Remaja)";
        }
        milestoneMsg = " 🌿 Kekuatan alam berkumpul! Pet kamu berhasil BER-EVOLUSI menjadi REMAJA (TEEN)!";
      } else if (newLevel >= 2 && nextStage === 'EGG') {
        nextStage = 'BABY';
        if (nextName === "Sprouty") {
          nextName = "Sprouty (Bayi)";
        }
        milestoneMsg = " 🥚 Retakan besar muncul! Telurmu berhasil MENETAS secara otomatis menjadi BAYI (BABY)!";
      }

      setAppAlert({
        message: `🌟 LEVEL UP! ${nextName} berhasil naik ke LEVEL ${newLevel}!${milestoneMsg}`,
        type: "success"
      });
    }

    return { 
      ...currentPet, 
      xp: newXp, 
      level: newLevel, 
      maxXp: newMaxXp,
      evolutionStage: nextStage,
      name: nextName
    };
  };

  // --- ACTIONS ---

  // Feed pet
  const handlePetFeed = (feedType: 'ORGANIC_WASTE' | 'ECO_SEED') => {
    if (feedType === 'ORGANIC_WASTE') {
      if (inventory.ORGANIC < 500) {
        setAppAlert({
          message: "⚠️ Pakan Gagal: Stok sampah organik basah di Gudangmu kurang dari 500gr! Silakan catat sisa dapurmu terlebih dahulu.",
          type: "warning"
        });
        return;
      }

      setInventory(prev => ({ ...prev, ORGANIC: prev.ORGANIC - 500 }));
      setPet(prev => {
        const nextHunger = Math.min(100, prev.hunger + 30);
        const nextCleanliness = Math.max(0, prev.cleanliness - 10); // eating gets messy
        const withXp = gainXp(180, { ...prev, hunger: nextHunger, cleanliness: nextCleanliness });
        return withXp;
      });

      setAppAlert({
        message: `🍔 Berhasil memberi makan ${pet.name}! Kenyang bertambah, dan ia memperoleh +180 EXP dan -10 Kebersihan.`,
        type: "success"
      });
    } else {
      // Super Eco Seeds (consumes 150 tokens)
      if (inventory.ecoTokens < 150) {
        setAppAlert({
          message: "⚠️ Kebutuhan Gagal: Koin Eco-Tokens milikmu kurang dari 150! Lakukan barter sisa botol plastik dengan warga RT untuk meraup koin.",
          type: "warning"
        });
        return;
      }

      setInventory(prev => ({ ...prev, ecoTokens: prev.ecoTokens - 150 }));
      setPet(prev => {
        const nextHunger = Math.min(100, prev.hunger + 50);
        const nextClean = Math.min(100, prev.cleanliness + 15);
        const nextJoy = Math.min(100, prev.happiness + 20);
        const withXp = gainXp(400, { ...prev, hunger: nextHunger, cleanliness: nextClean, happiness: nextJoy });
        return withXp;
      });

      setAppAlert({
        message: `🌱 Benih Ajaib ditanam! ${pet.name} melahap pupuk klorofil subur, membakar +400 EXP dan meningkatkan semua status secara masif!`,
        type: "success"
      });
    }
  };

  // Wash pet
  const handlePetWash = () => {
    setPet(prev => {
      const nextClean = Math.min(100, prev.cleanliness + 40);
      return gainXp(60, { ...prev, cleanliness: nextClean });
    });

    setAppAlert({
      message: `🧼 Mandi Hujan Alami sukses! Tubuh ${pet.name} bersih berkilau bebas hama parasit. Ia memperoleh +40 Kebersihan dan +60 EXP.`,
      type: "success"
    });
  };

  // Play with pet
  const handlePetPlay = () => {
    setPet(prev => {
      const nextJoy = Math.min(100, prev.happiness + 35);
      return gainXp(120, { ...prev, happiness: nextJoy });
    });

    setAppAlert({
      message: `🪁 Gotong-royong bermain dengan anak-anak RT! Keceriaan ${pet.name} mendongkrak +35% Keceriaan dan memperoleh +120 EXP.`,
      type: "success"
    });
  };

  // Evolve pet
  const handlePetEvolve = () => {
    setPet(prev => {
      let nextStage = prev.evolutionStage;
      let nextName = prev.name;

      if (prev.evolutionStage === 'EGG') {
        nextStage = 'BABY';
        if (prev.name === "Sprouty") {
          nextName = "Sprouty (Bayi)";
        }
      } else if (prev.evolutionStage === 'BABY') {
        nextStage = 'TEEN';
        if (prev.name === "Sprouty (Bayi)") {
          nextName = "Leafy Elf (Remaja)";
        }
      } else if (prev.evolutionStage === 'TEEN') {
        nextStage = 'GUARDIAN';
        if (prev.name === "Leafy Elf (Remaja)") {
          nextName = "Eco Titan Guardian (Pelindung)";
        }
      }

      return {
        ...prev,
        evolutionStage: nextStage,
        name: nextName,
        hunger: Math.max(80, prev.hunger),
        cleanliness: Math.max(80, prev.cleanliness),
        happiness: Math.max(80, prev.happiness)
      };
    });

    setAppAlert({
      message: `🌟 HUJAN DAUN! Monster Eco-Guardian milikmu berhasil BEREVOLUSI secara megah!`,
      type: "success"
    });
  };

  // Log household waste
  const handleAddWaste = (category: WasteCategory, weightGrams: number, points: number, mode: 'STORE' | 'DEPOSIT', photoUrl?: string) => {
    // Generate beautiful Indonesian localized date-time formatted cleanly
    const localTimestamp = formatIndonesianDateTime(new Date());

    if (mode === 'DEPOSIT') {
      // Processed instantly! Give immediate tokens, and ALSO update the household inventory stocks so the stock gets updated and can be used for barter or donations!
      setInventory(prev => ({
        ...prev,
        ecoTokens: prev.ecoTokens + points,
        [category]: prev[category] + weightGrams
      }));

      const newLog: WasteLog = {
        id: `log-${Date.now()}`,
        category,
        weightGrams,
        points,
        timestamp: localTimestamp,
        status: 'Disetorkan',
        photoUrl
      };
      setWasteLogs(prev => [newLog, ...prev]);

      // Update player progress on leaderboard
      setLeaderboard(prev => 
        prev.map(user => {
          if (user.id === "player") {
            return {
              ...user,
              totalRecycledGrams: user.totalRecycledGrams + weightGrams
            };
          }
          return user;
        }).sort((a, b) => b.totalRecycledGrams - a.totalRecycledGrams)
      );

      // Increase pet progress
      setPet(prev => gainXp(Math.round(points / 2), prev));
    } else {
      // mode === 'STORE'
      // Stored in household warehouse. No immediate EcoTokens given, making the barter loop meaningful!
      setInventory(prev => ({
        ...prev,
        [category]: prev[category] + weightGrams
      }));

      const newLog: WasteLog = {
        id: `log-${Date.now()}`,
        category,
        weightGrams,
        points: 0, // Points are earned only upon barter
        timestamp: localTimestamp,
        status: 'Tersimpan',
        photoUrl
      };
      setWasteLogs(prev => [newLog, ...prev]);

      // Give a tiny pet interaction joy for sorting
      setPet(prev => {
        const nextClean = Math.min(100, prev.cleanliness + 8);
        return { ...prev, cleanliness: nextClean };
      });
    }
  };

  // Rename virtual pet
  const handleRenamePet = (newName: string) => {
    if (!newName.trim()) return;
    setPet(prev => ({
      ...prev,
      name: newName.trim()
    }));
    setAppAlert({
      message: `✨ Berhasil! Hubungan batin dipererat, nama pet kini resmi menjadi: ${newName.trim()}!`,
      type: "success"
    });
  };

  // Switch to next tab in sequence
  const handleNextTab = () => {
    // Sequence of core user tabs (excluding locked or utility tabs depending on registry)
    const list: ('pelihara' | 'barter' | 'event' | 'ai-chat')[] = [
      'pelihara', 'barter', 'event', 'ai-chat'
    ];
    const currentIndex = list.indexOf(activeTab as any);
    if (currentIndex !== -1) {
      const nextIndex = (currentIndex + 1) % list.length;
      setActiveTab(list[nextIndex]);
    } else {
      setActiveTab('pelihara');
    }
  };

  // Switch to previous tab in sequence
  const handlePrevTab = () => {
    const list: ('pelihara' | 'barter' | 'event' | 'ai-chat')[] = [
      'pelihara', 'barter', 'event', 'ai-chat'
    ];
    const currentIndex = list.indexOf(activeTab as any);
    if (currentIndex !== -1) {
      const prevIndex = (currentIndex - 1 + list.length) % list.length;
      setActiveTab(list[prevIndex]);
    } else {
      setActiveTab('pelihara');
    }
  };

  // Barter execution
  const handleExecuteBarter = (listingId: string) => {
    const listing = barterListings.find(l => l.id === listingId);
    if (!listing) return;

    // Deduct player's inventory as a barter price
    if (listing.wantedCategory !== 'REWARD_ITEM') {
      const cat = listing.wantedCategory as WasteCategory;
      let reqGrams = 500;
      const match = listing.wantedAmount.toLowerCase().match(/([\d.]+)\s*(kg|g|gr)/);
      if (match) {
        const amt = parseFloat(match[1]);
        const unit = match[2];
        reqGrams = unit.startsWith('k') ? amt * 1000 : amt;
      }

      setInventory(prev => ({
        ...prev,
        [cat]: prev[cat] - reqGrams
      }));
    }

    // Add reward / offered items into player inventory
    if (listing.offeredCategory === 'REWARD_ITEM') {
      // Add general reward items or tokens based on name
      if (listing.offeredItem.includes("Kompos")) {
        setInventory(prev => ({ ...prev, ORGANIC: prev.ORGANIC + 1000 }));
        setAppAlert({
          message: `🤝 Barter Sukses! Kamu menukar sampahmu dengan Bu Retno. Memperoleh 1 Kg Kompos Organik Jadi (dimasukkan ke Gudang Organik)!`,
          type: "success"
        });
      } else if (listing.offeredItem.includes("Seeds")) {
        setInventory(prev => ({ ...prev, ecoTokens: prev.ecoTokens + 150 })); // Seeds or tokens
        setAppAlert({
          message: `🤝 Barter Sukses! Kak Agus senang menukar kardusmu. Kamu memperoleh Super Eco-Seeds gratis senilai koin klorofil!`,
          type: "success"
        });
      } else {
        setInventory(prev => ({ ...prev, ecoTokens: prev.ecoTokens + 120 }));
        setAppAlert({
          message: `🤝 Barter Sukses dengan Dek Susi! Dapat imbalan +120 EcoTokens yang berkilau!`,
          type: "success"
        });
      }
    }

    // Mark listing as completed
    setBarterListings(prev => 
      prev.map(item => item.id === listingId ? { ...item, status: 'COMPLETED' } : item)
    );

    // Boost pet happiness after doing a neighbors transaction (social play effort)!
    setPet(prev => {
      const nextJoy = Math.min(100, prev.happiness + 25);
      return gainXp(150, { ...prev, happiness: nextJoy });
    });

    // Post mock conversational chat feed event!
    setChatMessages(prev => [
      ...prev,
      {
        id: `sys-${Date.now()}`,
        sender: "neighbor",
        senderName: listing.ownerName,
        text: `Terima kasih de' atas sumbangan ${listing.wantedItem}-nya! Sangat membantu kegiatan RT kita.`,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  // Post a new barter listing
  const handlePostListingByPlayer = (offered: WasteCategory, offeredAmtGrams: number, wanted: string, desc: string) => {
    // Deduct player's inventory
    setInventory(prev => ({
      ...prev,
      [offered]: prev[offered] - offeredAmtGrams
    }));

    const newListing: BarterListing = {
      id: `player-swap-${Date.now()}`,
      ownerId: "player",
      ownerName: `${profile.name} (Saya)`,
      ownerAvatar: profile.avatar,
      offeredItem: offered === 'PLASTIC' ? "Botol Plastik Bersih" : offered === 'PAPER' ? "Box Kardus Keras" : offered === 'ORGANIC' ? "Sisa Sayuran Organik" : offered === 'METAL_GLASS' ? "Botol Kaca Sirup" : "Saringan Jelantah",
      offeredCategory: offered,
      offeredAmount: `${(offeredAmtGrams / 1000).toFixed(1)} Kg`,
      wantedItem: wanted,
      wantedCategory: "REWARD_ITEM",
      wantedAmount: "Tukar Bebas",
      status: "ACTIVE",
      timePosted: "Baru saja",
      description: desc || "Mau barter demi pemenuhan nutrisi Eco-Guardian tersayang kita warga kampung."
    };

    setBarterListings(prev => [newListing, ...prev]);
    setAppAlert({
      message: `📢 Berhasil memajang sediaan ${(offeredAmtGrams/1000).toFixed(1)}kg sampahmu di Bulletin Kelurahan. Hubungi tetangga sekitarmu!`,
      type: "success"
    });

    // Sometime later, mock neighbor answers in chat
    setTimeout(() => {
      setChatMessages(prev => [
        ...prev,
        {
          id: `reply-${Date.now()}`,
          sender: "neighbor",
          senderName: "Dek Susi",
          text: "Wih, penawaran dari de' Ranger menarik sekali tuh. Aku mau ambil ntar sore pas lewat ya kak!",
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }, 4000);
  };

  // Send Chat message in RT Chatroom
  const handleSendChatMessage = (text: string) => {
    const userMsg: ChatMessage = {
      id: `chat-${Date.now()}`,
      sender: 'user',
      senderName: `${profile.name} (Saya)`,
      text: text,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);

    // Fast interactive mock reply from neighbors or other registered profiles
    setTimeout(() => {
      let senderName = "Pak Budi";
      
      try {
        const list = JSON.parse(localStorage.getItem("eco_guardian_profile_list") || "[]") as string[];
        const others = list.filter(n => n.trim().toLowerCase() !== (profile.name || "").trim().toLowerCase());
        if (others.length > 0) {
          // Speak as one of the other registered users on this browser
          senderName = others[Math.floor(Math.random() * others.length)];
        }
      } catch(e){}

      const neighborReplies = [
        "Mantap de'! Terus pilah sisa dapur di rumah ya.",
        "Kompak sekali kelurahan kita. Eco-Guardian-ku juga sudah siap melatih klorofil barunya bapak-bapak.",
        "Luar biasa, gotong royong warga kita nomor satu!",
        "Betul, jangan biarkan plastik mencemari lingkungan subur kita.",
        "Siap, aku juga baru kelar setor sampah koran bekas tadi pagi lho.",
        "Ayo kumpul besok di balai RT, kita timbang bareng-bareng sambil ngopi."
      ];
      const randomReply = neighborReplies[Math.floor(Math.random() * neighborReplies.length)];
      
      setChatMessages(prev => [
        ...prev,
        {
          id: `reply-${Date.now() + 1}`,
          sender: 'neighbor',
          senderName: senderName,
          text: randomReply,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }, 1800);
  };

  // Donate to active collaborative campaigns
  const handleDonateToMission = (missionId: string, donateGrams: number) => {
    const targetMission = missions.find(m => m.id === missionId);
    if (!targetMission) return;

    const isNowCompleted = (targetMission.currentGrams + donateGrams) >= targetMission.targetGrams;
    const isAlreadyCompleted = targetMission.currentGrams >= targetMission.targetGrams;

    // Deduct player warehouse & award tokens
    setInventory(prev => {
      const completionBonus = (isNowCompleted && !isAlreadyCompleted) ? targetMission.rewardTokens : 0;
      return {
        ...prev,
        [targetMission.category]: prev[targetMission.category] - donateGrams,
        ecoTokens: prev.ecoTokens + Math.round(donateGrams * 0.1) + completionBonus
      };
    });

    if (isNowCompleted && !isAlreadyCompleted) {
      setTimeout(() => {
        setAppAlert({
          message: `🎉 KAMPANYE SUKSES! Event "${targetMission.title}" dirampungkan warga serentak. Kamu menerima koin bonus +${targetMission.rewardTokens} Tokens!`,
          type: "success"
        });
      }, 500);
    }

    const userCash = Math.round((donateGrams / 1000) * (targetMission.partner?.cashPerKg || 3000));
    const userTokens = Math.round(donateGrams * 0.1);

    // Create pickup schedule record with BELUM_DIKUMPULKAN status
    const newPickup: DonationPickup = {
      id: `pickup-${Date.now()}`,
      missionId: missionId,
      missionTitle: targetMission.title,
      category: targetMission.category,
      weightGrams: donateGrams,
      cashEarned: userCash,
      status: 'BELUM_DIKUMPULKAN',
      address: profile.address || "Jl. Puti Anggrek No. 25, Kel. Bubutan, Surabaya",
      timestamp: formatIndonesianDateTime(new Date()),
      paymentMethod: wallet.method || 'GoPay',
      paymentPhone: wallet.phone || '08123456789'
    };
    setPickups(prev => [newPickup, ...prev]);

    // Update mission status
    setMissions(prev => 
      prev.map(m => {
        if (m.id === missionId) {
          const newCurrent = m.currentGrams + donateGrams;
          const newDonorRecord = {
            name: profile.name || "Warga Anonim (Saya)",
            avatar: profile.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80",
            weightGrams: donateGrams,
            cashEarned: userCash,
            tokensEarned: userTokens,
            timestamp: "Baru Saja"
          };

          const updatedDonors = m.donors ? [newDonorRecord, ...m.donors] : [newDonorRecord];

          return { ...m, currentGrams: newCurrent, donors: updatedDonors };
        }
        return m;
      })
    );

    // Update player leaderboard
    setLeaderboard(prev => 
      prev.map(user => {
        if (user.id === "player") {
          return {
            ...user,
            totalRecycledGrams: user.totalRecycledGrams + donateGrams
          };
        }
        return user;
      }).sort((a, b) => b.totalRecycledGrams - a.totalRecycledGrams)
    );

    setAppAlert({
      message: `❤️ Mulia sekali! Kamu mendonasikan ${(donateGrams/1000).toFixed(1)}kg ke kampanye warga. Jadwal penjemputan baru otomatis terbit!`,
      type: "success"
    });

    // Level up pet small xp
    setPet(prev => gainXp(Math.round(donateGrams * 0.15), prev));
  };

  // Add Chat msg for AI guru advisor panel
  const handleAddAiAdvisorMessage = (msg: ChatMessage) => {
    setChatMessages(prev => [...prev, msg]);
  };

  // Handle Login simulation loading/storing localStorage
  const handleLogin = (name: string, rt: string, passwordText?: string) => {
    setLoginError("");
    if (!name.trim()) {
      setLoginError("Harap masukkan nama panggilan atau nama lengkap anda!");
      return;
    }

    const finalPassword = passwordText !== undefined ? passwordText : loginInputPassword;
    if (!finalPassword.trim()) {
      setLoginError("Harap masukkan kata sandi (password) anda!");
      return;
    }

    // Try loading saved data for this specific citizen
    let savedProfile = null;
    let savedPet = null;
    let savedInventory = null;
    try {
      const pstr = localStorage.getItem(`eco_guardian_profile_data_${name}`);
      const tstr = localStorage.getItem(`eco_guardian_pet_data_${name}`);
      const istr = localStorage.getItem(`eco_guardian_inventory_data_${name}`);
      if (pstr) savedProfile = JSON.parse(pstr);
      if (tstr) savedPet = JSON.parse(tstr);
      if (istr) savedInventory = JSON.parse(istr);
    } catch(e){}

    // If account exists and has password, verify it
    if (savedProfile && savedProfile.password && savedProfile.password !== finalPassword) {
      setLoginError("Kata sandi (password) salah! Periksa kembali kata sandi anda.");
      return;
    }

    const newProfile = savedProfile ? {
      ...savedProfile,
      password: savedProfile.password || finalPassword
    } : {
      name: name,
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80",
      neighborhood: rt,
      password: finalPassword,
      registered: true
    };

    localStorage.setItem("eco_pet_profile", JSON.stringify({ 
      name: newProfile.name, 
      avatar: newProfile.avatar, 
      neighborhood: newProfile.neighborhood,
      password: newProfile.password
    }));
    setProfile(newProfile);
    setAuthModal(null);

    // Load or initialize pet
    const finalPet = savedPet || {
      name: "Sprouty",
      level: 1,
      xp: 250,
      maxXp: 1000,
      hunger: 65,
      cleanliness: 75,
      happiness: 55,
      evolutionStage: 'EGG' as const
    };
    setPet(finalPet);
    localStorage.setItem("eco_pet_pet", JSON.stringify(finalPet));

    // Load or initialize inventory
    const finalInv = savedInventory || {
      PLASTIC: 1500,
      PAPER: 1000,
      ORGANIC: 800,
      METAL_GLASS: 500,
      SPECIAL_WASTE: 300,
      ecoTokens: 250
    };
    setInventory(finalInv);
    localStorage.setItem("eco_pet_inventory", JSON.stringify(finalInv));

    // Append to list of all registered profiles
    try {
      const existingList = JSON.parse(localStorage.getItem("eco_guardian_profile_list") || "[]") as string[];
      if (!existingList.includes(name)) {
        existingList.push(name);
        localStorage.setItem("eco_guardian_profile_list", JSON.stringify(existingList));
      }
      localStorage.setItem(`eco_guardian_profile_data_${name}`, JSON.stringify(newProfile));
      localStorage.setItem(`eco_guardian_pet_data_${name}`, JSON.stringify(finalPet));
      localStorage.setItem(`eco_guardian_inventory_data_${name}`, JSON.stringify(finalInv));
    } catch(e){}

    setActiveTab('pelihara');
    setAppAlert({
      message: `🔑 Selamat beralih ke akun Ranger ${name}! Seluruh data rawatan Eco-Guardian Anda berhasil dimuat.`,
      type: "success"
    });
  };

  // Profile Update Form Fields
  const [editProfileName, setEditProfileName] = useState("");
  const [editProfileAddress, setEditProfileAddress] = useState("");
  const [editProfileNeighborhood, setEditProfileNeighborhood] = useState("");
  const [editProfileAvatar, setEditProfileAvatar] = useState("");
  const [editProfileGender, setEditProfileGender] = useState<'Laki-laki' | 'Perempuan'>('Laki-laki');
  const [editProfilePassword, setEditProfilePassword] = useState("");
  const [showEditPassword, setShowEditPassword] = useState(false);

  // Sync state with profile fields when modal opens
  useEffect(() => {
    if (isProfileEditOpen) {
      setEditProfileName(profile.name);
      setEditProfileAddress(profile.address || "Jl. Puti Anggrek No. 25, Kel. Bubutan, Surabaya");
      setEditProfileNeighborhood(profile.neighborhood || "Jakarta");
      setEditProfileAvatar(profile.avatar);
      setEditProfileGender((profile.gender as 'Laki-laki' | 'Perempuan') || 'Laki-laki');
      setEditProfilePassword(profile.password || "");
      setShowEditPassword(false);
    }
  }, [isProfileEditOpen, profile]);

  const handleUpdateProfile = () => {
    if (!editProfileName.trim()) {
      alert("Nama Lengkap tidak boleh kosong!");
      return;
    }
    const updated = {
      ...profile,
      name: editProfileName,
      address: editProfileAddress,
      neighborhood: editProfileNeighborhood,
      avatar: editProfileAvatar,
      gender: editProfileGender,
      password: editProfilePassword,
      registered: true
    };
    setProfile(updated);
    localStorage.setItem("eco_pet_profile", JSON.stringify({
      name: editProfileName,
      avatar: editProfileAvatar,
      neighborhood: editProfileNeighborhood,
      address: editProfileAddress,
      gender: editProfileGender,
      password: editProfilePassword
    }));

    // Save/update registries too so password handles and works in login
    try {
      const existingList = JSON.parse(localStorage.getItem("eco_guardian_profile_list") || "[]") as string[];
      // Remove old name if changed to avoid orphaned entries
      if (profile.name && profile.name !== editProfileName) {
        const index = existingList.indexOf(profile.name);
        if (index > -1) {
          existingList.splice(index, 1);
        }
      }
      if (!existingList.includes(editProfileName)) {
        existingList.push(editProfileName);
      }
      localStorage.setItem("eco_guardian_profile_list", JSON.stringify(existingList));
      localStorage.setItem(`eco_guardian_profile_data_${editProfileName}`, JSON.stringify(updated));
    } catch (e) {}

    // Update player name and avatar on leaderboard
    setLeaderboard(prev => {
      const next = prev.map(user => {
        if (user.id === "player") {
          return {
            ...user,
            name: `${editProfileName} (Saya)`,
            avatar: editProfileAvatar
          };
        }
        return user;
      });
      localStorage.setItem("eco_pet_leaderboard", JSON.stringify(next));
      return next;
    });

    setIsProfileEditOpen(false);
    setAppAlert({
      message: "💾 Profil & kata sandi (password) Anda sukses diperbarui!",
      type: "success"
    });
  };

  // Elegant Guest/Member Welcoming Dashboard Tab
  const LandingDashboard = () => {
    const [activeSlide, setActiveSlide] = useState(0);
    const slides = [
      {
        step: 1,
        title: "Pilah & Laporkan Sampah di Rumahmu 🥤",
        description: "Pilah sampah plastik, kardus bekas, atau kotoran organik dari dapur rumah aslimu. Catat berat kotornya di Eco-Guardian untuk peroleh status 'Tersimpan' atau 'Disetorkan' demi menutrisi pertumbuhan bayi monster milikmu.",
        icon: "🥤"
      },
      {
        step: 2,
        title: "Lakukan Barter Saling Silang Sesama Warga 🤝",
        description: "Punya sisa botol plastik berlebih tapi butuh bibit cabai Kak Agus atau kompos murni subur tanaman hias Bu Retno? Manfaatkan 'Bulletin Barter' untuk menukar sampah secara hemat emisi langsung di Kelurahan Hijau!",
        icon: "🤝"
      },
      {
        step: 3,
        title: "Selesaikan Misi Kampanye & Event Kelurahan 🏆",
        description: "Donasikan tumpukan kertas kardusmu untuk mendukung kedaulatan daur ulang rukun warga komunal. Lihat namamu melesat tinggi menjulang di puncak peringkat pahlawan Eco-Ranger terpopuler!",
        icon: "🏆"
      }
    ];

    const handleNextSlide = () => {
      setActiveSlide(prev => (prev + 1) % slides.length);
    };

    const handlePrevSlide = () => {
      setActiveSlide(prev => (prev - 1 + slides.length) % slides.length);
    };

    return (
      <div className="space-y-8" id="guest-landing-dashboard">
        {/* Banner Ajakan Cantik */}
        <div className="bg-gradient-to-br from-[#10B981] to-[#047857] rounded-[40px] p-6 sm:p-10 text-white relative overflow-hidden shadow-xl border-4 border-[#065F46]">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full transform translate-x-12 -translate-y-12 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full transform -translate-x-6 translate-y-6 pointer-events-none" />
          
          <div className="max-w-xl space-y-4 relative z-10">
            <h2 className="text-2xl sm:text-4xl font-black tracking-tight leading-tight">
              Ayo Beraksi, Rawat Bumi & Temukan Eco-Guardian-mu!
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 font-medium leading-relaxed">
              Selamat datang di Eco-Guardian! Ini adalah platform interaktif bertetangga untuk memecahkan penumpukan sampah nyata di lingkungan dengan konsep gamifikasi. 
              Pilah sampahmu di rumah aslimu, lakukan barter subur dengan tetangga, raup koin, dan kembangkan monster klorofil virtualmu dari telur hingga pelindung desa megah!
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              {!profile.registered ? (
                <button
                  onClick={() => setAuthModal('register')}
                  className="px-5 py-3 bg-white hover:bg-emerald-50 text-[#047857] text-xs font-black rounded-2xl transition-all shadow-md uppercase tracking-wider cursor-pointer"
                >
                  🌱 Tetaskan Eco-Guardian Baru (Gratis)
                </button>
              ) : (
                <button
                  onClick={() => setActiveTab('pelihara')}
                  className="px-5 py-3 bg-white hover:bg-emerald-50 text-[#047857] text-xs font-black rounded-2xl transition-all shadow-md uppercase tracking-wider cursor-pointer flex items-center gap-1.5"
                >
                  🎮 Rawat {pet.name} Saya
                </button>
              )}
              <a
                href="#cara-kerja"
                className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white border border-white/20 text-xs font-black rounded-2xl transition-all uppercase tracking-wider text-center"
              >
                Pelajari Cara Kerja 👇
              </a>
            </div>
          </div>
          <div className="absolute bottom-4 right-6 hidden lg:block text-9xl select-none animate-pulse">
            🌱
          </div>
        </div>

        {/* Lingkungan & Sampah Nyata Warga Metrics Section */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <h3 className="text-lg font-black text-[#1A3C34] tracking-tight">📊 Dashboard Sampah Rukun Warga</h3>
              <p className="text-xs text-emerald-800/80">Laporan kontribusi nyata pengumpulan & daur ulang sampah seluruh warga Kelurahan Hijau</p>
            </div>
            <div className="text-[10px] text-emerald-700 bg-white border border-[#E2F0E2] px-3 py-1.5 rounded-full font-mono font-bold">
              ● Diperbarui: Hari Ini, 11:35
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            
            <div className="bg-white p-4 rounded-3xl border-2 border-[#E2F0E2] shadow-sm relative overflow-hidden group hover:border-[#10B981] transition-all">
              <span className="text-2xl absolute right-3 bottom-2 opacity-15 select-none font-sans group-hover:scale-110 transition-transform">🥤</span>
              <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Botol Plastik</span>
              <span className="text-xl sm:text-2xl font-black text-[#1A3C34] block mt-1">26.2 Kg</span>
              <div className="mt-1.5 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="text-[9px] font-bold text-[#065F46]">+2.4 Kg minggu ini</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-3xl border-2 border-[#E2F0E2] shadow-sm relative overflow-hidden group hover:border-[#10B981] transition-all">
              <span className="text-2xl absolute right-3 bottom-2 opacity-15 select-none font-sans group-hover:scale-110 transition-transform">📦</span>
              <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Dus & Kardus</span>
              <span className="text-xl sm:text-2xl font-black text-[#1A3C34] block mt-1">18.4 Kg</span>
              <div className="mt-1.5 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="text-[9px] font-bold text-[#065F46]">+3.1 Kg minggu ini</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-3xl border-2 border-[#E2F0E2] shadow-sm relative overflow-hidden group hover:border-[#10B981] transition-all">
              <span className="text-2xl absolute right-3 bottom-2 opacity-15 select-none font-sans group-hover:scale-110 transition-transform">🥬</span>
              <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Kompos Organik</span>
              <span className="text-xl sm:text-2xl font-black text-[#1A3C34] block mt-1">32.0 Kg</span>
              <div className="mt-1.5 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="text-[9px] font-bold text-[#065F46]">Didistribusikan ke taman</span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-3xl border-2 border-[#E2F0E2] shadow-sm relative overflow-hidden group hover:border-[#10B981] transition-all">
              <span className="text-2xl absolute right-3 bottom-2 opacity-15 select-none font-sans group-hover:scale-110 transition-transform">🛢️</span>
              <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Minyak Jelantah</span>
              <span className="text-xl sm:text-2xl font-black text-[#1A3C34] block mt-1">8.5 Liter</span>
              <div className="mt-1.5 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span className="text-[9px] font-bold text-[#065F46]">Saring biodiesel warga</span>
              </div>
            </div>

          </div>
        </div>

        {/* Cute Showcase Gallery of Eco-Pets (Static Previews) */}
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-black text-[#1A3C34] tracking-tight">🌱 Temui Ragam Spesies Eco-Guardian Lucu</h3>
            <p className="text-xs text-emerald-800/80">Kembangkan monster klorofilmu dari fase telur hingga pelindung lingkungan rukun tetangga</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-white rounded-3xl border-4 border-[#E2F0E2] p-5 space-y-4 hover:border-emerald-200 transition-all text-center flex flex-col justify-between">
              <div className="space-y-2">
                <div className="bg-gradient-to-b from-[#ECFDF5] to-[#D1FAE5] rounded-full w-20 h-20 flex items-center justify-center mx-auto text-4xl shadow-inner border border-emerald-100">
                  🥚
                </div>
                <h4 className="font-black text-sm text-[#1A3C34]">Fase Telur (Eco-Egg)</h4>
                <span className="text-[9px] font-bold uppercase tracking-wider bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">Fase Awal</span>
                <p className="text-[11px] text-slate-500 leading-relaxed pt-1.5">
                  Menyerap sari air klorofil dan kepingan pakan kering. Sensitif terhadap kestabilan kebersihan pekarangan rumahmu.
                </p>
              </div>
              <div className="border-t border-slate-100 pt-3 text-[10px] text-[#065F46] font-bold font-mono">
                Pakan Utama: Pupuk Kompos Organik 🌱
              </div>
            </div>

            <div className="bg-white rounded-3xl border-4 border-[#E2F0E2] p-5 space-y-4 hover:border-emerald-200 transition-all text-center flex flex-col justify-between">
              <div className="space-y-2">
                <div className="bg-gradient-to-b from-[#ECFDF5] to-[#D1FAE5] rounded-full w-20 h-20 flex items-center justify-center mx-auto text-4xl shadow-inner border border-emerald-100 animate-pulse">
                  🌱
                </div>
                <h4 className="font-black text-sm text-[#1A3C34]">Sprouty (Bayi Tunas)</h4>
                <span className="text-[9px] font-bold uppercase tracking-wider bg-emerald-100 text-[#047857] px-2 py-0.5 rounded-full">Level 1 - 2</span>
                <p className="text-[11px] text-slate-500 leading-relaxed pt-1.5">
                  Kepala daun unyunya bergoyang jika disirami klorofil segar. Mulai aktif berakting mendaur oksigen mikro di sekitar kamarmu.
                </p>
              </div>
              <div className="border-t border-slate-100 pt-3 text-[10px] text-[#065F46] font-bold font-mono">
                Sifat Unyu: Senang Dimandikan 🧼
              </div>
            </div>

            <div className="bg-white rounded-3xl border-4 border-[#E2F0E2] p-5 space-y-4 hover:border-emerald-200 transition-all text-center flex flex-col justify-between">
              <div className="space-y-2">
                <div className="bg-gradient-to-b from-[#ECFDF5] to-[#D1FAE5] rounded-full w-20 h-20 flex items-center justify-center mx-auto text-4xl shadow-inner border border-emerald-100">
                  🌿
                </div>
                <h4 className="font-black text-sm text-[#1A3C34]">Leafy Elf (Remaja Rukun)</h4>
                <span className="text-[9px] font-bold uppercase tracking-wider bg-teal-100 text-teal-800 px-2 py-0.5 rounded-full">Level 3 - 4</span>
                <p className="text-[11px] text-slate-500 leading-relaxed pt-1.5">
                  Lincah dan gemar bertransaksi sosial. Dengan tarian daunnya, ia menjaring partikel debu halus di pekarangan rumah secara alami.
                </p>
              </div>
              <div className="border-t border-slate-100 pt-3 text-[10px] text-[#065F46] font-bold font-mono">
                Skematis: Anti Debu Skala Kecil ✨
              </div>
            </div>

            <div className="bg-white rounded-3xl border-4 border-[#E2F0E2] p-5 space-y-4 hover:border-emerald-200 transition-all text-center flex flex-col justify-between">
              <div className="space-y-2">
                <div className="bg-gradient-to-b from-[#ECFDF5] to-[#D1FAE5] rounded-full w-20 h-20 flex items-center justify-center mx-auto text-4xl shadow-inner border border-emerald-100">
                  🌳
                </div>
                <h4 className="font-black text-sm text-[#1A3C34]">Eco Titan (Guard Dunia)</h4>
                <span className="text-[9px] font-bold uppercase tracking-wider bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-black">Level 5+</span>
                <p className="text-[11px] text-slate-500 leading-relaxed pt-1.5">
                  Raksasa pelindung megah bertenaga fotosintesis murni. Berfungsi menepis polusi karbon berat dari asap kendaraan warga.
                </p>
              </div>
              <div className="border-t border-slate-100 pt-3 text-[10px] text-[#065F46] font-bold font-mono">
                Daya Aktif: Proteksi Polusi RT 🌳🛡️
              </div>
            </div>

          </div>
        </div>

        {/* Stateful Interactive Tutorial Walkthrough */}
        <div id="cara-kerja" className="bg-[#ECFDF5] p-6 sm:p-8 rounded-[36px] border-4 border-[#D1FAE5] space-y-4">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-b border-[#D1FAE5] pb-4">
            <div>
              <span className="text-[10px] bg-[#10B981] text-white px-3 py-1 rounded-full font-black uppercase tracking-wider inline-block">
                📖 Tutorial Interaktif Slide Ke-{slides[activeSlide].step} dari {slides.length}
              </span>
              <h4 className="text-lg font-black text-[#1A3C34] mt-1">Panduan Pengelolaan Lingkungan</h4>
            </div>
            {/* Nav controls */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrevSlide}
                className="p-2 sm:px-3 sm:py-1.5 bg-white hover:bg-emerald-50 text-[#047857] border border-[#D1FAE5] text-[10px] font-black rounded-xl transition-all cursor-pointer uppercase shadow-xs select-none active:scale-95"
              >
                ◀️ Kembali
              </button>
              <button
                type="button"
                onClick={handleNextSlide}
                className="p-2 sm:px-3 sm:py-1.5 bg-[#10B981] hover:bg-emerald-600 text-white border-b-2 border-emerald-800 text-[10px] font-black rounded-xl transition-all cursor-pointer uppercase shadow-xs select-none active:scale-95"
              >
                Selanjutnya ▶️
              </button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeSlide}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="bg-white p-6 rounded-3xl border-2 border-[#D1FAE5] shadow-xs flex flex-col md:flex-row items-start md:items-center gap-6 text-left"
            >
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-emerald-50 text-3xl font-black flex items-center justify-center shrink-0 shadow-inner border border-emerald-100">
                {slides[activeSlide].icon}
              </div>
              <div className="space-y-1.5 max-w-2xl">
                <h5 className="font-extrabold text-sm sm:text-base text-[#1A3C34]">
                  Langkah {slides[activeSlide].step}: {slides[activeSlide].title}
                </h5>
                <p className="text-xs sm:text-[13px] text-slate-600 leading-relaxed font-medium">
                  {slides[activeSlide].description}
                </p>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 pt-2">
            {slides.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActiveSlide(idx)}
                className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                  idx === activeSlide ? "bg-[#10B981] w-6" : "bg-[#D1FAE5] hover:bg-[#10B981]/50"
                }`}
                title={`Ke slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>

          <div className="bg-white rounded-3xl p-6 border-2 border-[#D1FAE5] flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <span className="text-rose-500 font-bold text-xs flex items-center gap-1">
                ❤️ Kata Ajakan Minggu Ini:
              </span>
              <p className="text-sm font-semibold italic text-[#1A3C34] leading-relaxed">
                "Bumi kita tidak mewarisi sisa sampah dari masa lalu, melainkan meminjamnya bagi tersenyum hijaunya masa depan anak-anak kita. Satu botol plastik yang kamu pilah hari ini menyelamatkan sepetak tanah subur kampung kita esok hari!"
              </p>
              <div className="flex items-center gap-2 pt-1 border-t border-emerald-50">
                <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-100">
                  <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&auto=format&fit=crop&q=80" alt="Ibu Retno" className="w-full h-full object-cover" />
                </div>
                <div>
                  <span className="text-xs font-black text-[#1A3C34] block leading-none">Bu Retno</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">Hortikulturis & Warga Senior Kelurahan Hijau</span>
                </div>
              </div>
            </div>

            <div className="pt-2">
              {!profile.registered ? (
                <button
                  onClick={() => setAuthModal('register')}
                  className="w-full py-3.5 bg-[#10B981] hover:bg-[#059669] text-white border-b-4 border-[#065F46] hover:border-emerald-800 text-xs font-black rounded-2xl transition-all shadow-md uppercase tracking-wider text-center cursor-pointer"
                >
                  👉 Mulai Ikut Pilah Klorofil & Buat Akun
                </button>
              ) : (
                <div className="text-center p-3 text-xs bg-[#ECFDF5] text-emerald-800 font-extrabold rounded-2xl border border-emerald-200">
                  🎉 Anda telah terdaftar sebagai Eco-Ranger aktif! Lanjutkan menjaga kedaulatan lingkungan!
                </div>
              )}
            </div>
          </div>
        </div>
    );
  };

  // Helper renderer to manage guest gated sections
  const renderTabContent = () => {
    if (activeTab === 'dashboard') {
      return <LandingDashboard />;
    }

    // Guest protection feature gating
    if (!profile.registered) {
      return (
        <div className="bg-white rounded-[40px] border-4 border-[#E2F0E2] p-8 md:p-12 text-center shadow-xl space-y-6 max-w-2xl mx-auto relative overflow-hidden" id="lock-screen-panel">
          <div className="absolute inset-0 bg-[#F4F9F4]/40 pointer-events-none" />
          
          <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-4xl shadow-inner border-2 border-[#10B981]/25 relative">
            <span className="animate-bounce">🔒</span>
            <div className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full animate-ping" />
          </div>

          <div className="space-y-3 relative z-10">
            <h3 className="text-xl md:text-2xl font-black text-[#1A3C34] tracking-tight">Eits! Fitur Terkunci 🔒</h3>
            <p className="text-xs text-[#065F46] font-bold uppercase tracking-wider">Akses Khusus Warga Ranger Terdaftar</p>
            <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
              Untuk dapat mulai melakukan pencatatan sampah aslimu, merawat monster Eco-Guardian pertamamu, berkolaborasi dalam misi event warga, atau barter P2P dengan para tetangga, silakan buat akun baru atau login terlebih dahulu!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-2 relative z-10">
            <button
              onClick={() => setAuthModal('register')}
              className="w-full sm:w-auto px-6 py-3.5 bg-[#10B981] hover:bg-[#059669] text-white border-b-4 border-[#065F46] text-xs font-black rounded-2xl transition-all shadow-md uppercase tracking-wider cursor-pointer"
            >
              🥚 Buat Akun & Adopsi Pet
            </button>
            <button
              onClick={() => setAuthModal('login')}
              className="w-full sm:w-auto px-6 py-3.5 bg-white hover:bg-[#F4F9F4] text-[#1A3C34] border-2 border-[#E2F0E2] hover:border-[#10B981] text-xs font-black rounded-2xl transition-all shadow-sm uppercase tracking-wider cursor-pointer"
            >
              🔑 Masuk Akun (Login)
            </button>
          </div>

          <div className="text-[10px] text-slate-400 italic">
            💡 Gratis, aman, dan progress kamu langsung tersimpan di browser perangkat lokal ini!
          </div>
        </div>
      );
    }

    switch (activeTab) {
      case 'pelihara':
        return (
          <PetDashboard
            pet={pet}
            inventory={inventory}
            onFeed={handlePetFeed}
            onWash={handlePetWash}
            onPlay={handlePetPlay}
            onEvolve={handlePetEvolve}
            onRename={handleRenamePet}
          />
        );
      case 'catat':
        return (
          <WasteLogger
            inventory={inventory}
            onAddWaste={(category, weightGrams, points, photoUrl) => handleAddWaste(category, weightGrams, points, 'DEPOSIT', photoUrl)}
            wasteLogs={wasteLogs}
          />
        );
      case 'barter':
        return (
          <BarterHub
            inventory={inventory}
            neighbors={neighbors}
            barterListings={barterListings}
            chatMessages={chatMessages}
            wasteLogs={wasteLogs}
            onExecuteBarter={handleExecuteBarter}
            onPostListing={handlePostListingByPlayer}
            onSendChatMessage={handleSendChatMessage}
            onAddWaste={handleAddWaste}
          />
        );
      case 'event':
        return (
          <MissionsLeaderboard
            inventory={inventory}
            missions={missions}
            leaderboard={leaderboard}
            onDonateToMission={handleDonateToMission}
            wallet={wallet}
            onUpdateWallet={(method, phone) => setWallet({ method, phone })}
            pickups={pickups}
            onUpdatePickups={setPickups}
            onShareToChat={(text) => {
              handleSendChatMessage(text);
              setActiveTab('barter');
            }}
          />
        );
      case 'ai-chat':
        return (
          <ChatAdvisor
            chatHistory={chatMessages}
            onAddChatMessage={handleAddAiAdvisorMessage}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F9F4] text-[#1A3C34] flex flex-col font-sans antialiased" id="eco-pet-app-root">
      {/* Upper Navigation Header Bar */}
      <header className="bg-white border-b-4 border-[#E2F0E2] sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Logo Brand / Theme Title */}
          <div className="flex items-center gap-3">
            {/* Hamburger Menu Toggle Button (Garis 3) */}
            <button
              onClick={() => setIsOpenMenu(!isOpenMenu)}
              className="p-2.5 bg-[#F0F7F0] hover:bg-[#E2F0E2] border-2 border-[#10B981]/20 rounded-2xl text-[#10B981] hover:text-[#065F46] focus:outline-none transition-all flex items-center justify-center cursor-pointer shadow-sm active:scale-95"
              id="hamburger-menu-toggle-button"
              title="Buka Menu Fitur"
            >
              {isOpenMenu ? <X className="w-5.5 h-5.5" /> : <Menu className="w-5.5 h-5.5" />}
            </button>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="bg-[#ECFDF5] text-[#10B981] border-2 border-[#D1FAE5] text-xs font-black px-4 py-2 rounded-2xl uppercase tracking-wider block">
                  📍 {profile.registered ? profile.neighborhood : "Tamu Warga 🌱"}
                </span>
              </div>
            </div>
          </div>

          {/* Quick HUD State Panel or Guest Onboarding */}
          {!profile.registered ? (
            <div className="flex items-center gap-3" id="guest-header-auth-buttons">
              <span className="text-[11px] font-black tracking-wider text-[#065F46] bg-[#ECFDF5] border border-[#D1FAE5] px-3.5 py-2 rounded-2xl hidden md:inline-flex items-center gap-1.5 shadow-inner">
                👋 Selamat Datang Warga!
              </span>
              <button
                onClick={() => setAuthModal('login')}
                className="px-4.5 py-2.5 bg-white hover:bg-emerald-50 text-[#10B981] border-2 border-[#E2F0E2] hover:border-[#10B981] text-xs font-black rounded-2xl transition-all cursor-pointer uppercase tracking-wider shadow-sm"
              >
                🔑 Masuk (Login)
              </button>
              <button
                onClick={() => setAuthModal('register')}
                className="px-4.5 py-2.5 bg-[#10B981] hover:bg-[#059669] text-white border-b-4 border-[#065F46] hover:border-[#0284c7] text-xs font-black rounded-2xl transition-all cursor-pointer uppercase tracking-wider shadow-md shadow-[#10b9811c]"
              >
                🥚 Daftar Akun
              </button>
            </div>
          ) : (
            <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 sm:gap-3 text-xs">
              {/* Coins / EcoTokens */}
              <div className="bg-[#F0F7F0] text-[#1A3C34] px-3.5 py-2.5 rounded-2xl border-2 border-[#E2F0E2] flex items-center gap-1.5 shadow-sm whitespace-nowrap">
                <Coins className="w-4.5 h-4.5 text-[#10B981] animate-bounce shrink-0" />
                <span className="text-[11px] font-black tracking-wide text-[#065F46] uppercase">Koin: {inventory.ecoTokens} Token</span>
              </div>

              {/* Pet Status HUD */}
              <div 
                onClick={() => setActiveTab('pelihara')}
                className="bg-[#F0F7F0] text-[#1A3C34] px-3.5 py-2.5 rounded-2xl border-2 border-[#E2F0E2] flex items-center gap-1.5 cursor-pointer hover:bg-[#E2F0E2]/70 transition-colors shadow-sm whitespace-nowrap"
              >
                <div className="w-2.5 h-2.5 bg-[#10B981] rounded-full animate-ping shrink-0" />
                <span className="text-[11px] font-black tracking-wide text-[#065F46] uppercase">Pet: {pet.name} (Lvl {pet.level})</span>
              </div>

              {/* Bulatan Avatar Akun Saya */}
              <button
                onClick={() => setIsProfileEditOpen(true)}
                className="relative shrink-0 focus:outline-none cursor-pointer group"
                title="Informasi Akun Saya & Edit Profil"
                id="header-profile-avatar-button"
              >
                <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-full border-4 border-[#10B981] overflow-hidden bg-white shadow-md group-hover:scale-105 active:scale-95 transition-all duration-200">
                  <img src={profile.avatar} alt={profile.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-1 -right-1 bg-[#10B981] text-white w-5 h-5 rounded-full border-2 border-white flex items-center justify-center text-[10px] font-black shadow shadow-black/10">
                  ✏️
                </div>
              </button>

              {/* Ganti Akun Button */}
              <button
                onClick={() => {
                  // Save current user stats if active before switching
                  if (profile.registered && profile.name) {
                    try {
                      const existingList = JSON.parse(localStorage.getItem("eco_guardian_profile_list") || "[]") as string[];
                      if (!existingList.includes(profile.name)) {
                        existingList.push(profile.name);
                        localStorage.setItem("eco_guardian_profile_list", JSON.stringify(existingList));
                      }
                      localStorage.setItem(`eco_guardian_profile_data_${profile.name}`, JSON.stringify(profile));
                      localStorage.setItem(`eco_guardian_pet_data_${profile.name}`, JSON.stringify(pet));
                      localStorage.setItem(`eco_guardian_inventory_data_${profile.name}`, JSON.stringify(inventory));
                    } catch(e){}
                  }
                  // Set profile registered to false so register/login modal opens
                  setProfile(prev => ({ ...prev, name: "", registered: false }));
                  setAuthModal('login');
                }}
                className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-2 border-emerald-200 px-3 py-2 rounded-2xl flex items-center gap-1.5 transition-colors cursor-pointer font-extrabold"
                title="Ganti Akun / Logout"
              >
                <Users className="w-4 h-4 text-emerald-600" />
                <span className="hidden sm:inline font-sans font-black font-sans">Ganti Akun</span>
              </button>

              {/* Reset Account Button */}
              <button
                onClick={() => setShowResetConfirmationModal(true)}
                className="bg-red-50 hover:bg-red-100 text-red-600 border-2 border-red-200 px-3 py-2 rounded-2xl flex items-center gap-1.5 transition-colors cursor-pointer font-extrabold"
                title="Reset Akun / Keluar"
              >
                <LogOut className="w-4 h-4 text-red-500" />
                <span className="hidden sm:inline font-sans font-black">Reset Akun</span>
              </button>
            </div>
          )}

        </div>
      </header>

      {/* Responsive App Alert Block */}
      <AnimatePresence>
        {appAlert && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className={`text-center py-3.5 px-4 text-xs font-semibold border-b transition-colors ${
              appAlert.type === 'success'
                ? "bg-[#10B981] text-white border-[#065F46]"
                : appAlert.type === 'warning'
                ? "bg-[#FFFBEB] text-amber-900 border-[#FEF3C7]"
                : "bg-[#065F46] text-[#ECFDF5] border-[#047857]"
            }`}
          >
            <div className="max-w-4xl mx-auto flex items-center justify-center gap-1.5">
              <span>📢</span>
              <span>{appAlert.message}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Drawer Overlay Backdrop & Sliding Menu Drawer (3 Garis) */}
      <AnimatePresence>
        {isOpenMenu && (
          <div className="fixed inset-0 z-50 flex" id="drawer-navigation-portal">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpenMenu(false)}
              className="absolute inset-0 bg-[#065F46]/40 backdrop-blur-xs cursor-pointer"
            />
            
            {/* Sliding Drawer Content */}
            <motion.aside
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 26, stiffness: 220 }}
              className="relative w-[300px] max-w-[85vw] h-full bg-white border-r-4 border-[#10B981] p-6 shadow-2xl flex flex-col justify-between overflow-y-auto"
            >
              <div className="space-y-6">
                {/* Header of Menu Drawer */}
                <div className="flex items-center justify-between border-b pb-4">
                  <div className="flex items-center gap-2">
                    <span className="font-black uppercase text-[#065F46] text-sm tracking-widest font-sans">Navigasi Eco-Guardian</span>
                  </div>
                  <button
                    onClick={() => setIsOpenMenu(false)}
                    className="p-1 px-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-extrabold text-xs rounded-xl transition-all cursor-pointer font-sans"
                  >
                    ✕ Close
                  </button>
                </div>

                <span className="text-[10px] font-black uppercase text-emerald-700 tracking-widest block px-1 font-sans">Pilih Fitur / Menu</span>

                <nav className="space-y-2.5" id="main-navigation-menu-sidebar">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('dashboard');
                      setIsOpenMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3.5 text-xs font-black uppercase tracking-widest rounded-2xl transition-all border-2 cursor-pointer font-sans ${
                      activeTab === 'dashboard'
                        ? "bg-[#10B981] text-white border-[#065F46] border-b-4 shadow-lg shadow-[#10b98133]"
                        : "bg-white text-[#1A3C34] hover:bg-[#F0F7F0] border-[#E2F0E2] hover:border-[#10B981]"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span>Beranda</span>
                    </div>
                    <span className={`font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                      activeTab === 'dashboard' ? "bg-white text-[#065F46]" : "bg-[#ECFDF5] text-[#10B981]"
                    }`}>
                      Utama
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (!profile.registered) {
                        setAuthModal('register');
                        return;
                      }
                      setActiveTab('pelihara');
                      setIsOpenMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3.5 text-xs font-black uppercase tracking-widest rounded-2xl transition-all border-2 cursor-pointer font-sans ${
                      activeTab === 'pelihara'
                        ? "bg-[#10B981] text-white border-[#065F46] border-b-4 shadow-lg shadow-[#10b98133]"
                        : "bg-white text-[#1A3C34] hover:bg-[#F0F7F0] border-[#E2F0E2] hover:border-[#10B981]"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span>Peliharaan Eco Pet {!profile.registered && " (Terkunci)"}</span>
                    </div>
                    <span className={`font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                      activeTab === 'pelihara' ? "bg-white text-[#065F46]" : "bg-[#ECFDF5] text-[#10B981]"
                    }`}>
                      Lvl {pet.level}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (!profile.registered) {
                        setAuthModal('register');
                        return;
                      }
                      setActiveTab('catat');
                      setIsOpenMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3.5 text-xs font-black uppercase tracking-widest rounded-2xl transition-all border-2 cursor-pointer font-sans ${
                      activeTab === 'catat'
                        ? "bg-[#10B981] text-white border-[#065F46] border-b-4 shadow-lg shadow-[#10b98133]"
                        : "bg-white text-[#1A3C34] hover:bg-[#F0F7F0] border-[#E2F0E2] hover:border-[#10B981]"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span>Catat dan Pindah {!profile.registered && " (Terkunci)"}</span>
                    </div>
                    <span className={`font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                      activeTab === 'catat' ? "bg-white text-[#065F46]" : "bg-[#ECFDF5] text-[#10B981]"
                    }`}>
                      Scan AI
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (!profile.registered) {
                        setAuthModal('register');
                        return;
                      }
                      setActiveTab('barter');
                      setIsOpenMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3.5 text-xs font-black uppercase tracking-widest rounded-2xl transition-all border-2 cursor-pointer font-sans ${
                      activeTab === 'barter'
                        ? "bg-[#10B981] text-white border-[#065F46] border-b-4 shadow-lg shadow-[#10b98133]"
                        : "bg-white text-[#1A3C34] hover:bg-[#F0F7F0] border-[#E2F0E2] hover:border-[#10B981]"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span>Barter {!profile.registered && " (Terkunci)"}</span>
                    </div>
                    <span className={`font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                      activeTab === 'barter' ? "bg-white text-[#065F46]" : "bg-[#ECFDF5] text-[#10B981]"
                    }`}>
                      P2P Swap
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (!profile.registered) {
                        setAuthModal('register');
                        return;
                      }
                      setActiveTab('event');
                      setIsOpenMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3.5 text-xs font-black uppercase tracking-widest rounded-2xl transition-all border-2 cursor-pointer font-sans ${
                      activeTab === 'event'
                        ? "bg-[#10B981] text-white border-[#065F46] border-b-4 shadow-lg shadow-[#10b98133]"
                        : "bg-white text-[#1A3C34] hover:bg-[#F0F7F0] border-[#E2F0E2] hover:border-[#10B981]"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span>Event {!profile.registered && " (Terkunci)"}</span>
                    </div>
                    <span className={`font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                      activeTab === 'event' ? "bg-white text-[#065F46]" : "bg-[#FEF3C7] text-amber-800"
                    }`}>
                      Kampanye
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (!profile.registered) {
                        setAuthModal('register');
                        return;
                      }
                      setActiveTab('ai-chat');
                      setIsOpenMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-4 py-3.5 text-xs font-black uppercase tracking-widest rounded-2xl transition-all border-2 cursor-pointer font-sans ${
                      activeTab === 'ai-chat'
                        ? "bg-[#065F46] text-white border-[#047857] border-b-4 shadow-lg shadow-[#065f4633]"
                        : "bg-white text-[#1A3C34] hover:bg-[#F0F7F0] border-[#E2F0E2] hover:border-[#10B981]"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="flex items-center gap-1.5">
                        AI Consultant {!profile.registered && " (Terkunci)"}
                        <div className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse"></div>
                      </span>
                    </div>
                  </button>
                </nav>
              </div>
            </motion.aside>
          </div>
        )}
      </AnimatePresence>

      {/* Main Content Layout with Full Range Density */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row gap-6">

        {/* Dynamic Panels transitions box rendering screen */}
        <section className="flex-1 min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -15, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {renderTabContent()}
            </motion.div>
          </AnimatePresence>
        </section>

      </main>

      {/* Pure White clean footer */}
      <footer className="bg-white border-t-4 border-[#E2F0E2] py-8 text-center text-xs text-emerald-800/70 font-semibold shadow-inner mt-auto">
        <p>© 2026 Eco-Guardian Kelurahan Hijau. Dibuat dengan penuh kepedulian sosial penanggulangan sampah nyata di sekitarmu.</p>
      </footer>

      {/* Dynamic Popups for Login & Register Modal overlay */}
      <AnimatePresence>
        {authModal && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-white rounded-[45px] border-4 border-[#10B981] p-6 sm:p-10 max-w-2xl w-full shadow-2xl relative overflow-y-auto max-h-[90vh] space-y-6 text-[#1A3C34]"
            >
              {/* Close Button */}
              <button
                onClick={() => {
                  setAuthModal(null);
                  setRegError("");
                  setLoginError("");
                }}
                className="absolute top-4 right-4 w-9 h-9 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full flex items-center justify-center font-bold text-xs cursor-pointer transition-colors"
              >
                ✕
              </button>

              {authModal === 'register' ? (
                /* Registration Screen Form (transferred from former signup) */
                <div className="space-y-6 text-left">
                  <div className="text-center space-y-2">
                    <div className="w-14 h-14 bg-[#10B981] text-white rounded-2xl flex items-center justify-center shadow-lg shadow-[#10b98122] mx-auto rotate-3">
                      <Leaf className="w-7 h-7 animate-pulse" />
                    </div>
                    <h2 className="text-2xl font-black text-[#1A3C34] tracking-tight">Daftar Akun Eco-Guardian Warga</h2>
                    <p className="text-xs text-emerald-800/80 font-medium max-w-md mx-auto leading-relaxed font-sans text-center">
                      Gabung rukun tetangga, lapor pemilahan sampah nyata di rumahmu, serta pelihara makhluk virtual setiamu.
                    </p>
                  </div>

                  {regError && (
                    <div className="p-3 bg-red-50 text-red-700 text-xs font-black rounded-2xl border border-red-100 text-center uppercase tracking-wide">
                      ⚠️ {regError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Left Form: Profile Details */}
                    <div className="space-y-4 text-left">
                      <span className="text-[10px] font-black uppercase text-[#10B981] tracking-wider block">1. Profil Penyelamat</span>
                      
                      {/* Name Input */}
                      <div className="space-y-1.5 font-sans">
                        <label className="text-xs font-black text-slate-700 block text-left">Nama Lengkap / Panggilan:</label>
                        <input
                          type="text"
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          placeholder="Contoh: Lila Ardani"
                          maxLength={18}
                          className="w-full px-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                        />
                      </div>

                      {/* Password Input */}
                      <div className="space-y-1.5 font-sans">
                        <label className="text-xs font-black text-slate-700 block text-left">Buat Password:</label>
                        <input
                          type="password"
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          placeholder="Kombinasi password rahasia..."
                          className="w-full px-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                        />
                      </div>

                      {/* Gender Selector */}
                      <div className="space-y-1.5 font-sans">
                        <label className="text-xs font-black text-slate-700 block text-left">Jenis Kelamin:</label>
                        <div className="grid grid-cols-2 gap-3">
                          <button
                            type="button"
                            onClick={() => setRegGender('Laki-laki')}
                            className={`py-2.5 px-4 rounded-xl border-2 text-[11px] font-black tracking-wide uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                              regGender === 'Laki-laki'
                                ? 'bg-emerald-500 text-white border-emerald-600 shadow-md'
                                : 'bg-[#F4F9F4] text-slate-700 border-[#E2F0E2] hover:border-[#10B981]/50'
                            }`}
                          >
                            👦 Laki-laki
                          </button>
                          <button
                            type="button"
                            onClick={() => setRegGender('Perempuan')}
                            className={`py-2.5 px-4 rounded-xl border-2 text-[11px] font-black tracking-wide uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                              regGender === 'Perempuan'
                                ? 'bg-emerald-500 text-white border-emerald-600 shadow-md'
                                : 'bg-[#F4F9F4] text-slate-700 border-[#E2F0E2] hover:border-[#10B981]/50'
                            }`}
                          >
                            👧 Perempuan
                          </button>
                        </div>
                      </div>

                      {/* Alamat Lengkap Input */}
                      <div className="space-y-1.5 font-sans">
                        <label className="text-xs font-black text-slate-700 block text-left">Alamat Lengkap / Daerah Asal:</label>
                        <div className="relative">
                          <input
                            type="text"
                            value={regNeighborhood}
                            onChange={(e) => setRegNeighborhood(e.target.value)}
                            placeholder="Contoh: Jl. Asia Afrika No. 12, Bandung"
                            className="w-full pl-9 pr-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                          />
                          <MapPin className="w-4 h-4 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        </div>
                      </div>

                      {/* Initial Pet Name */}
                      <div className="space-y-1.5 font-sans">
                        <label className="text-xs font-black text-slate-700 block text-left">Nama Eco-Guardian Telurmu:</label>
                        <input
                          type="text"
                          value={regPetName}
                          onChange={(e) => setRegPetName(e.target.value)}
                          placeholder="Contoh: Sprouty"
                          maxLength={18}
                          className="w-full px-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                        />
                      </div>
                    </div>

                    {/* Right Form: Avatar Selection & Custom File Upload */}
                    <div className="space-y-4 text-left">
                      <span className="text-[10px] font-black uppercase text-[#10B981] tracking-wider block">2. Pilih / Unggah Avatar Tumbuhan Karakter</span>
                      
                      {/* Avatar Presets Grid */}
                      <div className="grid grid-cols-2 gap-3.5">
                        {PLANT_AVATARS.map((avatarItem) => (
                          <button
                            key={avatarItem.url}
                            type="button"
                            onClick={() => setRegAvatar(avatarItem.url)}
                            className={`p-2 rounded-2xl bg-white border-2 text-center transition-all cursor-pointer relative group flex flex-col items-center gap-1.5 ${
                              regAvatar === avatarItem.url
                                ? "border-[#10B981] ring-2 ring-[#ECFDF5] shadow-lg"
                                : "border-[#E2F0E2] hover:border-[#10B981]/50"
                            }`}
                          >
                            <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-[#E2F0E2] bg-[#F4F9F4]">
                              <img src={avatarItem.url} alt={avatarItem.label} referrerPolicy="no-referrer" className="w-full h-full object-cover animate-pulse" />
                            </div>
                            <span className="text-[10px] font-bold text-slate-600 block">{avatarItem.label}</span>
                            {regAvatar === avatarItem.url && (
                              <span className="absolute top-1.5 right-1.5 text-emerald-500 font-extrabold text-xs">✓</span>
                            )}
                          </button>
                        ))}
                      </div>

                      {/* Folder File Drag and Drop / Upload */}
                      <div className="p-3 bg-emerald-50/50 rounded-2xl border-2 border-dashed border-[#10B981]/30 text-center relative group hover:bg-emerald-50 transition-all cursor-pointer">
                        <input
                          type="file"
                          accept="image/*"
                          id="custom-avatar-upload"
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                if (typeof reader.result === 'string') {
                                  setRegAvatar(reader.result);
                                }
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                        <div className="flex flex-col items-center gap-1">
                          <Upload className="w-5 h-5 text-[#10B981] group-hover:scale-110 transition-transform" />
                          <span className="text-[11px] font-black text-emerald-800">Geser (Drag) atau Upload Foto</span>
                          <span className="text-[9px] text-[#065F46] font-bold font-sans">Format gambar bebas langsung dimuat</span>
                        </div>
                      </div>

                      {/* Display custom preview */}
                      {regAvatar && !PLANT_AVATARS.map(item => item.url).includes(regAvatar) && (
                        <div className="flex items-center gap-3 bg-emerald-50 p-2.5 rounded-2xl border border-[#D1FAE5]">
                          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-[#10B981] shadow-sm">
                            <img src={regAvatar} className="w-full h-full object-cover" referrerPolicy="no-referrer" alt="Custom Preview" />
                          </div>
                          <div className="text-left">
                            <span className="text-[10px] font-black text-[#1A3C34] block">🍀 Foto Berhasil Dimuat!</span>
                            <span className="text-[9px] text-emerald-700/80 font-medium block">Siap digunakan di profil Anda</span>
                          </div>
                        </div>
                      )}
                    </div>

                  </div>

                  {/* Action hatchery button */}
                  <button
                    type="button"
                    onClick={() => {
                      handleRegister(regName, regAvatar, regNeighborhood, regPetName, regGender);
                      setAuthModal(null);
                    }}
                    className="w-full py-4 bg-[#10B981] hover:bg-[#059669] text-white border-[#065F46] border-b-4 font-black rounded-3xl transition-all shadow-xl shadow-[#10b98122] flex items-center justify-center gap-2 cursor-pointer uppercase text-xs tracking-wider"
                  >
                    🥚 Tetaskan Telur Eco-Guardian Anda
                  </button>

                  <div className="text-center font-sans">
                    <button
                      onClick={() => setAuthModal('login')}
                      className="text-xs text-emerald-800 font-bold hover:underline cursor-pointer"
                    >
                      Sudah punya akun sebelumnya? Masuk di sini
                    </button>
                  </div>
                </div>
              ) : (
                /* Login Screen Form */
                <div className="space-y-6 text-left">
                  <div className="text-center space-y-2">
                    <div className="w-14 h-14 bg-[#10B981] text-white rounded-2xl flex items-center justify-center shadow-lg shadow-[#10b98122] mx-auto rotate-3">
                      <Sparkles className="w-7 h-7" />
                    </div>
                    <h2 className="text-2xl font-black text-[#1A3C34] tracking-tight">Ketik & Masuk Akun Warga</h2>
                    <p className="text-xs text-emerald-800/80 font-medium max-w-md mx-auto leading-relaxed font-sans text-center">
                      Lanjutkan mengontrol sirkulasi klorofil dan progress tabungan sampah nyata Anda di balai desa RT.
                    </p>
                  </div>

                  {loginError && (
                    <div className="p-3 bg-red-50 text-red-700 text-xs font-black rounded-2xl border border-red-100 text-center uppercase tracking-wide">
                      ⚠️ {loginError}
                    </div>
                  )}

                  {/* Quick restore profile detection */}
                  {(() => {
                    try {
                      const profileList = JSON.parse(localStorage.getItem("eco_guardian_profile_list") || "[]") as string[];
                      if (profileList.length > 0) {
                        return (
                          <div className="p-4 bg-emerald-50/50 rounded-3xl border-2 border-[#10B981]/15 space-y-3.5">
                            <span className="text-[9px] font-black uppercase text-[#10B981] tracking-wider block text-left font-sans">Pilih Profil Terdaftar di Perangkat Ini:</span>
                            <div className="flex flex-col gap-2.5 max-h-[160px] overflow-y-auto pr-1">
                              {profileList.map((usrName) => {
                                let usrProf = { name: usrName, avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80", neighborhood: "RT 05" };
                                try {
                                  const saved = localStorage.getItem(`eco_guardian_profile_data_${usrName}`);
                                  if (saved) usrProf = JSON.parse(saved);
                                } catch(e){}
                                return (
                                  <div key={usrName} className="flex items-center justify-between gap-3 bg-white p-2.5 rounded-2xl border border-[#E2F0E2] hover:border-[#10B981]/40 transition-all shadow-sm">
                                    <div className="flex items-center gap-2.5">
                                      <div className="w-9 h-9 rounded-full overflow-hidden border">
                                        <img src={usrProf.avatar} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                                      </div>
                                      <div className="text-left leading-tight">
                                        <span className="text-xs font-black text-[#1A3C34] block font-sans">{usrProf.name}</span>
                                        <span className="text-[9px] text-[#065F46] block font-medium">{usrProf.neighborhood}</span>
                                      </div>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setLoginInputName(usrProf.name);
                                        setLoginInputRT(usrProf.neighborhood);
                                        setLoginError("");
                                        setTimeout(() => {
                                          const el = document.getElementById("login-password-input");
                                          if (el) el.focus();
                                        }, 100);
                                      }}
                                      className="px-3 py-1.5 bg-[#10B981] hover:bg-[#059669] text-white border-b-2 border-[#065F46] font-bold text-[10px] rounded-lg transition-all cursor-pointer font-sans"
                                    >
                                      Pilih ➔
                                    </button>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      }
                    } catch(e){}
                    
                    if (localStorage.getItem("eco_pet_profile")) {
                      return (
                        <div className="p-4 bg-emerald-50/50 rounded-3xl border-2 border-[#10B981]/15 space-y-3.5">
                          <span className="text-[9px] font-black uppercase text-[#10B981] tracking-wider block text-left">Deteksi Akun Sebelumnya di Perangkat Ini:</span>
                          <div className="flex items-center justify-between gap-4 bg-white p-3.5 rounded-2xl border-2 border-[#E2F0E2]">
                            <div className="flex items-center gap-3">
                              <div className="w-11 h-11 rounded-full overflow-hidden border">
                                <img 
                                  src={(() => {
                                    try {
                                      const saved = localStorage.getItem("eco_pet_profile");
                                      return saved ? JSON.parse(saved).avatar : "";
                                    } catch(e){}
                                    return "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80";
                                  })()} 
                                  referrerPolicy="no-referrer" 
                                  className="w-full h-full object-cover" 
                                />
                              </div>
                              <div className="text-left">
                                <span className="text-xs font-black text-[#1A3C34] block font-sans">
                                  {(() => {
                                    try {
                                      const saved = localStorage.getItem("eco_pet_profile");
                                      return saved ? JSON.parse(saved).name : "";
                                    } catch(e){}
                                    return "Lila Ardani";
                                  })()}
                                </span>
                                <span className="text-[10px] text-slate-400 block mt-0.5">
                                  {(() => {
                                    try {
                                      const saved = localStorage.getItem("eco_pet_profile");
                                      return saved ? JSON.parse(saved).neighborhood : "";
                                    } catch(e){}
                                    return "Kelurahan Hijau";
                                  })()}
                                </span>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => {
                                try {
                                  const saved = localStorage.getItem("eco_pet_profile");
                                  if (saved) {
                                    const parsed = JSON.parse(saved);
                                    handleLogin(parsed.name, parsed.neighborhood, parsed.password);
                                  }
                                } catch(e){}
                              }}
                              className="px-4 py-2.5 bg-[#10B981] hover:bg-[#059669] text-white border-b-2 border-[#065F46] font-bold text-xs rounded-xl transition-all cursor-pointer font-sans"
                            >
                              Masuk Langsung (1-Klik)
                            </button>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  })()}

                  <div className="space-y-4">
                    <span className="text-[10px] font-black uppercase text-[#10B981] tracking-wider block text-left font-sans">Ketik Akun Simulasi Lain / Baru:</span>
                    
                    <div className="space-y-1.5 font-sans text-left">
                      <label className="text-xs font-black text-slate-700 block text-left">Ketik Nama Ranger:</label>
                      <input
                        type="text"
                        value={loginInputName}
                        onChange={(e) => setLoginInputName(e.target.value)}
                        placeholder="Masukkan nama panggilan / nama luhur..."
                        className="w-full px-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                      />
                    </div>

                    {/* Alamat Input */}
                    <div className="space-y-1.5 text-left font-sans">
                      <label className="text-xs font-black text-slate-700 block text-left">Alamat Lengkap / Daerah Asal:</label>
                      <div className="relative">
                        <input
                          type="text"
                          value={loginInputRT}
                          onChange={(e) => setLoginInputRT(e.target.value)}
                          placeholder="Contoh: Jl. Asia Afrika No. 12, Bandung"
                          className="w-full pl-9 pr-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                        />
                        <MapPin className="w-4 h-4 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2" />
                      </div>
                    </div>

                    {/* Password Input */}
                    <div className="space-y-1.5 text-left font-sans">
                      <label className="text-xs font-black text-slate-700 block text-left">Masukkan Password:</label>
                      <input
                        type="password"
                        id="login-password-input"
                        value={loginInputPassword}
                        onChange={(e) => setLoginInputPassword(e.target.value)}
                        placeholder="Ketik password akun anda..."
                        className="w-full px-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleLogin(loginInputName, loginInputRT, loginInputPassword)}
                    className="w-full py-4 bg-[#10B981] hover:bg-[#059669] text-white border-[#065F46] border-b-4 font-black rounded-3xl transition-all shadow-xl shadow-[#10b98122] flex items-center justify-center gap-2 cursor-pointer uppercase text-xs tracking-wider"
                  >
                    🔑 Sambungkan Simulasi Akun Warga
                  </button>

                  <div className="text-center font-sans">
                    <button
                      onClick={() => setAuthModal('register')}
                      className="text-xs text-emerald-800 font-bold hover:underline cursor-pointer"
                    >
                      Belum punya akun warga? Buat akun di sini (5 detik)
                    </button>
                  </div>
                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Hatching Animation Overlay of the Eco-Guardian egg */}
      <AnimatePresence>
        {isHatching && (
          <div className="fixed inset-0 z-50 bg-[#F4F9F4] flex items-center justify-center p-4 sm:p-6" id="is-hatching-animation-overlay">
            <motion.div
              key="hatching"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[40px] border-4 border-[#10B981] p-10 md:p-12 text-center max-w-lg w-full shadow-2xl relative overflow-hidden flex flex-col items-center justify-center min-h-[460px] space-y-6"
            >
              {/* Spinning/pulsing environment */}
              <div className="absolute inset-0 bg-[#ECFDF5]/60 pointer-events-none" />
              
              <motion.div
                animate={{ 
                  rotate: [0, -10, 10, -10, 10, -5, 5, 0],
                  scale: [1, 1.05, 1, 1.05, 1]
                }}
                transition={{ repeat: Infinity, duration: 1.5 }}
                className="text-8xl select-none"
              >
                🥚
              </motion.div>

              <div className="space-y-2.5 z-10 w-full">
                <h2 className="text-[#1A3C34] font-black text-xl md:text-2xl tracking-tight uppercase flex items-center justify-center gap-2">
                  <Sparkles className="w-6 h-6 text-[#10B981] animate-spin" />
                  Mencoba Menetas...
                </h2>
                <div className="w-full h-3 bg-[#E2F0E2] rounded-full mx-auto overflow-hidden border border-[#D1FAE5] relative">
                  <motion.div 
                    initial={{ width: "0%" }}
                    animate={{ width: `${hatchingProgress}%` }}
                    className="absolute top-0 left-0 h-full bg-emerald-500 rounded-full"
                    transition={{ duration: 0.5 }}
                  />
                </div>
                <p className="text-xs text-[#065F46] font-extrabold font-mono tracking-wider animate-pulse uppercase mt-1">
                  {hatchingStatus}
                </p>
              </div>

              <div className="text-xs bg-[#F0F7F0]/80 p-4 border rounded-2xl italic font-semibold text-[#047857]/90 max-w-xs leading-relaxed">
                "Cahaya klorofil mulai berkilau di retakan telur. Eco-Guardian-mu menyerap profil saving usahamu!"
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Profil & Alamat Modal */}
      <AnimatePresence>
        {isProfileEditOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" id="edit-profile-modal-overlay">
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-white rounded-[45px] border-4 border-[#10B981] p-6 sm:p-10 max-w-2xl w-full shadow-2xl relative overflow-y-auto max-h-[90vh] space-y-6 text-[#1A3C34]"
            >
              {/* Close Button */}
              <button
                onClick={() => setIsProfileEditOpen(false)}
                className="absolute top-4 right-4 w-9 h-9 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full flex items-center justify-center font-bold text-xs cursor-pointer transition-colors"
              >
                ✕
              </button>

              <div className="text-center space-y-2">
                <div className="w-14 h-14 bg-[#10B981] text-white rounded-2xl flex items-center justify-center shadow-lg shadow-[#10b98122] mx-auto rotate-3">
                  <User className="w-7 h-7" />
                </div>
                <h2 className="text-2xl font-black text-[#1A3C34] tracking-tight">Informasi Akun Saya 🌱</h2>
                <p className="text-xs text-emerald-800/80 font-medium max-w-md mx-auto leading-relaxed">
                  Perbarui nama panggilan, alamat GPS, serta foto profil Anda untuk interaksi barter terdekat.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                {/* Form Fields Section */}
                <div className="space-y-4 text-left">
                  <span className="text-[10px] font-black uppercase text-[#10B981] tracking-wider block">1. Biodata Saya</span>

                  {/* Name */}
                  <div className="space-y-1.5 font-sans">
                    <label className="text-xs font-black text-slate-700 block">Nama Lengkap / Ranger:</label>
                    <input
                      type="text"
                      value={editProfileName}
                      onChange={(e) => setEditProfileName(e.target.value)}
                      maxLength={18}
                      placeholder="Masukkan nama Anda..."
                      className="w-full px-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                    />
                  </div>

                  {/* Gender Selector */}
                  <div className="space-y-1.5 font-sans">
                    <label className="text-xs font-black text-slate-700 block text-left">Jenis Kelamin:</label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setEditProfileGender('Laki-laki')}
                        className={`py-2.5 px-4 rounded-xl border-2 text-[11px] font-black tracking-wide uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          editProfileGender === 'Laki-laki'
                            ? 'bg-emerald-500 text-white border-emerald-600 shadow-md'
                            : 'bg-[#F4F9F4] text-slate-700 border-[#E2F0E2] hover:border-[#10B981]/50'
                        }`}
                      >
                        👦 Laki-laki
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditProfileGender('Perempuan')}
                        className={`py-2.5 px-4 rounded-xl border-2 text-[11px] font-black tracking-wide uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                          editProfileGender === 'Perempuan'
                            ? 'bg-emerald-500 text-white border-emerald-600 shadow-md'
                            : 'bg-[#F4F9F4] text-slate-700 border-[#E2F0E2] hover:border-[#10B981]/50'
                        }`}
                      >
                        👧 Perempuan
                      </button>
                    </div>
                  </div>

                  {/* Complete Address */}
                  <div className="space-y-1.5 font-sans">
                    <label className="text-xs font-black text-slate-700 block">Alamat Lengkap Rumah (GPS):</label>
                    <div className="relative">
                      <input
                        type="text"
                        value={editProfileAddress}
                        onChange={(e) => setEditProfileAddress(e.target.value)}
                        placeholder="Contoh: Jl. Puti Anggrek No. 12, Surabaya"
                        className="w-full pl-9 pr-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                      />
                      <MapPin className="w-4 h-4 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    </div>
                  </div>

                  {/* Region / Kelurahan */}
                  <div className="space-y-1.5 font-sans">
                    <label className="text-xs font-black text-slate-700 block">Rukun Tetangga / Daerah:</label>
                    <input
                      type="text"
                      value={editProfileNeighborhood}
                      onChange={(e) => setEditProfileNeighborhood(e.target.value)}
                      placeholder="Contoh: Gubeng Hijau"
                      className="w-full px-4 py-3 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all"
                    />
                  </div>

                  {/* Password Input to Check/Edit Own Account Password */}
                  <div className="space-y-1.5 font-sans">
                    <label className="text-xs font-black text-slate-700 block">Password Akun (Untuk Login Warga):</label>
                    <div className="relative">
                      <input
                        type={showEditPassword ? "text" : "password"}
                        value={editProfilePassword}
                        onChange={(e) => setEditProfilePassword(e.target.value)}
                        placeholder="Masukkan password baru..."
                        className="w-full px-4 py-3 pr-24 text-xs bg-[#F4F9F4] border-2 border-[#E2F0E2] rounded-2xl focus:border-[#10B981] focus:outline-none font-bold text-[#1A3C34] transition-all font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowEditPassword(prev => !prev)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[10px] font-black uppercase text-emerald-700 hover:text-emerald-900 transition-colors cursor-pointer"
                      >
                        {showEditPassword ? "Sembunyikan" : "Tampilkan"}
                      </button>
                    </div>
                    <span className="text-[9px] text-[#065F46] block font-semibold leading-normal">
                      *Tanggulangi kehilangan akses dengan memeriksa password di sini secara aman.
                    </span>
                  </div>
                </div>

                {/* Avatar Preset Section */}
                <div className="space-y-4 text-left">
                  <span className="text-[10px] font-black uppercase text-[#10B981] tracking-wider block">2. Ubah Avatar Tumbuhan</span>

                  {/* Avatar presets selection */}
                  <div className="grid grid-cols-2 gap-3.5">
                    {PLANT_AVATARS.map((avatarItem) => (
                      <button
                        key={avatarItem.url}
                        type="button"
                        onClick={() => setEditProfileAvatar(avatarItem.url)}
                        className={`p-2 rounded-2xl bg-white border-2 text-center transition-all cursor-pointer relative group flex flex-col items-center gap-1 ${
                          editProfileAvatar === avatarItem.url
                            ? "border-[#10B981] ring-2 ring-[#ECFDF5] shadow-lg"
                            : "border-[#E2F0E2] hover:border-[#10B981]/50"
                        }`}
                      >
                        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-[#E2F0E2] bg-[#F4F9F4]">
                          <img src={avatarItem.url} alt={avatarItem.label} referrerPolicy="no-referrer" className="w-full h-full object-cover animate-pulse" />
                        </div>
                        <span className="text-[9px] font-sans font-black text-slate-700 block leading-tight">{avatarItem.label}</span>
                      </button>
                    ))}
                  </div>

                  {/* Folder File Drag and Drop / Upload */}
                  <div className="p-3 bg-emerald-50/50 rounded-2xl border-2 border-dashed border-[#10B981]/30 text-center relative group hover:bg-emerald-50 transition-all cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      id="edit-profile-avatar-upload"
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            if (typeof reader.result === 'string') {
                              setEditProfileAvatar(reader.result);
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                    <div className="flex flex-col items-center gap-1">
                      <Upload className="w-5 h-5 text-[#10B981] group-hover:scale-110 transition-transform" />
                      <span className="text-[11px] font-black text-emerald-800 font-sans">Geser (Drag) atau Upload Foto</span>
                      <span className="text-[9px] text-[#065F46] font-bold font-sans">Format gambar bebas langsung dimuat</span>
                    </div>
                  </div>

                  {/* Display custom preview if uploaded */}
                  {editProfileAvatar && !PLANT_AVATARS.map(item => item.url).includes(editProfileAvatar) && (
                    <div className="flex items-center gap-3 bg-emerald-50 p-2.5 rounded-2xl border border-[#D1FAE5]">
                      <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-[#10B981] shadow-sm">
                        <img src={editProfileAvatar} className="w-full h-full object-cover" referrerPolicy="no-referrer" alt="Uploaded Preview" />
                      </div>
                      <div className="text-left">
                        <span className="text-[10px] font-black text-[#1A3C34] block">🍀 Foto Berhasil Dimuat!</span>
                        <span className="text-[9px] text-emerald-700/80 font-medium block">Telah terpasang siap disimpan</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Rows */}
              <div className="flex gap-4 pt-4 border-t border-[#E2F0E2]">
                <button
                  type="button"
                  onClick={() => setIsProfileEditOpen(false)}
                  className="flex-1 py-3.5 bg-slate-100 hover:bg-slate-200 text-[#1A3C34] hover:text-black font-black rounded-2xl transition-all cursor-pointer uppercase text-xs tracking-wider"
                >
                  Batal / Kembali
                </button>
                <button
                  type="button"
                  onClick={handleUpdateProfile}
                  className="flex-1 py-3.5 bg-[#10B981] hover:bg-[#059669] text-white border-b-4 border-[#065F46] font-black rounded-2xl transition-all shadow-md uppercase text-xs tracking-wider cursor-pointer"
                >
                  Simpan Perubahan 💾
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Custom Reset Akun Confirmation Modal (Secure & Anti Sandbox Iframe bugs) */}
      <AnimatePresence>
        {showResetConfirmationModal && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" id="reset-account-prompt-overlay">
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-white rounded-[40px] border-4 border-red-500 p-8 max-w-md w-full shadow-2xl relative space-y-6 text-[#1A3C34] text-center"
            >
              <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto border-2 border-red-300 animate-pulse text-2xl">
                ⚠️
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-black text-red-600 tracking-tight">Hapus & Reset Akun Warga?</h3>
                <p className="text-xs text-red-800 font-extrabold uppercase tracking-wide">Tindakan ini tidak dapat dibatalkan</p>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  Apakah Anda yakin ingin menghapus akun dan mengulang dari awal? Seluruh progress rawatan monster <strong>Eco-Guardian</strong>, sediaan sampah, koin Token, dan riwayat pertukaran barter bertetangga akan dihapus permanen dari browser ini.
                </p>
              </div>

              <div className="flex flex-col gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    localStorage.clear();
                    // Clear all actual state triggers in case standard frame reload is blocked
                    setProfile({
                      name: "",
                      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80",
                      neighborhood: "Jakarta",
                      address: "Jl. Puti Anggrek No. 25, Kel. Bubutan, Surabaya",
                      registered: false
                    });
                    setPet({
                      name: "Sprouty",
                      level: 1,
                      xp: 250,
                      maxXp: 1000,
                      hunger: 65,
                      cleanliness: 75,
                      happiness: 55,
                      evolutionStage: 'EGG'
                    });
                    setInventory({
                      PLASTIC: 1500,
                      PAPER: 1000,
                      ORGANIC: 800,
                      METAL_GLASS: 500,
                      SPECIAL_WASTE: 300,
                      ecoTokens: 250
                    });
                    setShowResetConfirmationModal(false);
                    setActiveTab('dashboard');
                    window.location.reload();
                  }}
                  className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white border-b-4 border-red-800 font-black rounded-2xl transition-all shadow-md uppercase text-xs tracking-wider cursor-pointer"
                >
                  Ya, Reset & Hapus Sekarang 💥
                </button>
                <button
                  type="button"
                  onClick={() => setShowResetConfirmationModal(false)}
                  className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-[#1A3C34] hover:text-black font-black rounded-2xl transition-all cursor-pointer uppercase text-xs tracking-wider"
                >
                  Batal / Kembali
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
