/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, DragEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  MapPin, 
  ArrowLeftRight, 
  Check, 
  Send, 
  Users, 
  AlertCircle, 
  Sparkles, 
  MessageCircle, 
  Info, 
  Upload, 
  Trash2, 
  Camera, 
  Scale, 
  Plus, 
  CheckCircle, 
  Clock, 
  Coins, 
  ChevronRight 
} from "lucide-react";
import { WasteCategory, Inventory, Neighbor, BarterListing, ChatMessage, WasteLog } from "../types";

interface BarterHubProps {
  inventory: Inventory;
  neighbors: Neighbor[];
  barterListings: BarterListing[];
  chatMessages: ChatMessage[];
  wasteLogs: WasteLog[];
  onExecuteBarter: (listingId: string) => void;
  onPostListing: (offered: WasteCategory, offeredAmt: number, wanted: string, desc: string) => void;
  onSendChatMessage: (text: string) => void;
  onAddWaste: (category: WasteCategory, weightGrams: number, points: number, mode: 'STORE' | 'DEPOSIT') => void;
}

const CATEGORY_NAMES = {
  PLASTIC: "Plastik",
  PAPER: "Kertas/Kardus",
  ORGANIC: "Organik",
  METAL_GLASS: "Logam/Kaca",
  SPECIAL_WASTE: "Jelantah/E-Waste"
};

const CATEGORY_DETAILS = {
  PLASTIC: {
    label: "Botol & Wadah Plastik",
    icon: "🥤",
    desc: "Botol air mineral, botol detergen, wadah makanan (PET/HDPE)",
    pointsPerKg: 100,
    color: "bg-emerald-50 text-emerald-700 border-emerald-200"
  },
  PAPER: {
    label: "Kardus & Kertas Bekas",
    icon: "📦",
    desc: "Kardus coklat, kertas bekas kantor, koran, karton susu",
    pointsPerKg: 80,
    color: "bg-green-50 text-green-700 border-green-200"
  },
  ORGANIC: {
    label: "Sisa Sampah Organik",
    icon: "🍎",
    desc: "Sisa dapur, kulit buah, sisa sayuran, ampas kopi",
    pointsPerKg: 120,
    color: "bg-teal-50 text-teal-700 border-teal-200"
  },
  METAL_GLASS: {
    label: "Kaleng & Kaca Bekas",
    icon: "🥫",
    desc: "Kaleng alumunium, botol kaca marjan, toples selai",
    pointsPerKg: 150,
    color: "bg-emerald-100/50 text-emerald-800 border-emerald-300"
  },
  SPECIAL_WASTE: {
    label: "Minyak Jelantah & E-Waste",
    icon: "🔋",
    desc: "Minyak goreng bekas, baterai, bohlam, casing HP",
    pointsPerKg: 250,
    color: "bg-emerald-950/10 text-emerald-900 border-emerald-400"
  }
};

export default function BarterHub({
  inventory,
  neighbors,
  barterListings,
  chatMessages,
  wasteLogs,
  onExecuteBarter,
  onPostListing,
  onSendChatMessage,
  onAddWaste
}: BarterHubProps) {
  // We default to 'listings' (Bulletin Barter)
  const [activeTab, setActiveTab] = useState<'listings' | 'map' | 'chat'>('listings');
  
  // Custom State for detailed view of neighbor's barter bulletin listing
  const [selectedListingDetail, setSelectedListingDetail] = useState<BarterListing | null>(null);
  
  // States of the Scanner Sub-tab
  const [selectedCategory, setSelectedCategory] = useState<WasteCategory>("PLASTIC");
  const [weight, setWeight] = useState<number>(500); // grams default
  const [isDragging, setIsDragging] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<{
    detectedCategory: WasteCategory;
    confidence: number;
    estimatedWeight: number;
  } | null>(null);
  
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [loggedDetails, setLoggedDetails] = useState<{ weight: number; points: number; category: string; mode: 'STORE' | 'DEPOSIT' } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Statesfor neighbor selector, chat & maps
  const [selectedNeighbor, setSelectedNeighbor] = useState<Neighbor | null>(null);
  const [inputText, setInputText] = useState("");
  const [sidebarTab, setSidebarTab] = useState<'details' | 'chat'>('details');
  const [privateInputText, setPrivateInputText] = useState("");
  const [isTypingPrivate, setIsTypingPrivate] = useState<string | null>(null);

  const [directChatsByNeighbor, setDirectChatsByNeighbor] = useState<Record<string, { id: string; sender: 'user' | 'neighbor'; text: string; timestamp: string }[]>>({
    "bu-retno": [
      { id: "br-1", sender: "neighbor", text: "Halo de'! Senang sekali kamu berkunjung ke rumah Ibu lewat peta. Kebetulan Ibu butuh botol plastik bersih untuk wadah semai cabai di kebun RT. Ada stok?", timestamp: "11:00" }
    ],
    "kak-agus": [
      { id: "ka-1", sender: "neighbor", text: "Yo bro! Lagi kumpulin kardus keras bekas kemasan sereal sama susu nih buat kerajinan anak-anak. Mau ditukar bibit istimewa?", timestamp: "11:05" }
    ],
    "dek-susi": [
      { id: "ds-1", sender: "neighbor", text: "Halo kak Eco-Ranger! Aku lagi kumpulin kaleng soda alumunium bekas marjan biar ga mencemari got perumahan kita nih. Sini barter!", timestamp: "11:10" }
    ],
    "pak-budi": [
      { id: "pb-1", sender: "neighbor", text: "Assalamu'alaikum nak, minyak jelantah bekas dari dapur istri tolong dikumpulkan ya. Bapak saring untuk jadi lilin daur ulang warga.", timestamp: "11:12" }
    ]
  });

  // Calculate potential immediate points
  const calculatePoints = (cat: WasteCategory, wtGrams: number) => {
    const pointsPerGram = CATEGORY_DETAILS[cat].pointsPerKg / 1000;
    return Math.round(wtGrams * pointsPerGram);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processMockFile(e.dataTransfer.files[0]);
    }
  };

  const processMockFile = (file: File) => {
    setIsAnalyzing(true);
    setAiAnalysisResult(null);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    setTimeout(() => {
      setIsAnalyzing(false);
      const categories: WasteCategory[] = ["PLASTIC", "PAPER", "ORGANIC", "METAL_GLASS", "SPECIAL_WASTE"];
      const detected = categories[Math.floor(Math.random() * categories.length)];
      const randomWeight = Math.round((Math.random() * 1200 + 150) / 100) * 100;

      setSelectedCategory(detected);
      setWeight(randomWeight);

      setAiAnalysisResult({
        detectedCategory: detected,
        confidence: Math.round(88 + Math.random() * 11),
        estimatedWeight: randomWeight
      });
    }, 1200);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processMockFile(e.target.files[0]);
    }
  };

  const handleResetImage = () => {
    setPreviewImage(null);
    setAiAnalysisResult(null);
  };

  // Processing logged waste with two deliberate outcomes
  const handleProcessWaste = (mode: 'STORE' | 'DEPOSIT') => {
    const finalPoints = calculatePoints(selectedCategory, weight);
    onAddWaste(selectedCategory, weight, finalPoints, mode);

    setLoggedDetails({
      weight: weight,
      points: finalPoints,
      category: CATEGORY_DETAILS[selectedCategory].label,
      mode: mode
    });

    setShowSuccessToast(true);
    handleResetImage();

    setTimeout(() => {
      setShowSuccessToast(false);
      setLoggedDetails(null);
    }, 4500);
  };

  // Direct mock replies for personal chats
  const handleSendPrivateMessage = (neighborId: string) => {
    if (!privateInputText.trim()) return;
    
    const textToSend = privateInputText;
    setPrivateInputText("");
    
    const newMsg = {
      id: `pmsg-${Date.now()}`,
      sender: "user" as const,
      text: textToSend,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    };
    
    setDirectChatsByNeighbor(prev => ({
      ...prev,
      [neighborId]: [...(prev[neighborId] || []), newMsg]
    }));
    
    setIsTypingPrivate(neighborId);
    
    setTimeout(() => {
      setIsTypingPrivate(null);
      let replyText = "Siap nak! Datang aja langsung ke rumah ya.";
      
      if (neighborId === "bu-retno") {
        const replies = [
          "Kompos Ibu terbuat dari daun kering jati RT, dijamin menyuburkan tanaman hias pekaranganmu nak.",
          "Cuci bersih dulu ya botol plastiknya nak agar benih Ibu tidak berjamur.",
          "Ibu standby di teras rumah koq. Sambil siram kangkung hidroponik Ibu.",
          "Terima kasih kepeduliannya ya nak. Anak muda panutan rukun tetangga."
        ];
        replyText = replies[Math.floor(Math.random() * replies.length)];
      } else if (neighborId === "kak-agus") {
        const replies = [
          "Mantap bro! Nanti bibit Super Eco-Seeds nya bisa dipakai langsung biar monstermu makin kuat.",
          "Kardusnya usahakan dilipat rapi ya bro biar gampang kakak tumpuk di gudang.",
          "Kreativitas pilah sampah gini nih yang bikin RT kita paling hijau sekecamatan!",
          "Siap bro, ntar malem kita sambil ngopi depan teras."
        ];
        replyText = replies[Math.floor(Math.random() * replies.length)];
      } else if (neighborId === "dek-susi") {
        const replies = [
          "Asyik! Karakter Eco-Guardian kakak level berapa nih sekarang? Pasti sudah gede ya.",
          "Kaleng alumuniumnya penyetkan dulu ya kak biar ntar muat masuk tas sekolahku.",
          "Tokennya bisa ditukar lho di Bulletin Warga. Semangat menyelamatkan lingkungan kak!",
          "Terima kasih banyak ya Kak Ranger!"
        ];
        replyText = replies[Math.floor(Math.random() * replies.length)];
      } else if (neighborId === "pak-budi") {
        const replies = [
          "Minyak jelantahnya bapak olah jadi lilin ramah lingkungan buat disumbangkan ke pos ronda, nak.",
          "Jangan sekali-sekali dibuang ke selokan ya, selain bikin mampet juga mencemari aliran air tanah.",
          "Wa'alaikumussalam nak. Silakan mampir saja, gerbang bapak tidak pernah dikunci.",
          "Alhamdulillah, terima kasih banyak ya nak sudah menjaga kelestarian kelurahan kita."
        ];
        replyText = replies[Math.floor(Math.random() * replies.length)];
      }
      
      const replyMsg = {
        id: `pmsg-${Date.now() + 1}`,
        sender: "neighbor" as const,
        text: replyText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      };
      
      setDirectChatsByNeighbor(prev => ({
        ...prev,
        [neighborId]: [...(prev[neighborId] || []), replyMsg]
      }));
    }, 1500);
  };

  // Custom barter listing posting form state
  const [showPostModal, setShowPostModal] = useState(false);
  const [postOffered, setPostOffered] = useState<WasteCategory>("PLASTIC");
  const [postOfferedAmt, setPostOfferedAmt] = useState<number>(1000); // grams
  const [postWanted, setPostWanted] = useState("");
  const [postDesc, setPostDesc] = useState("");
  const [postError, setPostError] = useState("");

  const handlePostListingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postWanted.trim()) {
      setPostError("Silakan isi apa yang kamu butuhkan!");
      return;
    }
    
    // Check if player actually has enough food in household inventory to post
    const currentInventoryWeight = inventory[postOffered];
    if (currentInventoryWeight < postOfferedAmt) {
      setPostError(`Stok ${CATEGORY_NAMES[postOffered]} di Gudangmu kurang! Kamu hanya punya ${(currentInventoryWeight/1000).toFixed(1)} Kg.`);
      return;
    }

    onPostListing(postOffered, postOfferedAmt, postWanted, postDesc);
    setShowPostModal(false);
    setPostOffered("PLASTIC");
    setPostOfferedAmt(1000);
    setPostWanted("");
    setPostDesc("");
    setPostError("");
  };

  const handleClaimBarter = (listing: BarterListing) => {
    if (listing.ownerId === "player") return;

    if (listing.wantedCategory !== 'REWARD_ITEM') {
      const cat = listing.wantedCategory as WasteCategory;
      let reqGrams = 500;
      const match = listing.wantedAmount.toLowerCase().match(/([\d.]+)\s*(kg|g|gr)/);
      if (match) {
        const amt = parseFloat(match[1]);
        const unit = match[2];
        reqGrams = unit.startsWith('k') ? amt * 1000 : amt;
      }

      if (inventory[cat] < reqGrams) {
        alert(`Batal Tukar: Stok Kamu Kurang! Tetangga meminta ${(reqGrams/1000).toFixed(1)}kg ${CATEGORY_NAMES[cat]}, sedangkan stok gudangmu hanya ${(inventory[cat]/1000).toFixed(1)}kg.`);
        return;
      }
    }

    onExecuteBarter(listing.id);
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;
    onSendChatMessage(inputText);
    setInputText("");
  };

  const hasEnoughInventory = (listing: BarterListing) => {
    if (listing.wantedCategory === 'REWARD_ITEM') return true;
    const cat = listing.wantedCategory as WasteCategory;
    let reqGrams = 500;
    const match = listing.wantedAmount.toLowerCase().match(/([\d.]+)\s*(kg|g|gr)/);
    if (match) {
      const amt = parseFloat(match[1]);
      const unit = match[2];
      reqGrams = unit.startsWith('k') ? amt * 1000 : amt;
    }
    return inventory[cat] >= reqGrams;
  };

  return (
    <div className="space-y-6 animate-fade-in" id="barter-hub-panel">
      {/* Toast Notification */}
      <AnimatePresence>
        {showSuccessToast && loggedDetails && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed top-24 left-12 right-12 md:left-auto md:right-6 md:w-96 bg-white border-4 border-[#10B981] rounded-[32px] shadow-2xl p-5 flex items-start gap-4.5 z-50"
            id="toast-waste-success"
          >
            <div className="bg-[#ECFDF5] p-2.5 rounded-2xl text-[#10B981] border border-[#D1FAE5] shrink-0">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-extrabold text-[#1A3C34]">Sukses Mengelola Sampah!</h4>
              <p className="text-xs text-[#1A3C34]/95 mt-1 leading-relaxed">
                Tindakan: <strong className="text-emerald-800 tracking-wide">{loggedDetails.mode === 'DEPOSIT' ? "Disetorkan Langsung 🏦" : "Disimpan di Gudang Rumah 📦"}</strong>
                <br />
                Sebanyak <strong className="text-[#10B981] font-black">{loggedDetails.weight}g {loggedDetails.category}</strong>.
              </p>
              {loggedDetails.mode === 'DEPOSIT' ? (
                <div className="mt-2.5 flex items-center gap-1.5 text-[10px] font-black text-[#10B981] bg-[#ECFDF5] px-3 py-1 rounded-full w-fit border border-[#D1FAE5]">
                  <Sparkles className="w-3 h-3 text-[#10B981]" /> +{loggedDetails.points} Eco-Token & Pet EXP diperoleh!
                </div>
              ) : (
                <div className="mt-2.5 flex items-center gap-1 text-[10px] font-black text-amber-800 bg-amber-50 px-3 py-1 rounded-full w-fit border border-amber-200">
                  📦 Siap ditukar (barter) untuk hadiah melimpah!
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Unified Mode Switcher Header */}
      <div className="bg-white rounded-[32px] border-4 border-[#E2F0E2] p-6 flex flex-col items-center justify-center text-center gap-5 shadow-sm">
        {/* Tab Controls */}
        <div className="flex border-2 border-[#E2F0E2] bg-[#F4F9F4]/40 p-1 rounded-2xl w-full sm:w-auto overflow-x-auto justify-center">
          <button
            type="button"
            onClick={() => setActiveTab('listings')}
            className={`px-5 py-2.5 text-[11px] font-black uppercase rounded-xl transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'listings'
                ? "bg-[#10B981] text-white shadow"
                : "text-[#065F46] hover:bg-emerald-50"
            }`}
          >
            <ArrowLeftRight className="w-3.5 h-3.5 stroke-[3px]" /> Bulletin Barter
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('map')}
            className={`px-5 py-2.5 text-[11px] font-black uppercase rounded-xl transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'map'
                ? "bg-[#10B981] text-white shadow"
                : "text-[#065F46] hover:bg-emerald-50"
            }`}
          >
            <MapPin className="w-3.5 h-3.5 stroke-[3px]" /> Peta Tetangga
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('chat')}
            className={`px-5 py-2.5 text-[11px] font-black uppercase rounded-xl transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer ${
              activeTab === 'chat'
                ? "bg-[#10B981] text-white shadow"
                : "text-[#065F46] hover:bg-emerald-50"
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5 stroke-[3px]" /> Chat Forum
          </button>
        </div>
      </div>

      {/* RENDER THE SEL      {/* SUB-TAB B: BULLETIN BARTER */}
      {activeTab === 'listings' && (
        <div className="space-y-6" id="listings-sub-view">
          {/* Welcome Banner and Action header */}
          <div className="bg-gradient-to-br from-[#10B981] to-emerald-700 text-white rounded-3xl p-6 shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-left border-2 border-emerald-800">
            <div>
              <span className="bg-white/20 px-3 py-0.5 text-[9px] uppercase font-black rounded-full tracking-widest">
                Forum Pertukaran Kelurahan Hijau
              </span>
              <h3 className="text-lg font-black mt-1">Papan Bulletin Barter Seberang Jalan</h3>
              <p className="text-xs opacity-90 font-medium leading-relaxed mt-1">
                Butuh bahan daur ulang dari tetangga? Atau punya botol plastik berlebih untuk ditukar dengan kompos murni tanaman hias? 
                Eksplorasi tawaran rukun tetangga di bawah ini!
              </p>
            </div>
            
            <button
              onClick={() => {
                setPostError("");
                setShowPostModal(true);
              }}
              className="py-3 px-5 bg-white text-[#10B981] hover:bg-emerald-50 rounded-2xl text-xs font-black uppercase shadow-lg transition-transform hover:scale-103 shrink-0 cursor-pointer"
            >
              ➕ Pasang Tawaran Barter Saya
            </button>
          </div>

          {/* Horizontal Gudang Penampungan */}
          <div className="bg-emerald-50/50 p-4.5 border-4 border-[#E2F0E2] rounded-[32px] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-left">
            <div>
              <span className="text-[10px] font-black text-emerald-800 uppercase tracking-widest block">Gudang Penyimpanan Rumah Tanggamu 🏢</span>
              <p className="text-[11px] text-[#1A3C34] font-medium leading-tight mt-0.5">Stok sampah aktual yang saat ini tersimpan di rumahmu dan siap dibarter:</p>
            </div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="bg-white px-3 py-1.5 border-2 border-[#E2F0E2] rounded-xl text-xs font-black text-[#1A3C34] flex items-center gap-1 shadow-sm">
                <span>🥤 Plastik:</span>
                <span className="font-mono text-emerald-700">{(inventory.PLASTIC/1000).toFixed(1)} Kg</span>
              </div>
              <div className="bg-white px-3 py-1.5 border-2 border-[#E2F0E2] rounded-xl text-xs font-black text-[#1A3C34] flex items-center gap-1 shadow-sm">
                <span>📦 Kertas:</span>
                <span className="font-mono text-emerald-700">{(inventory.PAPER/1000).toFixed(1)} Kg</span>
              </div>
              <div className="bg-white px-3 py-1.5 border-2 border-[#E2F0E2] rounded-xl text-xs font-black text-[#1A3C34] flex items-center gap-1 shadow-sm">
                <span>🍎 Organik:</span>
                <span className="font-mono text-emerald-700">{(inventory.ORGANIC/1000).toFixed(1)} Kg</span>
              </div>
              <div className="bg-white px-3 py-1.5 border-2 border-[#E2F0E2] rounded-xl text-xs font-black text-[#1A3C34] flex items-center gap-1 shadow-sm">
                <span>🥫 Logam/Kaca:</span>
                <span className="font-mono text-emerald-700">{(inventory.METAL_GLASS/1000).toFixed(1)} Kg</span>
              </div>
              <div className="bg-white px-3 py-1.5 border-2 border-[#E2F0E2] rounded-xl text-xs font-black text-[#1A3C34] flex items-center gap-1 shadow-sm">
                <span>🔋 Khusus:</span>
                <span className="font-mono text-emerald-700">{(inventory.SPECIAL_WASTE/1000).toFixed(1)} Kg</span>
              </div>
            </div>
          </div>

          {/* Active Listings Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {barterListings.map((listing) => {
              const categoryDetails = listing.wantedCategory === 'REWARD_ITEM' 
                ? null 
                : CATEGORY_DETAILS[listing.wantedCategory as WasteCategory];
              
              const isClaimed = listing.status === 'COMPLETED';
              const ownsListing = listing.ownerId === "player";
              const matchesStash = hasEnoughInventory(listing);

              return (
                <div 
                  key={listing.id}
                  className={`bg-white rounded-[40px] border-4 p-6 text-left flex flex-col justify-between gap-4 transition-all relative overflow-hidden ${
                    isClaimed 
                      ? "border-slate-100 opacity-60" 
                      : ownsListing 
                      ? "border-[#10B981]/50 bg-emerald-50/10 shadow shadow-emerald-100" 
                      : "border-[#E2F0E2] hover:border-[#10B981] hover:shadow-lg hover:shadow-[#00000003]"
                  }`}
                >
                  {/* Watermark of Completed */}
                  {isClaimed && (
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rotate-12 z-10 bg-slate-100 border-4 border-slate-300 text-slate-500 text-xs font-black uppercase tracking-widest px-4 py-2 rounded-2xl shadow-md">
                      ✓ Barter Sukses
                    </div>
                  )}

                  {/* Header Owner Row */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-full border-2 border-emerald-300 overflow-hidden bg-white">
                        <img src={listing.ownerAvatar} alt={listing.ownerName} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <span className="font-extrabold text-xs text-[#1A3C34] block leading-none">{listing.ownerName}</span>
                        <span className="text-[9px] text-slate-400 block mt-0.5 font-semibold uppercase">
                          {listing.ownerId === "player" ? "Eco-Ranger" : (neighbors.find(n => n.id === listing.ownerId)?.role || "Warga Kelurahan Hijau")}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[8px] font-mono font-bold text-slate-400 block bg-slate-50 px-2 py-0.5 rounded-md border">
                        ID: {listing.id}
                      </span>
                    </div>
                  </div>

                  {/* The Trade Detail logic */}
                  <div className="bg-[#F4F9F4] rounded-2xl p-4.5 border border-[#E2F0E2]/80 space-y-3">
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <div className="space-y-0.5 text-left">
                        <span className="text-[8px] font-black uppercase text-slate-400 block">Menawarkan:</span>
                        <span className="font-extrabold text-[#1A3C34] text-xs leading-none">
                          {listing.offeredCategory === 'REWARD_ITEM' ? listing.offeredItem : (CATEGORY_NAMES[listing.offeredCategory as WasteCategory] || listing.offeredItem)}
                        </span>
                        <span className="text-[10px] text-slate-500 block">Jumlah: {listing.offeredAmount}</span>
                      </div>
                      <div className="text-emerald-700 font-extrabold">➔</div>
                      <div className="space-y-0.5 text-right">
                        <span className="text-[8px] font-black uppercase text-slate-400 block">Kebutuhan:</span>
                        <span className="font-extrabold text-emerald-800 text-xs block leading-none">{listing.wantedItem}</span>
                        <span className="text-[10px] text-[#10B981] font-mono font-bold block">{listing.wantedAmount}</span>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-600 leading-relaxed italic border-t pt-2 border-slate-100">
                      "{listing.description}"
                    </p>
                  </div>

                  {/* Claim and validation Controls */}
                  <div className="flex items-center justify-between border-t pt-3 border-slate-100 mt-2">
                    <div className="text-left">
                      <span className="text-[9px] font-black uppercase text-[#10B981] block">Pangkat Pet EXP:</span>
                      <span className="text-xs font-black text-emerald-950 font-mono">+150 EXP</span>
                    </div>

                    {ownsListing ? (
                      <span className="text-[9px] text-[#059669] font-black uppercase bg-[#ECFDF5] px-3 py-1.5 border border-[#D1FAE5] rounded-xl">
                        Tawaran Milikmu 📦
                      </span>
                    ) : isClaimed ? (
                      <span className="text-[10px] text-slate-400 font-bold">Barter Terselesaikan</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setSelectedListingDetail(listing)}
                        className="px-4.5 py-2 bg-[#10B981] hover:bg-[#059669] text-white text-[10px] font-black uppercase rounded-xl border-b-2 border-emerald-700 transition-all cursor-pointer shadow-md"
                      >
                        Detail & Barter 🤝
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUB-TAB C: NEIGHBORHOOD MAP */}
      {activeTab === 'map' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="interactive-map-view">
          {/* Neighbors Map simulation map */}
          <div className="lg:col-span-8 bg-white rounded-[40px] p-6 md:p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] space-y-4 text-left">
            <div>
              <h3 className="font-black text-[#1A3C34] text-base flex items-center gap-1.5">
                <MapPin className="text-[#10B981] w-5 h-5" />
                Peta Sirkulasi Kelurahan Hijau
              </h3>
              <p className="text-xs text-[#065F46] font-medium leading-none mt-1">
                Klik pin lokasi hunian tetangga di bawah untuk melihat list penawaran barter pribadi & memulai negosiasi!
              </p>
            </div>

            {/* Map board body */}
            <div className="w-full overflow-x-auto rounded-[32px] border-4 border-[#E2F0E2] shadow-inner bg-[#F4F9F4]" id="map-scroll-container">
              <div className="relative bg-[#F4F9F4] h-80 min-w-[620px] w-full overflow-hidden flex items-center justify-center select-none">
                <div className="absolute inset-0 opacity-15 pointer-events-none" style={{
                  backgroundImage: 'radial-gradient(#10B981 1.2px, transparent 1.2px)',
                  backgroundSize: '24px 24px'
                }} />
                
                <div className="absolute top-[38%] left-[5%] right-[5%] h-2.5 bg-sky-200/40 -rotate-12 border-y border-sky-300/20" /> {/* River */}
                <div className="absolute top-[20%] bottom-[20%] left-[48%] w-5 bg-stone-200/70 shadow-inner" /> {/* Road */}

                {/* Player Base Center */}
                <motion.button
                  onClick={() => alert("Ini Rumah Anda (Eco-Guardian Egg/Baby Base). Temukan tetangga sekitar untuk mulai barter!")}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-20"
                  whileHover={{ scale: 1.08 }}
                >
                  <div className="bg-[#065F46] text-white border border-[#10b981] px-2.5 py-0.5 text-[9px] font-mono font-black rounded-full shadow-md flex items-center gap-1 mb-1 leading-none">
                    🏡 Base-ku
                  </div>
                  <div className="w-4 h-4 rounded-full bg-[#10B981] border-2 border-white animate-pulse" />
                </motion.button>

                {/* Neighbors Pins */}
                {neighbors.map((neighbor, index) => {
                  const coords = [
                    { top: '28%', left: '22%' },
                    { top: '22%', left: '72%' },
                    { top: '72%', left: '32%' },
                    { top: '65%', left: '78%' }
                  ];
                  const pos = coords[index] || { top: '35%', left: '35%' };

                  return (
                    <motion.button
                      key={neighbor.id}
                      onClick={() => {
                        setSelectedNeighbor(neighbor);
                        setSidebarTab('details');
                      }}
                      className="absolute flex flex-col items-center z-10 cursor-pointer"
                      style={{ top: pos.top, left: pos.left }}
                      whileHover={{ scale: 1.12, zIndex: 30 }}
                    >
                      <div className="bg-white text-[#1A3C34] border-2 border-[#E2F0E2] px-2.5 py-1 text-[9px] h-fit font-black rounded-xl shadow-lg whitespace-nowrap mb-1">
                        {neighbor.name} ({neighbor.role})
                      </div>
                      <div className="w-10 h-10 rounded-full border-[3px] border-[#10B981] overflow-hidden shadow-lg bg-white">
                        <img src={neighbor.avatar} alt={neighbor.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Radar list details sorted by proximity */}
            <div className="bg-[#F0F7F0]/40 rounded-[32px] p-5 border-4 border-dashed border-[#10B981]/30 text-left space-y-4">
              <div>
                <h4 className="font-black text-[#1A3C34] text-sm flex items-center gap-1">
                  📡 Radar Proksimitas (Tetangga Terdekat Anda)
                </h4>
                <p className="text-[11px] text-emerald-800 font-bold leading-normal">
                  Sistem GPS otomatis menyaring jarak paling hemat karbon untuk penukaran sampah antar rukun RT.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[...neighbors]
                  .sort((a, b) => a.distanceMeters - b.distanceMeters)
                  .map((neighbor) => {
                    const isSelected = selectedNeighbor?.id === neighbor.id;
                    return (
                      <div 
                        key={neighbor.id} 
                        onClick={() => {
                          setSelectedNeighbor(neighbor);
                          setSidebarTab('details');
                        }}
                        className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer flex items-center justify-between gap-3 ${
                          isSelected 
                            ? "bg-white border-[#10B981] shadow-md ring-2 ring-emerald-400/10"
                            : "bg-[#F4F9F4]/50 border-[#E2F0E2] hover:bg-white hover:border-[#10B981] hover:shadow-sm"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 text-left">
                          <div className="w-9 h-9 rounded-full overflow-hidden border-2 border-[#10B981] bg-white shrink-0">
                            <img src={neighbor.avatar} alt={neighbor.name} className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <span className="font-extrabold text-xs text-[#1A3C34] block leading-tight">{neighbor.name}</span>
                            <span className="text-[9px] text-[#059669] font-black uppercase block tracking-wider mt-0.5 leading-none">{neighbor.role}</span>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-black rounded-md uppercase tracking-wide border border-emerald-200">
                             📍 {neighbor.distanceMeters} M
                          </span>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>

          {/* Sidebar Area: Selected Neighbor Details */}
          <div className="lg:col-span-4 flex flex-col gap-4 text-left">
            <AnimatePresence mode="wait">
              {selectedNeighbor ? (
                <motion.div
                  key={selectedNeighbor.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-white rounded-[40px] p-6 border-4 border-[#10B981] shadow-2xl space-y-4"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={selectedNeighbor.avatar}
                      alt={selectedNeighbor.name}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-full border-2 border-[#E2F0E2] object-cover shrink-0"
                    />
                    <div>
                      <h4 className="font-black text-[#1A3C34] leading-tight text-sm">{selectedNeighbor.name}</h4>
                      <span className="text-[9.5px] font-black uppercase text-[#10B981] bg-[#ECFDF5] px-2 py-0.5 border border-[#D1FAE5] rounded-md inline-block mt-1">
                        {selectedNeighbor.role}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-2xl border flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[8px] font-black uppercase text-[#047857] block tracking-wide">Alamat Hunian:</span>
                      <span className="text-[11px] font-bold text-[#1A3C34] leading-tight block mt-0.5">
                        {selectedNeighbor.address}
                      </span>
                    </div>
                  </div>

                  {/* Sidebar Inner Toggle */}
                  <div className="flex border border-[#E2F0E2] bg-[#F4F9F4]/40 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setSidebarTab('details')}
                      className={`flex-1 py-1.5 text-[10px] font-black uppercase rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
                        sidebarTab === 'details'
                          ? "bg-[#10B981] text-white shadow-sm"
                          : "text-[#065F46] hover:bg-emerald-50"
                      }`}
                    >
                      🎁 Barter Info
                    </button>
                    <button
                      type="button"
                      onClick={() => setSidebarTab('chat')}
                      className={`flex-1 py-1.5 text-[10px] font-black uppercase rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
                        sidebarTab === 'chat'
                          ? "bg-[#10B981] text-white shadow-sm"
                          : "text-[#065F46] hover:bg-emerald-50"
                      }`}
                    >
                      💬 Private Chat
                    </button>
                  </div>

                  {sidebarTab === 'details' ? (
                    <div className="space-y-3.5 text-xs pt-1">
                      <div className="rounded-2xl bg-amber-50 p-3 border-2 border-amber-200">
                        <span className="text-[8px] font-black text-amber-800 uppercase tracking-widest block mb-1">
                          Imbalan Khusus Barter:
                        </span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xl">🌿</span>
                          <div>
                            <strong className="text-amber-900 block font-black leading-tight text-[11px]">{selectedNeighbor.rewardTitle}</strong>
                            <p className="text-[10px] text-amber-800 leading-normal mt-0.5">{selectedNeighbor.rewardDesc}</p>
                          </div>
                        </div>
                      </div>

                      <div className="p-3 bg-emerald-50/50 rounded-2xl border text-[10px] text-[#065F46] font-semibold leading-relaxed">
                        ✨ <strong>Hubungi via chat:</strong> Tekan tab "Private Chat" di atas untuk mengetik pesan pribadi langsung ke {selectedNeighbor.name} untuk janjian barter!
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3.5 pt-1">
                      {/* Direct dialogue screen */}
                      <div className="bg-[#F4F9F4] p-3 rounded-2xl h-44 overflow-y-auto space-y-2 border">
                        {(directChatsByNeighbor[selectedNeighbor.id] || []).map((msg) => (
                          <div 
                            key={msg.id} 
                            className={`flex flex-col max-w-[85%] rounded-2xl p-2.5 text-[11px] leading-relaxed text-left ${
                              msg.sender === 'user' 
                                ? "bg-[#10B981] text-white ml-auto rounded-tr-none" 
                                : "bg-white text-[#1A3C34] border rounded-tl-none mr-auto shadow-xs"
                            }`}
                          >
                            <p className="font-medium text-left leading-tight">{msg.text}</p>
                            <span className="text-[8px] opacity-60 mt-1 self-end">{msg.timestamp}</span>
                          </div>
                        ))}
                        {isTypingPrivate === selectedNeighbor.id && (
                          <span className="text-[9px] text-[#10B981] font-bold italic block text-left animate-pulse">Mengetik balasan...</span>
                        )}
                      </div>

                      <div className="flex gap-2.5">
                        <input
                          type="text"
                          value={privateInputText}
                          onChange={(e) => setPrivateInputText(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleSendPrivateMessage(selectedNeighbor.id);
                          }}
                          placeholder="Ketik rahasia..."
                          className="w-full bg-[#F4F9F4] text-xs font-bold px-3 py-2 border-2 border-[#E2F0E2] rounded-xl outline-none focus:border-[#10B981] placeholder:text-slate-300"
                        />
                        <button
                          type="button"
                          onClick={() => handleSendPrivateMessage(selectedNeighbor.id)}
                          className="px-4 py-2 bg-[#10B981] text-white rounded-xl text-xs font-black uppercase border-b-2 border-emerald-800"
                        >
                          Kirim
                        </button>
                      </div>
                    </div>
                  )}
                </motion.div>
              ) : (
                <div className="bg-[#F4F9F4]/60 border-2 border-dashed border-[#E2F0E2] rounded-[40px] p-10 text-center text-slate-400 italic text-xs flex flex-col justify-center h-48">
                  <span>🗺️ Klik salah satu hunian rukun warga di peta untuk interaksi klorofil!</span>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* SUB-TAB D: FORUM CHAT */}
      {activeTab === 'chat' && (
        <div className="bg-white rounded-[40px] border-4 border-[#E2F0E2] p-6 md:p-8 shadow-xl max-w-2xl mx-auto space-y-4" id="chat-sub-view">
          <div className="text-left border-b pb-3">
            <span className="bg-emerald-50 text-emerald-800 px-3 py-0.5 rounded-full uppercase tracking-wider text-[8px] font-black border border-emerald-200">
              Masyarakat Setia Kelurahan
            </span>
            <h3 className="font-extrabold text-sm mt-1 text-[#1A3C34] flex items-center gap-1.5">
              💬 Forum Diskusi & Bulletin Swadaya Hijau
            </h3>
            <p className="text-xs text-slate-400 leading-tight">Gunakan ruang obrolan warga rukun rukun tetangga untuk menyalurkan kampanye!</p>
          </div>

          <div className="bg-[#F4F9F4] p-4.5 rounded-3xl h-72 overflow-y-auto space-y-3 border">
            {chatMessages.map((msg) => {
              const isMe = msg.sender === 'user';
              const nameLabel = isMe ? "Saya" : msg.senderName;
              return (
                <div 
                  key={msg.id} 
                  className={`flex flex-col text-left max-w-[80%] rounded-2xl p-3 text-xs leading-relaxed ${
                    isMe 
                      ? "bg-[#10B981] text-white ml-auto rounded-tr-none" 
                      : "bg-white text-[#1A3C34] mr-auto rounded-tl-none border shadow-xs"
                  }`}
                >
                  <span className={`text-[8.5px] font-black uppercase tracking-wider block mb-1 ${isMe ? "text-emerald-100" : "text-[#10B981]"}`}>
                    {nameLabel}
                  </span>
                  <p className="font-medium text-left leading-relaxed">{msg.text}</p>
                </div>
              );
            })}
          </div>

          <div className="flex gap-3">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendMessage();
              }}
              placeholder="Sampaikan gagasan kelestarian ke para warga RT..."
              className="w-full bg-[#F4F9F4] text-xs font-bold px-4 py-3 border-2 border-[#E2F0E2] focus:border-[#10B981] rounded-2xl outline-none text-[#1a3c34] placeholder:text-slate-300"
            />
            <button
              onClick={handleSendMessage}
              className="py-3 px-6 bg-[#10B981] text-white font-black hover:bg-emerald-600 rounded-2xl font-mono border-b-4 border-emerald-800 text-xs text-center"
            >
              KIRIM
            </button>
          </div>
        </div>
      )}

      {/* POPUP POST BARTER MODAL FORM */}
      <AnimatePresence>
        {showPostModal && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-[40px] p-6 sm:p-8 max-w-md w-full border-4 border-[#10B981] shadow-2xl relative text-left"
            >
              <button
                onClick={() => setShowPostModal(false)}
                className="absolute top-4 right-4 w-8 h-8 bg-slate-100 hover:bg-gray-100 text-slate-500 rounded-full flex items-center justify-center font-bold text-xs"
              >
                ✕
              </button>

              <div className="border-b pb-3 mb-4">
                <span className="text-[9px] font-black text-[#10B981] uppercase block">Post New Trade Offer</span>
                <h3 className="font-black text-slate-800">Pasang Iklan Barter Baru</h3>
              </div>

              <form onSubmit={handlePostListingSubmit} className="space-y-4">
                {/* Offered Material */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-black uppercase text-[#065F46] block tracking-wider">Sampah Ditawarkan:</label>
                    <select
                      value={postOffered}
                      onChange={(e) => setPostOffered(e.target.value as WasteCategory)}
                      className="w-full bg-slate-50 border-2 border-[#E2F0E2] focus:border-[#10B981] px-3 py-2 text-xs font-bold rounded-xl outline-none"
                    >
                      {Object.entries(CATEGORY_NAMES).map(([key, label]) => (
                        <option key={key} value={key}>{label}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-black uppercase text-[#065F46] block tracking-wider">Berat Ditawarkan:</label>
                    <div className="flex items-center bg-slate-50 border-2 border-[#E2F0E2] px-3 rounded-xl text-xs font-bold focus-within:border-[#10B981]">
                      <input
                        type="number"
                        value={postOfferedAmt}
                        onChange={(e) => setPostOfferedAmt(parseInt(e.target.value) || 0)}
                        className="w-full py-2 bg-transparent outline-none"
                        min={10}
                      />
                      <span className="text-slate-400 font-mono text-[10px] pl-2">gr</span>
                    </div>
                  </div>
                </div>

                {/* Wanted description */}
                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] font-black uppercase text-[#065F46] block tracking-wider font-sans">Barang Yang Kamu Cari dari Tetangga:</label>
                  <input
                    type="text"
                    value={postWanted}
                    onChange={(e) => setPostWanted(e.target.value)}
                    placeholder="Contoh: 1 Kg Pupuk Organik Bu Retno / Bibit Kangkung"
                    className="w-full px-3 py-2.5 text-xs bg-slate-50 text-[#1A3C34] border-2 border-[#E2F0E2] focus:border-[#10B981] rounded-xl outline-none font-bold placeholder:text-slate-400"
                  />
                </div>

                {/* Description */}
                <div className="space-y-1.5 text-left">
                  <label className="text-[10px] font-black uppercase text-[#065F46] block tracking-wider">Pesan Tambahan:</label>
                  <textarea
                    value={postDesc}
                    onChange={(e) => setPostDesc(e.target.value)}
                    placeholder="Contoh: Plastik bekas botol sprite tebal, kering sudah dicuci..."
                    rows={2}
                    className="w-full px-3 py-2.5 text-xs bg-slate-50 text-[#1A3C34] border-2 border-[#E2F0E2] focus:border-[#10B981] rounded-xl outline-none font-bold placeholder:text-slate-400 resize-none"
                  />
                </div>

                {postError && (
                  <div className="p-3 bg-red-50 rounded-xl flex items-start gap-1.5 text-xs text-red-600 border-2 border-red-100 font-bold leading-normal">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                    <span>{postError}</span>
                  </div>
                )}

                <div className="flex gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowPostModal(false)}
                    className="flex-1 py-2.5 border-2 border-[#E2F0E2] hover:bg-gray-50 text-[#065F46] font-black rounded-xl text-[10px] uppercase cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-[#10B981] hover:bg-[#059669] text-white border-emerald-800 border-b-2 font-black rounded-xl text-[10px] uppercase cursor-pointer"
                  >
                    Pasang Barter
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {selectedListingDetail && (() => {
          const ownerNeighbor = neighbors.find(n => n.id === selectedListingDetail.ownerId);
          const ownerAddress = ownerNeighbor?.address || "Jl. Puti Anggrek, Kel. Bubutan, Surabaya";
          const matchesStash = hasEnoughInventory(selectedListingDetail);
          
          return (
            <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-white rounded-[40px] p-6 sm:p-8 max-w-lg w-full border-4 border-[#10B981] shadow-2xl relative text-left"
              >
                <button
                  onClick={() => setSelectedListingDetail(null)}
                  className="absolute top-4 right-4 w-8 h-8 bg-slate-100 hover:bg-gray-100 text-slate-500 rounded-full flex items-center justify-center font-bold text-xs cursor-pointer"
                >
                  ✕
                </button>

                {/* Neighbor Info Header */}
                <div className="flex items-center gap-4 border-b pb-4 mb-4">
                  <div className="w-14 h-14 rounded-2xl border-2 border-[#E2F0E2] overflow-hidden shadow-inner bg-white shrink-0">
                    <img src={selectedListingDetail.ownerAvatar} alt={selectedListingDetail.ownerName} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <span className="text-[9px] font-black text-[#10B981] uppercase tracking-wider block">Pasangan Barter</span>
                    <h3 className="font-black text-lg text-slate-800 leading-tight">{selectedListingDetail.ownerName}</h3>
                    <p className="text-xs text-[#065F46] font-bold mt-0.5">{ownerNeighbor?.role || "Warga Kelurahan Hijau"}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  {/* Detailed Location Address Info */}
                  <div className="bg-[#F4F9F4] p-4 rounded-2xl border border-[#E2F0E2] text-xs">
                    <h4 className="font-extrabold text-[#1A3C34] flex items-center gap-1.5 uppercase text-[10px] tracking-wider mb-1.5 text-emerald-800">
                      📍 Alamat Lengkap Tetangga:
                    </h4>
                    <p className="font-bold text-slate-700">{ownerAddress}</p>
                    <p className="text-[10px] text-slate-400 mt-1">Berjarak sekitar {ownerNeighbor?.distanceMeters || 150}m dari rumah Anda.</p>
                  </div>

                  {/* Proposed Exchange description */}
                  <div className="border border-slate-100 rounded-3xl p-4.5 space-y-3">
                    <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Tawaran & Kebutuhan:</h4>
                    <div className="bg-slate-50 p-3 rounded-2xl border flex items-center justify-between text-xs font-semibold gap-2">
                      <div className="text-left space-y-0.5 font-sans">
                        <span className="text-[8px] font-bold text-slate-400 block uppercase">Anda Dapat:</span>
                        <span className="font-black text-slate-800 block text-xs">
                          {selectedListingDetail.offeredCategory === 'REWARD_ITEM' 
                            ? selectedListingDetail.offeredItem 
                            : (CATEGORY_NAMES[selectedListingDetail.offeredCategory as WasteCategory] || selectedListingDetail.offeredItem)}
                        </span>
                        <span className="text-[10px] text-emerald-600 font-bold block">{selectedListingDetail.offeredAmount}</span>
                      </div>
                      <span className="text-2xl">🤝</span>
                      <div className="text-right space-y-0.5 font-sans">
                        <span className="text-[8px] font-bold text-slate-400 block uppercase">Anda Berikan:</span>
                        <span className="font-black text-slate-800 block text-xs">{selectedListingDetail.wantedItem}</span>
                        <span className="text-[11px] text-[#10B981] font-mono font-black block">{selectedListingDetail.wantedAmount}</span>
                      </div>
                    </div>
                    
                    <div className="text-xs text-slate-500 italic leading-relaxed pt-2 font-sans">
                      "{selectedListingDetail.description}"
                    </div>
                  </div>

                  {/* Stash Verification Status */}
                  <div className="bg-emerald-50/20 border-2 border-emerald-100 rounded-2xl p-4 flex items-center gap-3.5 text-xs">
                    <span className="text-xl">🎒</span>
                    <div>
                      {selectedListingDetail.wantedCategory !== 'REWARD_ITEM' ? (() => {
                        const cat = selectedListingDetail.wantedCategory as WasteCategory;
                        const currentAmt = inventory[cat] || 0;
                        return (
                          <>
                            <p className="font-bold text-[#1A3C34] font-sans">
                              Status Stokmu: <strong className="text-emerald-700 font-mono">{(currentAmt/1000).toFixed(1)} Kg {CATEGORY_NAMES[cat]}</strong>
                            </p>
                            <p className="text-[10px] text-slate-500 mt-0.5 font-sans">
                              {matchesStash 
                                ? "Persediaan sampahmu mencukupi! Kamu siap untuk barter sekarang." 
                                : `Persediaanmu belum cukup. Butuh ${selectedListingDetail.wantedAmount}, silakan catat/scan sampah dulu.`}
                            </p>
                          </>
                        );
                      })() : (
                        <>
                          <p className="font-bold text-[#1A3C34] font-sans">Barter Terbuka Bebas!</p>
                          <p className="text-[10px] text-slate-500 mt-0.5 font-sans">Tidak membutuhkan kategori limbah tertentu dari gudang rumah tangga Anda.</p>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Action row */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
                    {/* Private Chat button */}
                    <button
                      type="button"
                      onClick={() => {
                        if (ownerNeighbor) {
                          setSelectedNeighbor(ownerNeighbor);
                          setSidebarTab('chat');
                          setActiveTab('map');
                        } else {
                          setActiveTab('chat');
                        }
                        setSelectedListingDetail(null);
                      }}
                      className="py-3 px-4.5 bg-sky-600 hover:bg-sky-700 text-white font-black rounded-xl text-xs uppercase flex items-center justify-center gap-2 border-b-2 border-sky-800 transition-all cursor-pointer shadow-md"
                    >
                      <MessageCircle className="w-4 h-4 shrink-0" /> Kirim Chat Privat 💬
                    </button>

                    {/* Claim Barter button */}
                    <button
                      type="button"
                      disabled={!matchesStash}
                      onClick={() => {
                        handleClaimBarter(selectedListingDetail);
                        setSelectedListingDetail(null);
                      }}
                      className={`py-3 px-4.5 font-black uppercase rounded-xl border-b-2 text-xs flex items-center justify-center gap-2 transition-all ${
                        matchesStash 
                          ? "bg-[#10B981] hover:bg-[#059669] text-white border-emerald-700 cursor-pointer shadow"
                          : "bg-red-50 text-red-500 border-red-200 cursor-not-allowed leading-none font-sans"
                      }`}
                    >
                      {matchesStash ? (
                        <>🤝 Konfirmasi Barter</>
                      ) : (
                        <>Stok Kurang (Batal)</>
                      )}
                    </button>
                  </div>
                </div>
              </motion.div>
            </div>
          );
        })()}
      </AnimatePresence>
    </div>
  );
}
