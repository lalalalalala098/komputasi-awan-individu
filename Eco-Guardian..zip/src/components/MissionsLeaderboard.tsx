/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Heart, Trophy, Award, Gift, ChevronUp, Share2, Sparkles, Target, 
  Star, Building, X, Coins, DollarSign, Wallet, Phone, CheckCircle, 
  Clock, Truck, CreditCard, Copy 
} from "lucide-react";
import { CommunityMission, LeaderboardUser, Inventory, DonationPickup } from "../types";

interface MissionsLeaderboardProps {
  inventory: Inventory;
  missions: CommunityMission[];
  leaderboard: LeaderboardUser[];
  onDonateToMission: (missionId: string, donateGrams: number) => void;
  wallet: { method: 'GoPay' | 'OVO' | null; phone: string };
  onUpdateWallet: (method: 'GoPay' | 'OVO' | null, phone: string) => void;
  pickups: DonationPickup[];
  onUpdatePickups: React.Dispatch<React.SetStateAction<DonationPickup[]>> | ((val: DonationPickup[] | ((prev: DonationPickup[]) => DonationPickup[])) => void);
  onShareToChat?: (text: string) => void;
}

export default function MissionsLeaderboard({
  inventory,
  missions,
  leaderboard,
  onDonateToMission,
  wallet,
  onUpdateWallet,
  pickups,
  onUpdatePickups,
  onShareToChat
}: MissionsLeaderboardProps) {
  const [donateAmount, setDonateAmount] = useState<number>(500); // Default donation grams
  const [selectedMissionId, setSelectedMissionId] = useState<string | null>(null);

  const [walletModalOpen, setWalletModalOpen] = useState(false);
  const [tempWalletMethod, setTempWalletMethod] = useState<'GoPay' | 'OVO'>('GoPay');
  const [tempWalletPhone, setTempWalletPhone] = useState(wallet.phone || '');
  const [walletError, setWalletError] = useState('');

  // Interactive Extra states: Share Achievement Certificate
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [copiedText, setCopiedText] = useState(false);

  const selectedMission = missions.find(m => m.id === selectedMissionId) || null;

  // Derive player stats from the leaderboard data
  const mePlayer = leaderboard.find(u => u.id === "player");
  const playerName = mePlayer?.name || "Eco-Ranger Saya";
  const playerTotalGrams = mePlayer?.totalRecycledGrams || 0;
  
  // Calculate player rank
  const sortedLeaderboard = [...leaderboard].sort((a, b) => b.totalRecycledGrams - a.totalRecycledGrams);
  const playerRank = sortedLeaderboard.findIndex(u => u.id === "player") + 1 || 4;

  // Calculate dynamic balances
  const unclaimedPickups = pickups.filter(p => p.status === 'BELUM_DIKUMPULKAN');
  const totalUnclaimed = unclaimedPickups.reduce((acc, p) => acc + p.cashEarned, 0);

  const claimedPickups = pickups.filter(p => p.status === 'SUDAH_DIKUMPULKAN');
  const totalClaimed = claimedPickups.reduce((acc, p) => acc + p.cashEarned, 0);

  const handleDonateSubmit = (mission: CommunityMission) => {
    if (inventory[mission.category] <= 0) {
      alert("Stok Gagal Didonasikan: Gudang Anda masih kosong! Catat sampah terlebih dahulu.");
      return;
    }
    if (inventory[mission.category] < donateAmount) {
      alert(`Stok Gagal Didonasikan: Stok gudangmu (${(inventory[mission.category]/1000).toFixed(1)}kg) lebih kecil dari donasi yang diajukan (${(donateAmount/1000).toFixed(1)}kg).`);
      return;
    }
    if (!wallet.method) {
      setTempWalletPhone(wallet.phone || "");
      setWalletModalOpen(true);
      return;
    }
    
    onDonateToMission(mission.id, donateAmount);
  };

  const handleConnectWalletSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWalletError("");
    const formattedPhone = tempWalletPhone.trim();
    if (!formattedPhone) {
      setWalletError("No. HP tidak boleh kosong!");
      return;
    }
    if (!/^\+?[0-9]{9,15}$/.test(formattedPhone)) {
      setWalletError("Format No. HP salah! Gunakan angka saja (9-15 digit), contoh: 08123456789");
      return;
    }
    onUpdateWallet(tempWalletMethod, formattedPhone);
    setWalletModalOpen(false);
  };

  // Direct, high-speed instant claim handling
  const handleDirectClaim = (pickupId: string | null, isLumpSum: boolean) => {
    if (!wallet.method) {
      alert("🚨 Silakan hubungkan dompet digital Anda (GoPay/OVO) terlebih dahulu pada menu Hubungkan Akun!");
      setTempWalletPhone(wallet.phone || "");
      setWalletModalOpen(true);
      return;
    }

    if (onUpdatePickups) {
      const targetPickups = isLumpSum 
        ? pickups.filter(p => p.status === 'BELUM_DIKUMPULKAN')
        : pickups.filter(p => p.id === pickupId);

      if (targetPickups.length === 0) return;
      
      const claimedAmount = targetPickups.reduce((acc, p) => acc + p.cashEarned, 0);

      onUpdatePickups(prev => 
        prev.map(p => {
          if (isLumpSum) {
            return p.status === 'BELUM_DIKUMPULKAN' 
              ? { ...p, status: 'SUDAH_DIKUMPULKAN', paymentMethod: wallet.method, paymentPhone: wallet.phone } 
              : p;
          } else {
            return p.id === pickupId 
              ? { ...p, status: 'SUDAH_DIKUMPULKAN', paymentMethod: wallet.method, paymentPhone: wallet.phone } 
              : p;
          }
        })
      );
      
      alert(`🎉 Sukses! Saldo kompensasi senilai Rp ${claimedAmount.toLocaleString("id-ID")} berhasil dicairkan secara instan langsung ke akun ${wallet.method} (${wallet.phone}) milikmu!`);
    }
  };

  const getRankBadgeAndColor = (rank: number) => {
    switch (rank) {
      case 1:
        return {
          icon: "👑",
          label: "Platinum Guardian",
          color: "bg-yellow-50 border-yellow-200 text-yellow-800",
          stars: 5
        };
      case 2:
        return {
          icon: "🥈",
          label: "Gold Sprout",
          color: "bg-slate-50 border-slate-200 text-gray-700",
          stars: 4
        };
      case 3:
        return {
          icon: "🥉",
          label: "Silver Leaf",
          color: "bg-amber-50 border-amber-200 text-amber-900",
          stars: 3
        };
      default:
        return {
          icon: "🌱",
          label: "Eco Ranger",
          color: "bg-green-50 border-green-200 text-green-700",
          stars: 2
        };
    }
  };

  const handleCopyCertificateText = () => {
    const textToCopy = `🌱 Prestasi Pahlawan Sampah RT 05: Saya baru saja mendaur ulang ${(playerTotalGrams / 1000).toFixed(1)} Kg sampah rumah tangga dan merawat Eco-Guardian virtual saya hingga peringkat ${getRankBadgeAndColor(playerRank).label}! Ayo gabung melestarikan lingkungan perumahan kita secara nyata di Eco-Guardian Kelurahan Hijau!`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 3000);
  };

  const handleDownloadCertificate = () => {
    const canvas = document.createElement("canvas");
    canvas.width = 800;
    canvas.height = 1000;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // 1. Clean backgroud with premium soft background gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, 1000);
    gradient.addColorStop(0, "#FEFDF9");
    gradient.addColorStop(0.5, "#FFFDF6");
    gradient.addColorStop(1, "#F3FAF3");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 1000);

    // 2. High-contrast double border
    ctx.strokeStyle = "#10B981";
    ctx.lineWidth = 12;
    ctx.strokeRect(30, 30, 740, 940);

    ctx.strokeStyle = "#F59E0B";
    ctx.lineWidth = 3;
    ctx.setLineDash([12, 8]);
    ctx.strokeRect(50, 50, 700, 900);
    ctx.setLineDash([]);

    // 3. Corner Ornaments
    const drawCorner = (x: number, y: number, angle: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(angle);
      ctx.fillStyle = "#F59E0B";
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(40, 0);
      ctx.lineTo(40, 8);
      ctx.lineTo(8, 8);
      ctx.lineTo(8, 40);
      ctx.lineTo(0, 40);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };
    drawCorner(50, 50, 0);
    drawCorner(750, 50, Math.PI / 2);
    drawCorner(750, 950, Math.PI);
    drawCorner(50, 950, -Math.PI / 2);

    // 4. Header text
    ctx.textAlign = "center";
    ctx.fillStyle = "#065F46";
    ctx.font = "bold 16px sans-serif";
    ctx.fillText("KARTU PRESTASI HIDROPONIK & DAUR ULANG RT 05", 400, 150);

    // 5. Title
    ctx.fillStyle = "#78350F";
    ctx.font = "bold 34px sans-serif";
    ctx.fillText("PIAGAM HERO ECO-GUARDIAN", 400, 210);

    // Line
    ctx.strokeStyle = "#F59E0B";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(150, 250);
    ctx.lineTo(650, 250);
    ctx.stroke();

    // 6. Subtitle / description
    ctx.fillStyle = "#475569";
    ctx.font = "italic 16px sans-serif";
    ctx.fillText("Dengan bangga diberikan kepada warga kehormatan luar biasa", 400, 310);
    ctx.fillText("atas dedikasi nyata menimbang, memilah sampah, dan menyukseskan", 400, 345);
    ctx.fillText("sirkular kelurahan secara konsisten:", 400, 380);

    // 7. Recipient
    ctx.fillStyle = "#047857";
    ctx.font = "bold 38px sans-serif";
    ctx.fillText(playerName, 400, 460);

    ctx.strokeStyle = "#F59E0B";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(200, 485);
    ctx.lineTo(600, 485);
    ctx.stroke();

    // 8. Rank
    ctx.fillStyle = "#B45309";
    ctx.font = "bold 20px sans-serif";
    const rankLabel = getRankBadgeAndColor(playerRank).label;
    ctx.fillText(`PERINGKAT: ${rankLabel.toUpperCase()} #${playerRank}`, 400, 535);

    // 9. Recycled amount block
    ctx.fillStyle = "#ECFDF5";
    ctx.beginPath();
    ctx.roundRect(150, 580, 500, 130, 25);
    ctx.fill();
    ctx.strokeStyle = "#A7F3D0";
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = "#1A3C34";
    ctx.font = "bold 18px sans-serif";
    ctx.fillText("Telah Berhasil Mendaur Ulang Seberat", 400, 625);
    
    ctx.fillStyle = "#10B981";
    ctx.font = "bold 32px sans-serif";
    ctx.fillText(`${(playerTotalGrams / 1000).toFixed(1)} Kilogram Sampah`, 400, 680);

    // 10. Footer motto
    ctx.fillStyle = "#065F46";
    ctx.font = "italic 14px sans-serif";
    ctx.fillText('"Pilah sampahmu hari ini, asuh Eco-Guardian pelindungmu,', 400, 770);
    ctx.fillText('klaim rupiah aslimu, hijaukan Kelurahan kita bersama!"', 400, 795);

    // 11. Stamp
    ctx.save();
    ctx.translate(220, 890);
    ctx.rotate(-0.15);
    ctx.strokeStyle = "rgba(16, 185, 129, 0.7)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, 48, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, 41, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "rgba(16, 185, 129, 0.7)";
    ctx.font = "bold 11px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("KAMPANYE RT05", 0, -10);
    ctx.fillText("TERTANDA", 0, 8);
    ctx.fillText("GUARDIAN", 0, 24);
    ctx.restore();

    // 12. Dynamic Trophy emoji drawing
    ctx.font = "72px sans-serif";
    ctx.fillText("🏆", 400, 90);

    // 13. RT President Signature
    ctx.fillStyle = "#334155";
    ctx.font = "bold 15px sans-serif";
    ctx.fillText("Sutarno Widodo", 580, 885);
    ctx.font = "12px sans-serif";
    ctx.fillText("Ketua RT 05 Kelurahan Hijau", 580, 905);

    // Signature scribble ink
    ctx.strokeStyle = "#475569";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(520, 865);
    ctx.bezierCurveTo(550, 845, 560, 885, 595, 855);
    ctx.bezierCurveTo(610, 835, 625, 875, 640, 865);
    ctx.stroke();

    // Trigger local client side secure download
    try {
      const dataUrl = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.download = `Piagam_Eco_Guardian_${playerName.replace(/\s+/g, '_')}.png`;
      link.href = dataUrl;
      link.click();
    } catch (e) {
      alert("Gagal mengunduh piagam, silakan coba lagi.");
    }
  };

  return (
    <div className="space-y-6" id="missions-community-panel">
      {/* Upper Milestone & Collaborative Goal */}
      <div className="bg-white rounded-[40px] p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] space-y-6">
        <div>
          <h3 className="text-xl font-black text-[#1A3C34] tracking-tight flex items-center gap-2">
            <Target className="text-[#10B981] w-5.5 h-5.5 animate-pulse" />
            Event Kelurahan Hijau - Kampanye Lingkungan Hidup
          </h3>
          <p className="text-xs text-[#065F46] font-medium mt-1">
            Donasikan sediaan botol atau sampah dapur rumah tanggamu untuk merampungkan proyek kolektif warga Kelurahan Hijau. Saling bersatu melestarikan bumi!
          </p>
        </div>

        {/* Redesigned Double-tier Digital Wallet Balance Dashboard */}
        <div className="w-full" id="ranger-cashout-dashboard">
          {/* Virtual Bank Card */}
          <div className="w-full bg-gradient-to-br from-emerald-800 via-emerald-700 to-teal-800 rounded-[35px] p-6 text-white shadow-xl relative overflow-hidden flex flex-col justify-between min-h-[190px]">
            {/* Ambient Background Glows */}
            <div className="absolute top-0 right-0 w-44 h-44 bg-emerald-400/10 rounded-full blur-2xl -translate-y-12 translate-x-12 pointer-events-none" />
            <div className="absolute bottom-0 left-12 w-32 h-32 bg-teal-400/10 rounded-full blur-xl translate-y-12 pointer-events-none" />
            
            {/* Card Header Info */}
            <div className="flex justify-between items-start relative z-10">
              <div className="space-y-1 text-left">
                <span 
                  onClick={() => { setTempWalletPhone(wallet.phone || ""); setWalletModalOpen(true); }}
                  className="text-[9px] font-black uppercase bg-[#10B981]/20 hover:bg-[#10B981]/40 text-emerald-100 px-3 py-1 rounded-full tracking-widest inline-block border border-emerald-400/30 cursor-pointer transition-all active:scale-95"
                >
                  ⚡ RT 05 ECO-CASH GATEWAY • KLIK UNTUK RIWAYAT MUTASI
                </span>
                <p className="text-[10px] text-emerald-200/90 font-medium">Dompet Saldo Hasil Pilah Sampah Warga</p>
              </div>
              <button 
                type="button" 
                onClick={() => { setTempWalletPhone(wallet.phone || ""); setWalletModalOpen(true); }}
                className="p-1.5 bg-emerald-950/20 hover:bg-emerald-950/40 border border-emerald-700 text-emerald-300 rounded-xl transition-all cursor-pointer"
                title="Buka Mutasi & Pengaturan"
              >
                <Wallet className="w-5.5 h-5.5" />
              </button>
            </div>

            {/* Balances Presentation */}
            <div className="grid grid-cols-2 gap-4 my-4 text-left relative z-10 border-t border-b border-emerald-600/40 py-3.5">
              <div className="space-y-1">
                <span className="text-[9px] text-emerald-200/80 font-black uppercase tracking-wider flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-ping" />
                  Saldo Siap Diklaim:
                </span>
                <h3 className="text-lg sm:text-xl font-black text-amber-300 tracking-tight font-mono">
                  Rp {totalUnclaimed.toLocaleString("id-ID")}
                </h3>
              </div>
              <div className="space-y-1 border-l border-emerald-600/30 pl-4">
                <span className="text-[9px] text-emerald-200/80 font-black uppercase tracking-wider flex items-center gap-1">
                  <CheckCircle className="w-2.5 h-2.5 text-emerald-300" />
                  Total Terklaim:
                </span>
                <h3 className="text-lg sm:text-xl font-black text-emerald-100 tracking-tight font-mono">
                  Rp {totalClaimed.toLocaleString("id-ID")}
                </h3>
              </div>
            </div>

            {/* Action Claim Payout */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10 pt-1">
              <div className="text-left text-[9px] text-emerald-205/90">
                {wallet.method ? (
                  <button
                    type="button"
                    onClick={() => { setTempWalletPhone(wallet.phone || ""); setWalletModalOpen(true); }}
                    className="font-semibold block text-emerald-200 hover:text-white hover:underline text-left bg-transparent border-0 cursor-pointer p-0"
                  >
                    Akun Pencairan: <strong className="text-white uppercase font-mono bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-700">{wallet.method}</strong> ({wallet.phone})
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => { setTempWalletPhone(wallet.phone || ""); setWalletModalOpen(true); }}
                    className="text-amber-200 font-bold block flex items-center gap-1 bg-transparent border-0 cursor-pointer p-0 hover:underline"
                  >
                    ⚠️ Belum menghubungkan GoPay / OVO untuk klaim.
                  </button>
                )}
              </div>

              {totalUnclaimed > 0 ? (
                <button
                  type="button"
                  onClick={() => handleDirectClaim(null, true)}
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-teal-950 font-black text-xs uppercase tracking-wider rounded-2xl border-b-4 border-amber-600 transition-all cursor-pointer flex items-center gap-1.5 self-end sm:self-auto hover:scale-[1.02] active:scale-95 shadow-md"
                >
                  <DollarSign className="w-4 h-4 stroke-[3px]" />
                  Cairkan Saldo Rp {totalUnclaimed.toLocaleString("id-ID")}
                </button>
              ) : (
                <button
                  type="button"
                  disabled
                  className="px-5 py-2.5 bg-emerald-900/60 text-emerald-500/80 font-black text-xs uppercase tracking-wider rounded-2xl border border-emerald-800/40 flex items-center gap-1.5 self-end sm:self-auto opacity-70"
                >
                  <Clock className="w-3.5 h-3.5" />
                  Belum Ada Saldo Cair
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="community-campaigns-list">
          {missions.map((mission) => {
            const progressPct = Math.min(100, (mission.currentGrams / mission.targetGrams) * 100);
            const isCompleted = mission.currentGrams >= mission.targetGrams;

            return (
              <div
                key={mission.id}
                className={`border-2 rounded-[32px] p-5 flex flex-col justify-between gap-4 transition-all relative ${
                  isCompleted 
                    ? "bg-[#F0F7F0]/60 border-[#10B981]"
                    : "bg-white border-[#E2F0E2]"
                }`}
              >
                {isCompleted && (
                  <div className="absolute top-3 right-3 bg-[#ECFDF5] text-[#10B981] text-[9px] font-black uppercase py-0.5 px-2.5 rounded-full border border-[#D1FAE5] tracking-wider">
                    Target Selesai! 🎉
                  </div>
                )}

                <div className="space-y-3">
                  <div className="flex gap-2.5 items-start">
                    <span 
                      onClick={() => setSelectedMissionId(mission.id)}
                      className="text-2xl p-2.5 bg-[#F0F7F0] rounded-xl border border-[#D1FAE5] cursor-pointer hover:bg-emerald-100 transition-colors shrink-0"
                      title="Klik untuk detail mitra"
                    >
                      {mission.category === 'PLASTIC' ? "🥤" : mission.category === 'ORGANIC' ? "🍎" : "📦"}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 
                          onClick={() => setSelectedMissionId(mission.id)}
                          className="font-extrabold text-[#1A3C34] text-xs leading-tight hover:text-emerald-800 cursor-pointer hover:underline"
                        >
                          {mission.title}
                        </h4>
                        <button
                          type="button"
                          onClick={() => setSelectedMissionId(mission.id)}
                          className="text-[9px] text-[#10B981] hover:text-[#065F46] font-black underline uppercase whitespace-nowrap shrink-0"
                        >
                          Detail ➔
                        </button>
                      </div>
                      <p className="text-[10px] text-[#065F46] font-mono font-medium mt-1 leading-normal">{mission.description}</p>
                      
                      {mission.partner && (
                        <div 
                          onClick={() => setSelectedMissionId(mission.id)}
                          className="mt-2 flex items-center gap-1.5 bg-[#ECFDF5] hover:bg-emerald-100 p-1.5 px-2.5 rounded-xl border border-[#D1FAE5] text-[9px] text-[#065F46] font-bold cursor-pointer w-fit transition-all"
                          title="Klik untuk detail pencairan nominal uang mitra"
                        >
                          <Building className="w-3 h-3 text-[#10B981]" />
                          <span>Mitra: <strong className="text-emerald-800">{mission.partner.name}</strong></span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Progress bar info layout */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-baseline text-[10px] font-mono text-[#065F46] font-bold">
                      <span>Proses: <strong className="text-[#10B981]">{(mission.currentGrams/1000).toFixed(1)} Kg</strong></span>
                      <span>Target: <strong className="text-[#1A3C34]">{(mission.targetGrams/1000).toFixed(1)} Kg</strong></span>
                    </div>

                    <div className="w-full bg-[#F4F9F4] h-3 rounded-full overflow-hidden p-0.5 border-2 border-[#E2F0E2]">
                      <motion.div
                        className="h-full bg-gradient-to-r from-[#10B981] to-[#047857] rounded-full"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                    
                    <div className="flex justify-between items-center text-[9px] font-mono mt-1">
                      <button
                        type="button"
                        onClick={() => setSelectedMissionId(mission.id)}
                        className="text-[9px] text-[#10B981] font-bold hover:underline"
                      >
                        👥 Donasi Warga & Nilai Uang (Rp) ➔
                      </button>
                      <span className="text-[#047857] uppercase tracking-wider block font-black">
                        {mission.daysRemaining} hari tersisa
                      </span>
                    </div>
                  </div>
                </div>

                {/* Donation action footer */}
                <div className="border-t border-[#E2F0E2] pt-3 flex flex-wrap sm:flex-nowrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-black text-[#047857] flex items-center gap-0.5 uppercase">
                      <Gift className="w-3.5 h-3.5 text-[#10B981]" /> +{mission.rewardTokens} Token dibagikan warga
                    </span>
                  </div>

                  {!isCompleted && (
                    inventory[mission.category] <= 0 ? (
                      <div className="text-[10px] bg-rose-50 border border-rose-200 text-rose-700 font-extrabold py-1.5 px-3 rounded-xl flex items-center gap-1">
                        <span>⚠️ Sediaan Gudang 0 Kg (Tidak bisa donasi)</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 w-full sm:w-auto">
                        <select
                          value={donateAmount}
                          onChange={(e) => setDonateAmount(parseInt(e.target.value))}
                          className="px-2 py-1 text-xs border-2 border-[#E2F0E2] rounded-xl bg-white text-[#1A3C34] font-bold"
                        >
                          <option value={200}>200g</option>
                          <option value={500}>500g</option>
                          <option value={1000}>1.0Kg</option>
                          <option value={2000}>2.0Kg</option>
                        </select>
                        <button
                          type="button"
                          onClick={() => handleDonateSubmit(mission)}
                          className="py-1.5 px-3 bg-[#10B981] hover:bg-[#059669] text-white border-[#065F46] border-b-2 font-black rounded-xl text-xs transition-transform hover:scale-105"
                        >
                          Donasi
                        </button>
                      </div>
                    )
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Pickups Log and Status Tracking */}
      <div className="bg-white rounded-[40px] p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] space-y-6">
        <div>
          <h3 className="text-lg font-black text-[#1A3C34] tracking-tight flex items-center gap-2">
            <Truck className="text-[#10B981] w-5.5 h-5.5" />
            Jadwal Penjemputan Sampah Donasi 🚛
          </h3>
          <p className="text-xs text-[#065F46] font-medium mt-1">
            Pantau status penjemputan sampah ril yang sudah didonasikan. Kurir balai desa akan datang menimbang fisik di rumahmu!
          </p>
        </div>

        {pickups.length === 0 ? (
          <div className="border-2 border-dashed border-slate-200 p-8 text-center rounded-[32px] space-y-2">
            <p className="text-xs text-slate-500 font-bold">Belum ada jadwal penjemputan.</p>
            <p className="text-[10px] text-slate-400 font-medium">Donasikan botol/sampah organik sisa gudangmu di atas untuk menjadwalkan kurir penjemputan baru gratis!</p>
          </div>
        ) : (
          <div className="space-y-3" id="donation-pickups-list">
            {pickups.map((pickup) => (
              <div
                key={pickup.id}
                className={`p-5 rounded-[24px] border-2 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                  pickup.status === 'SUDAH_DIKUMPULKAN'
                    ? "bg-[#F8FAF8]/80 border-emerald-100"
                    : "bg-amber-50/45 border-amber-100"
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl p-2 bg-white rounded-xl border border-slate-100 shrink-0 shadow-sm">
                    {pickup.category === 'PLASTIC' ? "🥤" : pickup.category === 'ORGANIC' ? "🍎" : "📦"}
                  </span>
                  <div className="space-y-1 text-left">
                    <span className="text-[10px] bg-slate-100 text-slate-705 font-black px-2 py-0.5 rounded-lg uppercase tracking-wider block w-fit">
                      {pickup.category === 'PLASTIC' ? "Plastik & Botol" : pickup.category === 'ORGANIC' ? "Organik Basah" : "Kertas & Kardus"}
                    </span>
                    <h4 className="font-extrabold text-xs text-[#1A3C34] leading-tight">
                      Penjemputan Donasi "{pickup.missionTitle}"
                    </h4>
                    <p className="text-[10px] text-[#065F46] font-semibold leading-normal font-sans">
                      📍 Lokasi: {pickup.address}
                    </p>
                    <p className="text-[9px] text-slate-400 font-bold font-mono">
                      📅 Diajukan: {pickup.timestamp}
                    </p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-start sm:items-center md:justify-end gap-3 shrink-0">
                  <div className="text-left sm:text-right">
                    <span className="text-xs font-black text-[#10B981] font-mono block">
                      {(pickup.weightGrams / 1000).toFixed(1)} Kg Sampah
                    </span>
                    <span className="text-[10px] font-mono text-rose-600 font-bold block">
                      Cair Rp {pickup.cashEarned.toLocaleString("id-ID")} Ke {pickup.paymentMethod}
                    </span>
                    <span className="text-[9px] text-slate-400 block font-bold leading-none mt-0.5">
                      No. HP: {pickup.paymentPhone}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {pickup.status === 'BELUM_DIKUMPULKAN' ? (
                      <>
                        <span className="text-[10px] font-black text-amber-700 bg-amber-100 border border-amber-200 p-2 rounded-xl flex items-center gap-1 font-mono tracking-tight shrink-0">
                          <Clock className="w-3.5 h-3.5 animate-spin shrink-0" /> Belum Dikumpulkan
                        </span>
                        <button
                          type="button"
                          onClick={() => handleDirectClaim(pickup.id, false)}
                          className="px-3.5 py-2 bg-[#10B981] hover:bg-[#059669] text-white border-b-2 border-[#065F46] font-black text-[10px] rounded-xl flex items-center gap-1 transition-transform hover:scale-105 active:scale-95 cursor-pointer shadow-sm animate-pulse"
                        >
                          <CheckCircle className="w-3.5 h-3.5" /> Jemput & Klaim Uang
                        </button>
                      </>
                    ) : (
                      <span className="text-[10px] font-black text-emerald-800 bg-emerald-100/60 border border-emerald-200 p-2 rounded-xl flex items-center gap-1.5 font-sans">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100" /> Sudah Dikumpulkan (Uang Cair!)
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Leaderboard Ranking structure */}
      <div className="bg-white rounded-[40px] p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-[#E2F0E2] pb-4">
          <div>
            <h3 className="text-lg font-black text-[#1A3C34] tracking-tight flex items-center gap-2">
              <Trophy className="text-yellow-500 w-5.5 h-5.5" />
              Peringkat Aktivis Pahlawan Sampah Kelurahan
            </h3>
            <p className="text-xs text-[#065F46] font-medium mt-1">Kumulatif volume sampah nyata yang berhasil dilebur dan dibarter oleh warga sekitarmu.</p>
          </div>

          <button
            type="button"
            onClick={() => setShareModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-[#FAFDFB] border-3 border-[#E2F0E2] hover:border-[#10B981] rounded-2xl font-black text-xs text-[#065F46] hover:bg-[#F0F7F0] self-start cursor-pointer hover:scale-[1.02] active:scale-95 transition-all shadow-xs"
          >
            <Share2 className="w-4 h-4 stroke-[2.7px] text-[#10B981]" /> Bagikan Prestasi
          </button>
        </div>

        {/* Leaderboard layout list */}
        <div className="space-y-2.5" id="leaderboard-ranking-list">
          {leaderboard.map((user, idx) => {
            const isMe = user.id === "player";
            const badgeMeta = getRankBadgeAndColor(idx + 1);

            return (
              <div
                key={user.id}
                className={`p-4 rounded-[24px] flex items-center justify-between border-2 transition-all ${
                  isMe
                    ? "bg-[#F0F7F0] border-[#10B981] ring-4 ring-[#ECFDF5]"
                    : "bg-white border-[#E2F0E2] hover:border-[#10B981]"
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Rank score indicator */}
                  <span className="w-6 font-mono font-black text-[#1A3C34] text-sm pl-1">{idx + 1}</span>

                  {/* Avatar wrapper */}
                  <div className="relative">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full border-2 border-[#E2F0E2] object-cover"
                    />
                    <span className="absolute -bottom-1 -right-1 text-sm bg-white rounded-full shadow-inner p-0.5">
                      {badgeMeta.icon}
                    </span>
                  </div>

                  <div>
                    <span className="font-extrabold text-xs text-[#1A3C34] block flex items-center gap-1">
                      {user.name}
                      {isMe && (
                        <span className="text-[9px] font-black text-white bg-[#10B981] px-1.5 py-0.5 rounded uppercase">
                          Kamu
                        </span>
                      )}
                    </span>
                    <span className="text-[10px] text-[#065F46] block font-bold leading-none mt-0.5">
                      Peringkat: {badgeMeta.label}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-black text-[#10B981] font-mono block">
                    {(user.totalRecycledGrams / 1000).toFixed(1)} Kg
                  </span>
                  <span className="text-[9px] text-[#065F46] font-mono block uppercase font-bold mt-0.5">
                    Recycled / Bartered
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Detail Kampanye & Pencairan Dana Mitra Modal */}
      <AnimatePresence>
        {selectedMission && (
          <div className="fixed inset-0 z-50 bg-[#065F46]/60 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-white rounded-[45px] border-4 border-[#10B981] p-6 sm:p-8 max-w-xl w-full shadow-2xl relative overflow-y-auto max-h-[90vh] space-y-6 text-[#1A3C34]"
            >
              {/* Close button */}
              <button
                type="button"
                onClick={() => setSelectedMissionId(null)}
                className="absolute top-4 right-4 p-2 bg-emerald-50 hover:bg-emerald-100 text-[#10B981] hover:text-[#065F46] hover:rotate-90 transition-transform duration-150 rounded-full font-bold cursor-pointer"
                title="Tutup lembar detail"
              >
                <X className="w-5 h-5" />
              </button>

              <div>
                <h3 className="text-lg font-black leading-tight tracking-tight text-[#1a3c34] pr-8 flex items-center gap-2">
                  <Target className="text-[#10B981] w-5 h-5 shrink-0" />
                  {selectedMission.title}
                </h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-1">
                  Detail Event Kelurahan & Mitra Kerja Sama
                </p>
              </div>

              {/* Partner Corporate Card */}
              {selectedMission.partner ? (
                <div className="bg-[#F0F7F0]/80 p-4 rounded-3xl border-2 border-[#D1FAE5] flex flex-col sm:flex-row items-center gap-4">
                  <img
                    src={selectedMission.partner.avatar}
                    alt={selectedMission.partner.name}
                    className="w-14 h-14 rounded-2xl border-2 border-white object-cover shadow-sm shrink-0"
                  />
                  <div className="text-center sm:text-left">
                    <span className="text-[9px] font-black uppercase text-emerald-800 bg-white border border-emerald-100 px-2 py-0.5 rounded-lg tracking-wider">
                      Mitra Pembeli Berwenang
                    </span>
                    <h4 className="font-extrabold text-sm mt-1 text-[#1A3C34]">
                      {selectedMission.partner.name}
                    </h4>
                    <p className="text-[10px] text-slate-500 font-bold">
                      {selectedMission.partner.categoryName}
                    </p>
                    <div className="mt-2 text-[11px] font-black text-rose-600 font-mono flex items-center gap-1.5 bg-white px-3 py-1 rounded-xl border border-rose-100 w-fit mx-auto sm:mx-0 shadow-sm">
                      💵 Rp {selectedMission.partner.cashPerKg.toLocaleString("id-ID")} / Kg Sampah
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-amber-50 p-4 rounded-3xl border border-amber-200 text-xs font-bold text-amber-800 text-center">
                  Informasi mitra sedang diperbarui kelurahan.
                </div>
              )}

              {/* Progress Panel */}
              <div className="bg-[#FAFDFB] border border-emerald-100 p-4 rounded-3xl space-y-2">
                <span className="text-[10px] font-black text-[#065F46] uppercase tracking-wide block">
                  Status Akumulasi Event:
                </span>
                <div className="flex justify-between items-baseline text-xs font-mono text-slate-600 font-bold">
                  <span>Terkumpul: <strong className="text-[#10B981] text-sm">{(selectedMission.currentGrams/1000).toFixed(1)} Kg</strong></span>
                  <span>Target: <strong className="text-[#1A3C34] text-sm">{(selectedMission.targetGrams/1000).toFixed(1)} Kg</strong></span>
                </div>
                
                <div className="w-full bg-[#F4F9F4] h-3.5 rounded-full overflow-hidden p-0.5 border-2 border-[#E2F0E2]">
                  <div
                    className="h-full bg-gradient-to-r from-[#10B981] to-[#047857] rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (selectedMission.currentGrams / selectedMission.targetGrams) * 100)}%` }}
                  />
                </div>
                
                <p className="text-[10px] text-[#065F46] font-medium leading-normal italic bg-[#ECFDF5] p-2 rounded-xl border border-[#D1FAE5]">
                  *Semua sampah yang Anda donasikan di kampanye ini langsung dilebur ke depo pengolahan mitra dan Anda dibayar berupa Rupiah tunai nominal di bawah berdasarkan kilogram donasi!
                </p>
              </div>

              {/* Fast Donation directly inside detailed modal */}
              {selectedMission.currentGrams < selectedMission.targetGrams ? (
                inventory[selectedMission.category] <= 0 ? (
                  <div className="bg-rose-50 border-2 border-rose-100 p-5 rounded-3xl space-y-2 text-left">
                    <span className="text-[11px] font-black uppercase text-rose-700 tracking-wide block">
                      ⚠️ GUDANG SEDIAAN ANDA KOSONG!
                    </span>
                    <p className="text-xs text-slate-600 leading-relaxed font-sans">
                      Stok Anda untuk kategori <strong>{selectedMission.category === 'PLASTIC' ? "Plastik Sisa" : selectedMission.category === 'ORGANIC' ? "Bahan Organik Basah" : "Kertas & Kardus"}</strong> adalah <strong>0 kilogram</strong>. Anda tidak dapat melakukan donasi untuk event ini sekarang.
                    </p>
                    <p className="text-xs text-[#065F46] font-bold font-sans">
                      💡 Solusi: Silakan catat setoran sampah nyata wargamu terlebih dahulu di tab <strong>"Catat"</strong> untuk mengisi gudang, lalu kembali ke sini untuk menyukseskan event kelurahan!
                    </p>
                  </div>
                ) : (
                  <div className="border-t border-[#E2F0E2] pt-4 flex flex-col gap-2 bg-[#F9FAF9] p-4 rounded-3xl border border-[#E2F0E2]">
                    <span className="text-[10px] font-black uppercase text-[#065F46] tracking-wide block">
                      Donasikan Sediaan Gudangmu Langsung Ke Sini:
                    </span>
                    <div className="flex items-center justify-between text-xs gap-3 font-semibold text-[#1A3C34]">
                      <span>Sediaan Gudangmu: <strong className="text-[#10B981] font-mono">{(inventory[selectedMission.category]/1000).toFixed(1)} Kg</strong></span>
                      <span>Tingkat Konversi Koin: <strong className="text-amber-600 font-mono">+10% Token</strong></span>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <select
                        value={donateAmount}
                        onChange={(e) => setDonateAmount(parseInt(e.target.value))}
                        className="flex-1 px-3 py-2 text-xs border-2 border-[#E2F0E2] rounded-xl bg-white text-[#1A3C34] font-black cursor-pointer focus:border-[#10B981]"
                      >
                        <option value={200}>200g (Dapat Rp {((200/1000)*(selectedMission.partner?.cashPerKg || 3000)).toLocaleString("id-ID")} & +20 Token)</option>
                        <option value={500}>500g (Dapat Rp {((500/1000)*(selectedMission.partner?.cashPerKg || 3000)).toLocaleString("id-ID")} & +50 Token)</option>
                        <option value={1000}>1.0 Kg (Dapat Rp {(1*(selectedMission.partner?.cashPerKg || 3000)).toLocaleString("id-ID")} & +100 Token)</option>
                        <option value={2000}>2.0 Kg (Dapat Rp {(2*(selectedMission.partner?.cashPerKg || 3000)).toLocaleString("id-ID")} & +200 Token)</option>
                      </select>
                      <button
                        type="button"
                        onClick={() => handleDonateSubmit(selectedMission)}
                        className="py-2.5 px-5 bg-[#10B981] hover:bg-[#059669] text-white border-b-4 border-[#065F46] font-black rounded-xl text-xs transition-transform hover:scale-105 active:scale-95"
                      >
                        Donasi Sekarang
                      </button>
                    </div>
                  </div>
                )
              ) : (
                <div className="bg-emerald-50 border border-emerald-200 text-center py-3 text-xs font-black text-emerald-800 rounded-2xl">
                  Proyek ini telah sukses dirampungkan! Terima kasih atas persatuan warga.
                </div>
              )}

              {/* Donors list with weight, money, and tokens */}
              <div className="space-y-3">
                <h4 className="text-[11px] font-black uppercase text-[#1A3C34] tracking-wider flex items-center justify-between border-b pb-2">
                  <span>Daftar Donatur Tetangga & Nominal Terbayar</span>
                  <span className="font-mono text-[10px] text-emerald-600 font-bold bg-[#ECFDF5] px-2 py-0.5 rounded-full">
                    {selectedMission.donors?.length || 0} Donasi
                  </span>
                </h4>

                <div className="space-y-2.5 max-h-[200px] overflow-y-auto pr-1" id="selected-campaign-donors-log">
                  {selectedMission.donors && selectedMission.donors.length > 0 ? (
                    selectedMission.donors.map((donor, dIdx) => (
                      <div
                        key={dIdx}
                        className="bg-white border border-emerald-50 hover:border-emerald-200 p-3 rounded-2xl flex items-center justify-between text-xs transition-shadow duration-150 hover:shadow-xs"
                      >
                        <div className="flex items-center gap-2.5">
                          <img
                            src={donor.avatar}
                            alt={donor.name}
                            className="w-8 h-8 rounded-full border border-emerald-100 object-cover"
                          />
                          <div>
                            <span className="font-extrabold text-xs text-[#1A3C34] block">
                              {donor.name}
                            </span>
                            <span className="text-[9px] text-[#065F46] font-bold block uppercase tracking-wide">
                              {donor.timestamp}
                            </span>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="font-black text-[#1A3C34] text-xs">
                            {(donor.weightGrams/1000).toFixed(1)} Kg
                          </div>
                          <div className="text-[10px] font-mono font-black text-rose-600">
                             Cair Rp {donor.cashEarned.toLocaleString("id-ID")}
                          </div>
                          <div className="text-[9px] text-amber-600 font-black block">
                            +{donor.tokensEarned} Token
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-[10px] text-slate-400 font-semibold py-6">
                      Belum ada donasi terdaftar untuk kampanye ini.
                    </p>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {/* Wallet Connection & Mutation History Modal */}
        {walletModalOpen && (
          <div className="fixed inset-0 z-50 bg-[#065F46]/60 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-white rounded-[40px] border-4 border-[#10B981] p-6 sm:p-8 max-w-3xl w-full shadow-2xl relative space-y-6 text-[#1A3C34]"
            >
              {/* Close button */}
              <button
                type="button"
                onClick={() => setWalletModalOpen(false)}
                className="absolute top-4 right-4 p-2 bg-emerald-50 hover:bg-emerald-100 text-[#10B981] hover:text-[#065F46] rounded-full font-bold cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="text-center space-y-1">
                <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-[#10B981]">
                  <Wallet className="w-6 h-6 animate-pulse" />
                </div>
                <h3 className="text-lg font-black tracking-tight text-[#1a3c34]">
                   Portal E-Money & Riwayat Pencairan Kas Warga
                </h3>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                  Kelurahan Hijau RT 05 • Terintegrasi Otomatis
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Left Side: Setup & Claims info */}
                <div className="space-y-4">
                  <div className="bg-[#FAFDFB] p-4 rounded-3xl border border-[#D1FAE5] space-y-2 text-left">
                    <span className="text-[9px] uppercase tracking-wider text-[#065F46] font-black">Informasi Saldo Kas Anda:</span>
                    <div className="flex justify-between items-center pb-2 border-b border-emerald-50">
                      <div>
                        <p className="text-[10px] text-slate-500 font-semibold uppercase">Siap Diklaim</p>
                        <h3 className="text-xl font-black font-mono text-amber-500">Rp {totalUnclaimed.toLocaleString("id-ID")}</h3>
                      </div>
                      <div className="border-l border-emerald-100 pl-4">
                        <p className="text-[10px] text-slate-500 font-semibold uppercase">Total Terklaim</p>
                        <h3 className="text-xl font-black font-mono text-emerald-600">Rp {totalClaimed.toLocaleString("id-ID")}</h3>
                      </div>
                    </div>

                    {totalUnclaimed > 0 ? (
                      <button
                        type="button"
                        onClick={() => {
                          if (!tempWalletPhone.trim()) {
                            alert("Masukkan Nomor HP di bawah terlebih dahulu!");
                            return;
                          }
                          // Save first!
                          onUpdateWallet(tempWalletMethod, tempWalletPhone.trim());
                          handleDirectClaim(null, true);
                        }}
                        className="w-full mt-2 py-2.5 bg-amber-400 hover:bg-amber-300 text-[#1a3c34] border-b-4 border-amber-600 font-black rounded-xl text-xs uppercase tracking-wide transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <DollarSign className="w-4 h-4 stroke-[3px]" />
                        Cairkan Saldo Rp {totalUnclaimed.toLocaleString("id-ID")} Ke {tempWalletMethod}
                      </button>
                    ) : (
                      <p className="text-[10px] p-1 bg-emerald-50/50 rounded text-center text-[#065F46] font-bold">
                        🎉 Seluruh saldo donasi telah dicairkan sepenuhnya!
                      </p>
                    )}
                  </div>

                  <form onSubmit={handleConnectWalletSubmit} className="space-y-4 text-left">
                    <div className="space-y-1.5">
                      <label className="text-xs font-black text-[#1A3C34] block">
                        Pilih Dompet Digital:
                      </label>
                      <div className="grid grid-cols-2 gap-2.5">
                        <button
                          type="button"
                          onClick={() => setTempWalletMethod('GoPay')}
                          className={`py-2 px-3 rounded-xl border-2 font-black text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            tempWalletMethod === 'GoPay'
                              ? "bg-emerald-50 border-[#10B981] text-[#047857]"
                              : "bg-white border-slate-200 text-slate-500 hover:bg-slate-50"
                          }`}
                        >
                          <CreditCard className="w-4 h-4" />
                          ⚡ GoPay
                        </button>
                        <button
                          type="button"
                          onClick={() => setTempWalletMethod('OVO')}
                          className={`py-2 px-3 rounded-xl border-2 font-black text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            tempWalletMethod === 'OVO'
                              ? "bg-emerald-50 border-[#10B981] text-[#047857]"
                              : "bg-white border-slate-200 text-slate-500 hover:bg-slate-50"
                          }`}
                        >
                          <CreditCard className="w-4 h-4" />
                          🔮 OVO
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-black text-[#1A3C34] block">
                        No. Handphone GoPay/OVO:
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                        <input
                          type="text"
                          placeholder="Contoh: 08123456789"
                          value={tempWalletPhone}
                          onChange={(e) => setTempWalletPhone(e.target.value)}
                          className="w-full pl-10 pr-4 py-2 text-xs font-black border-2 border-slate-200 rounded-xl focus:border-[#10B981] focus:outline-none text-[#1a3c34]"
                        />
                      </div>
                      <span className="text-[9px] text-[#065F46] block font-medium leading-tight">
                        *Pastikan no. HP terhubung dengan e-wallet aktif Anda untuk memicu automasi transfer data rupiah.
                      </span>
                    </div>

                    {walletError && (
                      <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-[10px] font-bold text-center">
                        {walletError}
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-[#10B981] hover:bg-[#059669] text-white border-b-4 border-[#065F46] font-black rounded-xl text-xs transition-transform hover:scale-[1.02] active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Simpan & Hubungkan Akun
                    </button>
                  </form>
                </div>

                {/* Right Side: Scrollable transaction ledger history */}
                <div className="space-y-2 text-left flex flex-col max-h-[380px]">
                  <h4 className="text-xs font-black uppercase text-slate-600 tracking-wider flex items-center gap-1">
                    📖 MUTASI SALDO MASUK / KELUAR
                  </h4>
                  <div className="flex-1 overflow-y-auto border-2 border-dashed border-[#E2F0E2] rounded-3xl p-3 bg-[#FAFDFB] space-y-2">
                    {pickups.length === 0 ? (
                      <div className="py-12 text-center space-y-1">
                        <p className="text-[11px] text-slate-500 font-black">Belum ada mutasi transaksi.</p>
                        <p className="text-[9px] text-slate-400 leading-normal px-4">Lakukan donasi sampah di atas terlebih dahulu untuk memunculkan saldo kompensasi masuk!</p>
                      </div>
                    ) : (
                      // Render dynamic transactions derived from pickups
                      pickups.flatMap((pickup) => {
                        const transactions = [];

                        // 1. Inflow Transaction (Pemasukan)
                        transactions.push({
                          id: `tx-in-${pickup.id}`,
                          type: 'IN',
                          title: `Uang Masuk: Donasi "${pickup.missionTitle}"`,
                          amount: pickup.cashEarned,
                          time: pickup.timestamp,
                          status: pickup.status === 'BELUM_DIKUMPULKAN' ? 'Menunggu Penjemputan' : 'Diterima Warga'
                        });

                        // 2. Outflow Transaction (Penarikan / Klaim)
                        if (pickup.status === 'SUDAH_DIKUMPULKAN') {
                          transactions.push({
                            id: `tx-out-${pickup.id}`,
                            type: 'OUT',
                            title: `Uang Keluar: Pencairan ke ${pickup.paymentMethod || wallet.method || 'GoPay'}`,
                            amount: pickup.cashEarned,
                            time: pickup.timestamp,
                            status: `Sukses Cair (${pickup.paymentPhone || wallet.phone})`
                          });
                        }

                        return transactions;
                      }).map((tx) => (
                        <div key={tx.id} className="p-3 bg-white rounded-2xl border border-slate-100 flex items-center justify-between gap-3 shadow-xs hover:border-emerald-200 transition-all">
                          <div className="space-y-0.5 min-w-0">
                            <span className={`inline-block text-[8px] font-black uppercase px-2 py-0.5 rounded-md ${
                              tx.type === 'IN' 
                                ? "bg-emerald-50 text-emerald-800 border border-emerald-100" 
                                : "bg-slate-100 text-slate-600 border border-slate-200"
                            }`}>
                              {tx.type === 'IN' ? '📥 Uang Masuk' : '📤 Uang Keluar (Cair)'}
                            </span>
                            <h5 className="font-extrabold text-[10px] text-[#1A3C34] truncate mt-0.5">
                              {tx.title}
                            </h5>
                            <div className="flex items-center gap-1.5 text-[8px] text-slate-400 font-bold font-mono">
                              <span>🕒 {tx.time}</span>
                              <span>•</span>
                              <span className={tx.type === 'IN' && tx.status.includes('Menunggu') ? "text-amber-600 font-black" : "text-emerald-600 font-black"}>
                                {tx.status}
                              </span>
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <span className={`text-[11px] font-black font-mono block ${
                              tx.type === 'IN' ? "text-[#10B981]" : "text-slate-600"
                            }`}>
                              {tx.type === 'IN' ? '+' : '-'} Rp {tx.amount.toLocaleString("id-ID")}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {/* Share Achievement Certificate Modal */}
        {shareModalOpen && (
          <div className="fixed inset-0 z-50 bg-[#065F46]/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, rotate: -2 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-amber-50 rounded-[45px] border-[8px] border-amber-500 max-w-lg w-full shadow-2xl relative p-8 text-center text-[#1A3C34] space-y-6 overflow-hidden"
              style={{ backgroundImage: "radial-gradient(#fefcbf 1px, transparent 1px)", backgroundSize: "16px 16px" }}
            >
              {/* Confetti Ribbon Backdrops */}
              <div className="absolute top-0 left-0 w-32 h-32 bg-amber-400/20 rounded-full blur-xl -translate-y-6 -translate-x-6 pointer-events-none" />
              <div className="absolute bottom-0 right-0 w-44 h-44 bg-[#10B981]/15 rounded-full blur-2xl translate-y-12 translate-x-12 pointer-events-none" />

              {/* Close Button */}
              <button
                type="button"
                onClick={() => setShareModalOpen(false)}
                className="absolute top-4 right-4 p-2 bg-amber-100 hover:bg-amber-200 text-amber-800 rounded-full font-bold cursor-pointer transition-transform hover:scale-110"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Certificate Border Frames */}
              <div className="border-2 border-dashed border-amber-600/30 p-6 rounded-[35px] space-y-5 bg-white/70 backdrop-blur-xs">
                {/* Seal Icon Banner */}
                <div className="flex justify-center">
                  <motion.div 
                    initial={{ scale: 0, rotate: -45 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ type: "spring", stiffness: 120, damping: 10, delay: 0.1 }}
                    className="w-16 h-16 bg-amber-400 rounded-full border-4 border-white shadow-md flex items-center justify-center text-3xl font-bold text-amber-950"
                  >
                    🏆
                  </motion.div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-black tracking-widest text-[#065F46] uppercase block">
                    KARTU PRESTASI HIDROPONIK & DAUR ULANG RT 05
                  </span>
                  <h3 className="text-xl font-mono font-black text-amber-900 leading-tight">
                    PIAGAM HERO ECO-GUARDIAN
                  </h3>
                </div>

                <div className="py-4 border-t border-b border-amber-200/50 space-y-3">
                  <p className="text-xs text-slate-500 italic leading-relaxed">
                    Dengan bangga diberikan kepada warga kehormatan luar biasa atas dedikasi nyata menimbang, memilah sampah, dan menyukseskan sirkular kelurahan:
                  </p>
                  
                  <div className="space-y-1">
                    <h2 className="text-xl font-extrabold text-[#065F46] tracking-tight decoration-double underline decoration-amber-400">
                      {playerName}
                    </h2>
                    <p className="text-[11px] font-mono font-black text-amber-700 uppercase">
                      Peringkat: {getRankBadgeAndColor(playerRank).label} #{playerRank}
                    </p>
                  </div>

                  <p className="text-xs text-[#1a3c34] font-semibold font-sans">
                    Telah mendaur ulang seberat: <strong className="text-[#10B981] font-mono text-sm leading-none bg-[#ECFDF5] px-3.5 py-1.5 rounded-xl border border-[#D1FAE5] inline-block font-black">{(playerTotalGrams / 1000).toFixed(1)} Kilogram</strong> sampah lingkungan hidup rumah tangga.
                  </p>
                </div>

                {/* Copy / Action Shares */}
                <div className="space-y-3">
                  <p className="text-[9px] text-[#065F46] leading-relaxed italic">
                    "Pilah sampahmu hari ini, asuh Eco-Guardian pelindungmu, klaim rupiah aslimu, hijaukan Kelurahan kita bersama!"
                  </p>

                  <div className="flex flex-col sm:flex-row items-center gap-2">
                    <button
                      type="button"
                      onClick={handleCopyCertificateText}
                      className="w-full sm:flex-1 py-3 bg-amber-400 hover:bg-amber-300 text-amber-950 border-b-4 border-amber-600 font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer hover:scale-102 active:scale-95"
                    >
                      <Copy className="w-4 h-4" />
                      {copiedText ? "Teks Disalin! ✅" : "Salin Teks"}
                    </button>
                    
                    <button
                      type="button"
                      onClick={handleDownloadCertificate}
                      className="w-full sm:flex-1 py-3 bg-blue-500 hover:bg-blue-600 text-white border-b-4 border-blue-700 font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer hover:scale-102 active:scale-95"
                    >
                      <Award className="w-4 h-4" />
                      Unduh Piagam
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const textToShare = `🌱 Prestasi Pahlawan Sampah RT 05: Saya baru saja mendaur ulang ${(playerTotalGrams / 1000).toFixed(1)} Kg sampah rumah tangga dan merawat Eco-Guardian virtual saya hingga peringkat ${getRankBadgeAndColor(playerRank).label}! Ayo gabung melestarikan lingkungan perumahan kita secara nyata di Eco-Guardian Kelurahan Hijau!`;
                        if (onShareToChat) {
                          onShareToChat(textToShare);
                        } else {
                          alert("🎉 Sertifikat berhasil dibagikan ke forum pesan tetangga Kelurahan Hijau!");
                        }
                        setShareModalOpen(false);
                      }}
                      className="w-full sm:w-auto px-4 py-3 bg-[#10B981] hover:bg-[#059669] text-white border-b-4 border-[#065F46] font-black text-xs uppercase tracking-wider rounded-xl transition-all cursor-pointer hover:scale-102"
                    >
                      Kirim Ke Chat
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}


      </AnimatePresence>
    </div>
  );
}
