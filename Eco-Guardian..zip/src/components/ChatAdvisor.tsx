/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from "react";
import { Send, Sparkles, MessageSquare, Bot, AlertCircle } from "lucide-react";
import { ChatMessage } from "../types";

interface ChatAdvisorProps {
  chatHistory: ChatMessage[];
  onAddChatMessage: (msg: ChatMessage) => void;
}

const QUICK_REPLIES = [
  "Bagaimana cara mengolah minyak jelantah sisa dapur?",
  "Apa pakan kesukaan virtual Eco-Guardian biar cepat besar?",
  "Bagaimana cara tukar kardus tebal ke pupuk kompos?",
  "Mengapa penting memisahkan botol plastik dari sampah organik?"
];

export default function ChatAdvisor({ chatHistory, onAddChatMessage }: ChatAdvisorProps) {
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState("");
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, isLoading]);

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    setApiError("");
    
    // 1. Add user message to history
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      senderName: "Saya (Eco-Ranger)",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    };
    onAddChatMessage(userMsg);
    setInputText("");
    setIsLoading(true);

    try {
      // 2. Query full-stack backend endpoint executing server-side Gemini API
      const response = await fetch("/api/eco-consult", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: textToSend, chatHistory: chatHistory.slice(-10) }) // Send last 10 messages for context
      });

      if (!response.ok) {
        throw new Error("Gagal memperoleh respons dari server.");
      }

      const data = await response.json();
      
      const petMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'pet',
        senderName: "Eco-Guardian Guru AI",
        text: data.reply || "Maaf, aku sedang bermeditasi menyerap karbon lingkungan. Coba tanyakan lagi ya!",
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      };
      
      onAddChatMessage(petMsg);
    } catch (err: any) {
      console.warn("Server API failed or is not active. Running smart offline fallback...", err);
      // Run intelligent client-side fallback
      generateOfflineReply(textToSend);
    } finally {
      setIsLoading(false);
    }
  };

  const generateOfflineReply = (text: string) => {
    const query = text.toLowerCase();
    let replyText = "";

    if (query.includes("jelantah") || query.includes("minyak")) {
      replyText = "Waduh pertanyaannya bagus sekali! Minyak jelantah TIDAK BOLEH dibuang ke wastafel karena bisa menyumbat saluran pipa RT kita dan mencemari air tanah. Kamu bisa menyaringnya, menampungnya dalam jerigen, lalu barter sediaan jelantahmu dengan tetangga yang membuat lilin aromaterapi atau mendonasikannya ke pengepul solar biodiesel di RT seberang! Kamu akan dapat banyak Eco-Tokens lho!";
    } else if (query.includes("makan") || query.includes("pakan") || query.includes("kesukaan")) {
      replyText = "Aku adalah pet monster berenergi klorofil! Aku paling suka difermentasi pakan sampah organik (kulit mangga, sisa apel, sayuran sawi hijau). Kamu juga bisa menukarkan tokenmu ke 'Super Eco-Seeds' di dashboard utama saya untuk melontarkan levelku secara cepat!";
    } else if (query.includes("kardus") || query.includes("kertas") || query.includes("pupuk")) {
      replyText = "Kardus bekas yang tebal memiliki serat selulosa yang tinggi. Seringkali Bu Retno merendamnya untuk dijadikan media cacing tanah penghasil kascing (kompos cacing). Cobalah cek peta tetangga, Bu Retno sering menawarkan barter kardus dengan Pupuk Organik murni buat pekaranganmu!";
    } else if (query.includes("pisah") || query.includes("plastik") || query.includes("organik")) {
      replyText = "Jika plastik tercampur sampah organik dapur, dia akan kotor dan tidak bernilai jual daur ulang. Selain itu sisa organik akan membusuk memproduksi gas metana anaerobik berbahaya. Dengan pemisahan kering & basah, sisa organik bisa langsung dibuat pupuk kompos subur, dan botol plastik di-press untuk pakan pabrik plastik baru. Sangat menguntungkan bagi monster Eco-Guardian-mu!";
    } else {
      replyText = "Wah, pemikiran ramah lingkungan yang mengesankan! Sebagai pendamping virtual Eco-Guardian, aku senang sekali kamu aktif mencari cara melestarikan lingkungan kita. Jangan lupa untuk mencatat sampah aslimu di rumah dan tukarkan/barter langsung dengan warga desa sekitarmu agar aku terus berevolusi!";
    }

    setTimeout(() => {
      onAddChatMessage({
        id: Date.now().toString(),
        sender: 'pet',
        senderName: "Eco-Guardian Guru AI",
        text: replyText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      });
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="bg-white rounded-[40px] border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] flex flex-col md:flex-row h-[540px] overflow-hidden" id="eco-advisor-panel">
      {/* Sidebar: quick-replies instructions */}
      <div className="w-full md:w-1/3 border-b md:border-b-0 md:border-r-4 border-[#E2F0E2] p-6 flex flex-col justify-between bg-[#F0F7F0]/40 overflow-y-auto">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-[#F0F7F0] text-[#10B981] rounded-xl border border-[#D1FAE5]">
              <Bot className="w-5 h-5" />
            </span>
            <h4 className="font-black text-sm text-[#1A3C34] leading-tight">Konsultasi AI Eco-Guardian</h4>
          </div>
          <p className="text-[11px] text-[#065F46] font-medium leading-relaxed">
            Tanyakan segala hal tentang regulasi pemilahan sampah, cara membuat komposter mini di teras, atau panduan swap barter antar tetangga. AI Guru ditenagai oleh Google Gemini.
          </p>
        </div>

        <div className="mt-6 space-y-2.5">
          <span className="text-[10px] font-black text-[#047857] block uppercase tracking-wider">Topik Cepat:</span>
          {QUICK_REPLIES.map((reply, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSend(reply)}
              className="w-full p-3 bg-white hover:bg-[#F0F7F0] hover:text-[#10B981] border-2 border-[#E2F0E2] hover:border-[#10B981] text-left rounded-2xl transition-all block text-[11px] font-bold text-[#1A3C34] shadow-sm leading-tight"
            >
              🚀 {reply}
            </button>
          ))}
        </div>
      </div>

      {/* Main chat window container */}
      <div className="flex-1 flex flex-col h-full bg-[#F4F9F4]/50 rounded-r-3xl">
        {/* Messages feed */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 font-sans">
          {chatHistory.map((msg) => {
            const isMe = msg.sender === 'user';
            
            return (
              <div key={msg.id} className={`flex max-w-[85%] flex-col ${isMe ? 'ml-auto items-end' : 'mr-auto items-start'}`}>
                <div className="flex items-center gap-1.5 mb-1.5 font-bold">
                  {!isMe && (
                    <span className="px-2 py-0.5 text-[9px] bg-[#ECFDF5] text-[#10B981] border border-[#D1FAE5] rounded-full font-black shrink-0">
                      AI GURU
                    </span>
                  )}
                  <span className="text-[10px] text-[#065F46] font-mono font-bold">{msg.senderName}</span>
                  <span className="text-[9px] text-emerald-800/60 font-mono font-bold">• {msg.timestamp}</span>
                </div>

                <div className={`p-4 rounded-2xl text-xs leading-relaxed shadow-sm border-2 ${
                  isMe
                    ? 'bg-[#10B981] text-white border-[#065F46] border-b-4 rounded-tr-none font-bold'
                    : 'bg-white text-[#1A3C34] border-[#E2F0E2] rounded-tl-none font-medium'
                }`}>
                  {msg.text}
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="mr-auto max-w-[80%] flex flex-col items-start font-sans">
              <div className="flex items-center gap-1.5 mb-1 bg-[#F0F7F0] px-3 py-1 rounded-full border border-[#D1FAE5] text-[10px] text-[#10B981] font-black animate-pulse">
                <Sparkles className="w-3.5 h-3.5 animate-spin" /> Eco-AI sedang berpikir...
              </div>
              <div className="p-3 bg-white border-2 border-[#E2F0E2] rounded-2xl rounded-tl-none flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-[#10B981] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-1.5 h-1.5 bg-[#10B981] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-1.5 h-1.5 bg-[#10B981] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Input box */}
        <div className="p-4 border-t-4 border-[#E2F0E2] bg-white flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend(inputText)}
            placeholder="Tanyakan kiat memilah atau barter sampah..."
            className="flex-1 px-4 py-3 text-xs bg-[#F4F9F4] text-[#1A3C34] border-2 border-[#E2F0E2] focus:border-[#10B981] focus:bg-white rounded-xl outline-none font-bold placeholder:text-emerald-800/40"
          />
          <button
            type="button"
            onClick={() => handleSend(inputText)}
            disabled={!inputText.trim() || isLoading}
            className={`p-3 bg-[#10B981] hover:bg-[#059669] text-white border-[#065F46] border-b-4 rounded-xl shadow flex items-center justify-center gap-1 cursor-pointer transition-all ${
              !inputText.trim() || isLoading ? "opacity-60 cursor-not-allowed" : "hover:scale-105"
            }`}
          >
            <Send className="w-4 h-4 stroke-[3px]" />
          </button>
        </div>
      </div>
    </div>
  );
}
