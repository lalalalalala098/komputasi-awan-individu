/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";

interface PetAvatarProps {
  stage: 'EGG' | 'BABY' | 'TEEN' | 'GUARDIAN';
  hunger: number;
  cleanliness: number;
  happiness: number;
  expression?: 'WASH' | 'PLAY' | 'SAD' | 'NORMAL' | 'IDLE';
}

export default function PetAvatar({ stage, hunger, cleanliness, happiness, expression }: PetAvatarProps) {
  const isHungry = hunger < 35 && expression !== 'WASH' && expression !== 'PLAY';
  const isDirty = cleanliness < 35 && expression !== 'WASH';
  const isSad = (hunger <= 50 || cleanliness <= 50 || happiness <= 50 || expression === 'SAD') && expression !== 'WASH' && expression !== 'PLAY';
  const isWashing = expression === 'WASH';
  const isPlaying = expression === 'PLAY';

  // Render SVG based on stage
  const renderAvatarContent = () => {
    switch (stage) {
      case 'EGG':
        return (
          <svg viewBox="0 0 200 200" className="w-full h-full" id="pet-svg-egg">
            {/* Shadow */}
            <ellipse cx="100" cy="170" rx="45" ry="10" fill="#e2e8f0" opacity="0.8" />
            
            {/* Egg Shell */}
            <motion.path
              d="M100 30 C55 30 50 160 100 160 C150 160 145 30 100 30 Z"
              fill="url(#eggGradient)"
              stroke="#16a34a"
              strokeWidth="4"
              className="origin-bottom"
              animate={{
                scaleX: [1, 1.05, 0.95, 1],
                scaleY: [1, 0.95, 1.05, 1],
                rotate: isSad ? [-1, 1, -1, 0] : [-3, 3, -3, 0]
              }}
              transition={{
                duration: isSad ? 3.5 : 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            
            {/* Spots / Eco Marks */}
            <circle cx="85" cy="80" r="8" fill="#86efac" />
            <circle cx="120" cy="110" r="10" fill="#22c55e" opacity="0.7" />
            <circle cx="80" cy="120" r="6" fill="#15803d" opacity="0.6" />
            <circle cx="115" cy="70" r="5" fill="#86efac" />

            {/* Mud spots if dirty */}
            {isDirty && (
              <>
                <path d="M 60,110 Q 65,115 62,120" stroke="#78350f" strokeWidth="5" strokeLinecap="round" />
                <path d="M 130,90 Q 135,92 133,96" stroke="#78350f" strokeWidth="4" strokeLinecap="round" />
              </>
            )}

            {/* Cute Band / Leaf decoration wrapping the egg */}
            <path d="M 60,120 Q 100,140 140,110" fill="none" stroke="#22c55e" strokeWidth="3" />
            <path d="M 72,125 L 64,135" stroke="#22c55e" strokeWidth="3" strokeLinecap="round" />
            <path d="M 115,123 L 122,133" stroke="#22c55e" strokeWidth="3" strokeLinecap="round" />

            {/* Crack lines if ready to hatch */}
            <path d="M 95,95 L 105,100 L 98,105 L 108,110" fill="none" stroke="#15803d" strokeWidth="2" />

            {/* Gradient definitions */}
            <defs>
              <linearGradient id="eggGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#f0fdf4" />
                <stop offset="50%" stopColor="#bbf7d0" />
                <stop offset="100%" stopColor="#4ade80" />
              </linearGradient>
            </defs>
          </svg>
        );

      case 'BABY':
        return (
          <svg viewBox="0 0 200 200" className="w-full h-full" id="pet-svg-baby">
            {/* Shadow */}
            <ellipse cx="100" cy="175" rx="50" ry="12" fill="#e2e8f0" opacity="0.8" />

            {/* Sprouty antenna */}
            <motion.path
              d="M 100,75 Q 115,50 130,55"
              fill="none"
              stroke="#15803d"
              strokeWidth="4"
              strokeLinecap="round"
              animate={{ rotate: [-5, 8, -5] }}
              transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
            />
            <motion.path
              d="M 130,55 C 130,55 142,48 135,42 C 128,36 122,50 122,50 Z"
              fill="#22c55e"
              stroke="#15803d"
              strokeWidth="2"
              className="origin-bottom"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 1.8, repeat: Infinity }}
            />

            {/* Little Body */}
            <motion.ellipse
              cx="100"
              cy="130"
              rx="48"
              ry="42"
              fill="url(#babyGradient)"
              stroke="#22c55e"
              strokeWidth="4"
              animate={{
                scaleY: [1, 0.96, 1.03, 1],
                scaleX: [1, 1.04, 0.97, 1],
              }}
              transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
            />

            {/* Mud Overlay */}
            {isDirty && (
              <path d="M 75,145 Q 85,150 90,140 Q 95,155 110,148" fill="none" stroke="#78350f" strokeWidth="6" strokeLinecap="round" />
            )}

            {/* Eyes */}
            <g>
              {isWashing ? (
                <>
                  {/* Bathing happy arc eyes */}
                  <path d="M 72,124 Q 80,114 88,124" fill="none" stroke="#1e293b" strokeWidth="4.5" strokeLinecap="round" />
                  <path d="M 112,124 Q 120,114 128,124" fill="none" stroke="#1e293b" strokeWidth="4.5" strokeLinecap="round" />
                </>
              ) : isPlaying ? (
                <>
                  {/* Excited laughing eyes */}
                  <path d="M 72,118 L 88,126 M 72,126 L 88,118" stroke="#1e293b" strokeWidth="4.5" strokeLinecap="round" />
                  <path d="M 112,118 L 128,126 M 112,126 L 128,118" stroke="#1e293b" strokeWidth="4.5" strokeLinecap="round" />
                </>
              ) : isSad ? (
                <>
                  {/* Sad/Teary Eyes */}
                  <ellipse cx="80" cy="120" rx="6" ry="6" fill="#1e293b" />
                  <ellipse cx="120" cy="120" rx="6" ry="6" fill="#1e293b" />
                  <circle cx="82" cy="118" r="2" fill="white" />
                  <circle cx="122" cy="118" r="2" fill="white" />
                  {/* Tears */}
                  <circle cx="80" cy="130" r="3" fill="#38bdf8" />
                  <circle cx="120" cy="130" r="3" fill="#38bdf8" />
                </>
              ) : isHungry ? (
                <>
                  {/* Dizzy / Hungry Eyes */}
                  <path d="M 73,120 L 87,120 M 80,113 L 80,127" stroke="#0f172a" strokeWidth="3" />
                  <path d="M 113,120 L 127,120 M 120,113 L 120,127" stroke="#0f172a" strokeWidth="3" />
                </>
              ) : (
                <>
                  {/* Normal Happy Blink Eyes */}
                  <motion.ellipse
                    cx="80"
                    cy="120"
                    rx="8"
                    ry="8"
                    fill="#1e293b"
                    animate={{ scaleY: [1, 1, 0.1, 1, 1] }}
                    transition={{ duration: 4, repeat: Infinity }}
                  />
                  <motion.ellipse
                    cx="120"
                    cy="120"
                    rx="8"
                    ry="8"
                    fill="#1e293b"
                    animate={{ scaleY: [1, 1, 0.1, 1, 1] }}
                    transition={{ duration: 4, repeat: Infinity }}
                  />
                  <circle cx="82" cy="116" r="3" fill="white" />
                  <circle cx="122" cy="116" r="3" fill="white" />
                </>
              )}
            </g>

            {/* Cheeks */}
            {!isDirty && (
              <>
                <circle cx="68" cy="130" r="5" fill="#f87171" opacity="0.6" />
                <circle cx="132" cy="130" r="5" fill="#f87171" opacity="0.6" />
              </>
            )}

            {/* Mouth */}
            {isWashing ? (
              <path d="M 90,135 Q 100,148 110,135" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
            ) : isPlaying ? (
              <ellipse cx="100" cy="140" rx="10" ry="8" fill="#f43f5e" stroke="#1e293b" strokeWidth="3" />
            ) : isHungry ? (
              <path d="M 95,138 Q 100,132 105,138" fill="none" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
            ) : isSad ? (
              <path d="M 93,142 Q 100,135 107,142" fill="none" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
            ) : (
              <motion.path
                d="M 92,136 Q 100,146 108,136"
                fill="#f43f5e"
                stroke="#1e293b"
                strokeWidth="3"
                strokeLinecap="round"
                animate={{ scaleY: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            )}

            {/* Little tiny leafy hands */}
            <motion.path
              d="M 52,135 C 40,130 45,120 50,125"
              fill="none"
              stroke="#22c55e"
              strokeWidth="4"
              strokeLinecap="round"
              animate={{ rotate: isSad ? [0, -10, 0] : [0, 20, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
            <motion.path
              d="M 148,135 C 160,130 155,120 150,125"
              fill="none"
              stroke="#22c55e"
              strokeWidth="4"
              strokeLinecap="round"
              animate={{ rotate: isSad ? [0, 10, 0] : [0, -20, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />

            <defs>
              <linearGradient id="babyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#bbf7d0" />
                <stop offset="100%" stopColor="#22c55e" />
              </linearGradient>
            </defs>
          </svg>
        );

      case 'TEEN':
        return (
          <svg viewBox="0 0 200 200" className="w-full h-full" id="pet-svg-teen">
            {/* Shadow */}
            <ellipse cx="100" cy="180" rx="60" ry="14" fill="#cbd5e1" opacity="0.8" />

            {/* Elegant Flowery Horn / Leaf Crown */}
            <motion.path
              d="M 80,75 C 65,45 100,35 100,35"
              fill="none"
              stroke="#15803d"
              strokeWidth="4"
              strokeLinecap="round"
            />
            <motion.path
              d="M 120,75 C 135,45 100,35 100,35"
              fill="none"
              stroke="#15803d"
              strokeWidth="4"
              strokeLinecap="round"
            />
            {/* Flower Bud on top */}
            <circle cx="100" cy="32" r="10" fill="#f43f5e" stroke="#be123c" strokeWidth="2" />
            <circle cx="95" cy="27" r="5" fill="#fca5a5" />

            {/* Ears (Leafy) */}
            <path d="M 60,95 C 30,100 40,75 55,85" fill="#4ade80" stroke="#15803d" strokeWidth="2" />
            <path d="M 140,95 C 170,100 160,75 145,85" fill="#4ade80" stroke="#15803d" strokeWidth="2" />

            {/* Teen Main Body */}
            <motion.path
              d="M60 140 C50 100 65 72 100 72 C135 72 150 100 140 140 C140 170 120 180 100 180 C80 180 60 170 60 140 Z"
              fill="url(#teenGradient)"
              stroke="#16a34a"
              strokeWidth="4"
              animate={{
                scaleY: [1, 1.02, 0.98, 1],
                scaleX: [1, 0.98, 1.02, 1],
              }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />

            {/* Body Spots / Moss accents */}
            <ellipse cx="80" cy="150" rx="10" ry="5" fill="#15803d" opacity="0.3" />
            <ellipse cx="120" cy="130" rx="8" ry="4" fill="#15803d" opacity="0.3" />

            {/* Mud if dirty */}
            {isDirty && (
              <g fill="#78350f" opacity="0.8">
                <circle cx="75" cy="115" r="4" />
                <path d="M 125,140 Q 130,145 128,150" stroke="#78350f" strokeWidth="5" strokeLinecap="round" />
              </g>
            )}

            {/* Face Eyes */}
            <g>
              {isWashing ? (
                <>
                  <path d="M 68,112 Q 78,102 88,112" fill="none" stroke="#1e293b" strokeWidth="5.5" strokeLinecap="round" />
                  <path d="M 112,112 Q 120,102 128,112" fill="none" stroke="#1e293b" strokeWidth="5.5" strokeLinecap="round" />
                </>
              ) : isPlaying ? (
                <>
                  <path d="M 68,105 L 88,115 M 68,115 L 88,105" stroke="#1e293b" strokeWidth="5" strokeLinecap="round" />
                  <path d="M 112,105 L 132,115 M 112,115 L 132,105" stroke="#1e293b" strokeWidth="5" strokeLinecap="round" />
                </>
              ) : isSad ? (
                <>
                  <path d="M 72,112 Q 80,122 88,112" fill="none" stroke="#1e293b" strokeWidth="4.5" strokeLinecap="round" />
                  <path d="M 112,112 Q 120,122 128,112" fill="none" stroke="#1e293b" strokeWidth="4.5" strokeLinecap="round" />
                  <path d="M 85,118 L 81,130" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
                  <path d="M 121,118 L 125,130" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
                </>
              ) : isHungry ? (
                <>
                  <path d="M 70,115 L 86,105 M 70,105 L 86,115" stroke="#1e293b" strokeWidth="3.5" />
                  <path d="M 114,115 L 130,105 M 114,105 L 130,115" stroke="#1e293b" strokeWidth="3.5" />
                </>
              ) : (
                <>
                  <motion.circle cx="78" cy="108" r="8" fill="#111827" />
                  <motion.circle cx="122" cy="108" r="8" fill="#111827" />
                  <circle cx="80" cy="105" r="3" fill="white" />
                  <circle cx="124" cy="105" r="3" fill="white" />
                </>
              )}
            </g>

            {/* Mouth / Smile */}
            {isWashing ? (
              <path d="M 88,124 Q 100,138 112,124" fill="#f43f5e" stroke="#111827" strokeWidth="4.5" strokeLinecap="round" />
            ) : isPlaying ? (
              <ellipse cx="100" cy="128" rx="12" ry="10" fill="#f43f5e" stroke="#111827" strokeWidth="3.5" />
            ) : isSad ? (
              <path d="M 90,132 Q 100,124 110,132" fill="none" stroke="#111827" strokeWidth="4" strokeLinecap="round" />
            ) : isHungry ? (
              <ellipse cx="100" cy="128" rx="7" ry="10" fill="#991b1b" stroke="#111827" strokeWidth="35" />
            ) : (
              <motion.path
                d="M 88,124 Q 100,138 112,124"
                fill="#f43f5e"
                stroke="#111827"
                strokeWidth="3.5"
                strokeLinecap="round"
                animate={{ scaleY: [1, 1.2, 0.9, 1] }}
                transition={{ duration: 2.5, repeat: Infinity }}
              />
            )}

            {/* Hands/Wings made of green vines */}
            <motion.path
              d="M 52,120 Q 30,130 50,150"
              fill="none"
              stroke="#15803d"
              strokeWidth="5"
              strokeLinecap="round"
              animate={{ rotate: [0, -12, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <motion.path
              d="M 148,120 Q 170,130 150,150"
              fill="none"
              stroke="#15803d"
              strokeWidth="5"
              strokeLinecap="round"
              animate={{ rotate: [0, 12, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            />

            <defs>
              <linearGradient id="teenGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#4ade80" />
                <stop offset="60%" stopColor="#22c55e" />
                <stop offset="100%" stopColor="#16a34a" />
              </linearGradient>
            </defs>
          </svg>
        );

      case 'GUARDIAN':
        return (
          <svg viewBox="0 0 200 200" className="w-full h-full" id="pet-svg-guardian">
            {/* Shadow */}
            <ellipse cx="100" cy="182" rx="72" ry="15" fill="#cbd5e1" opacity="0.9" />

            {/* Huge majestic branch horns */}
            <path d="M 75,55 C 55,20 30,40 25,25 Q 40,25 60,45" fill="none" stroke="#15803d" strokeWidth="5" strokeLinecap="round" />
            <path d="M 125,55 C 145,20 170,40 175,25 Q 160,25 140,45" fill="none" stroke="#15803d" strokeWidth="5" strokeLinecap="round" />
            
            {/* Bloom of Flowers on the horns */}
            <circle cx="25" cy="22" r="7" fill="#f43f5e" />
            <circle cx="175" cy="22" r="7" fill="#f43f5e" />
            <circle cx="25" cy="22" r="3" fill="#fef08a" />
            <circle cx="175" cy="22" r="3" fill="#fef08a" />

            {/* Leaf Collar */}
            <path d="M 60,95 Q 100,120 140,95 Q 100,80 60,95" fill="#15803d" stroke="#166534" strokeWidth="2" />

            {/* Guardian body */}
            <motion.path
              d="M 50,140 C 40,95 60,55 100,55 C 140,55 160,95 150,140 C 145,175 130,182 100,182 C 70,182 55,175 50,140 Z"
              fill="url(#guardianGradient)"
              stroke="#15803d"
              strokeWidth="5.5"
              animate={{
                scaleY: [1, 1.01, 0.99, 1],
                scaleX: [1, 0.99, 1.01, 1],
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />

            {/* Heart Core (Symbolizes eco protection) */}
            <motion.path
              d="M 100,135 C 100,135 108,127 108,122 C 108,118 104,115 100,119 C 96,115 92,118 92,122 C 92,127 100,135 100,135 Z"
              fill="#22c55e"
              animate={{ scale: [1, 1.25, 1], opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />

            {/* Guardian Eyes & Brow */}
            <g>
              {isWashing ? (
                <>
                  <path d="M 66,94 Q 76,82 86,94" fill="none" stroke="#0f172a" strokeWidth="6" strokeLinecap="round" />
                  <path d="M 114,94 Q 124,82 134,94" fill="none" stroke="#0f172a" strokeWidth="6" strokeLinecap="round" />
                </>
              ) : isPlaying ? (
                <>
                  <path d="M 66,86 L 86,98 M 66,98 L 86,86" stroke="#0f172a" strokeWidth="5.5" strokeLinecap="round" />
                  <path d="M 114,86 L 134,98 M 114,98 L 134,86" stroke="#0f172a" strokeWidth="5.5" strokeLinecap="round" />
                </>
              ) : isSad ? (
                <>
                  <path d="M 68,90 Q 78,100 88,90" fill="none" stroke="#0f172a" strokeWidth="4.5" strokeLinecap="round" />
                  <path d="M 112,90 Q 122,100 132,90" fill="none" stroke="#0f172a" strokeWidth="4.5" strokeLinecap="round" />
                </>
              ) : isHungry ? (
                <>
                  <path d="M 68,98 L 84,88" stroke="#0f172a" strokeWidth="4" strokeLinecap="round" />
                  <path d="M 116,98 L 132,88" stroke="#0f172a" strokeWidth="4" strokeLinecap="round" />
                </>
              ) : (
                <>
                  {/* Wise sparkling eyes */}
                  <circle cx="76" cy="92" r="8.5" fill="#0f172a" />
                  <circle cx="124" cy="92" r="8.5" fill="#0f172a" />
                  <circle cx="74" cy="89" r="3" fill="#ffffff" />
                  <circle cx="122" cy="89" r="3" fill="#ffffff" />
                  <circle cx="79" cy="95" r="1.5" fill="#ffffff" />
                  <circle cx="127" cy="95" r="1.5" fill="#ffffff" />
                </>
              )}
            </g>

            {/* Leafy Cloak details */}
            <path d="M 52,145 C 40,130 35,110 40,95" stroke="#22c55e" strokeWidth="4" fill="none" strokeLinecap="round" />
            <path d="M 148,145 C 160,130 165,110 160,95" stroke="#22c55e" strokeWidth="4" fill="none" strokeLinecap="round" />

            {/* Wise Gentle Smile */}
            {isWashing ? (
              <path d="M 88,104 Q 100,114 112,104" fill="none" stroke="#0f172a" strokeWidth="4" strokeLinecap="round" />
            ) : isPlaying ? (
              <ellipse cx="100" cy="108" rx="10" ry="8" fill="#f43f5e" stroke="#0f172a" strokeWidth="3.5" />
            ) : (
              <path d="M 90,105 Q 100,113 110,105" fill="none" stroke="#0f172a" strokeWidth="3" strokeLinecap="round" />
            )}

            {/* Mud on body if dirty */}
            {isDirty && (
              <g fill="#78350f" opacity="0.6">
                <rect x="70" y="145" width="8" height="6" rx="2" />
                <rect x="122" y="152" width="6" height="4" rx="1" />
              </g>
            )}

            <defs>
              <linearGradient id="guardianGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#86efac" />
                <stop offset="50%" stopColor="#16a34a" />
                <stop offset="100%" stopColor="#14532d" />
              </linearGradient>
            </defs>
          </svg>
        );
    }
  };

  return (
    <div className="w-full h-full max-w-xs mx-auto flex items-center justify-center relative p-2">
      {/* Floating SOAP bubbles when bathing */}
      {isWashing && (
        <div className="absolute inset-0 pointer-events-none z-30" id="washing-bubbles">
          <motion.div
            className="absolute top-12 left-10 w-4 h-4 rounded-full border border-teal-300 bg-teal-100/40"
            animate={{ y: [-20, -100], x: [0, 10], scale: [0.8, 1.3], opacity: [1, 0] }}
            transition={{ duration: 2.2, repeat: Infinity }}
          />
          <motion.div
            className="absolute top-24 right-8 w-5 h-5 rounded-full border border-sky-300 bg-sky-100/40"
            animate={{ y: [-10, -80], x: [0, -15], scale: [0.9, 1.4], opacity: [1, 0] }}
            transition={{ duration: 1.8, repeat: Infinity, delay: 0.3 }}
          />
          <motion.div
            className="absolute bottom-20 left-12 w-3.5 h-3.5 rounded-full border border-emerald-300 bg-emerald-100/40"
            animate={{ y: [-5, -60], x: [0, -5], scale: [0.7, 1.2], opacity: [1, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, delay: 0.5 }}
          />
          <motion.div
            className="absolute top-16 right-20 w-4.5 h-4.5 rounded-full border border-indigo-300 bg-indigo-100/40"
            animate={{ y: [-30, -90], x: [0, 12], scale: [0.8, 1.3], opacity: [1, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, delay: 0.1 }}
          />
        </div>
      )}

      {/* Floating MUSIC NOTES and STARS when playing */}
      {isPlaying && (
        <div className="absolute inset-0 pointer-events-none z-30 font-sans font-black text-lg select-none" id="playing-notes">
          <motion.div
            className="absolute top-8 left-12 text-[#10B981]"
            animate={{ y: [-10, -70], rotate: [-10, 15], opacity: [1, 0], scale: [1, 1.4] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            🎵
          </motion.div>
          <motion.div
            className="absolute top-20 right-10 text-amber-500"
            animate={{ y: [-15, -60], rotate: [10, -15], opacity: [1, 0], scale: [0.9, 1.3] }}
            transition={{ duration: 1.8, repeat: Infinity, delay: 0.3 }}
          >
            ⭐
          </motion.div>
          <motion.div
            className="absolute bottom-24 left-8 text-[#0284C7]"
            animate={{ y: [-5, -55], rotate: [-15, 20], opacity: [1, 0], scale: [0.8, 1.2] }}
            transition={{ duration: 1.5, repeat: Infinity, delay: 0.5 }}
          >
            🎶
          </motion.div>
          <motion.div
            className="absolute top-14 right-20 text-pink-500"
            animate={{ y: [-20, -80], rotate: [20, -10], opacity: [1, 0], scale: [1.1, 1.5] }}
            transition={{ duration: 2.3, repeat: Infinity, delay: 0.1 }}
          >
            ✨
          </motion.div>
        </div>
      )}

      {/* Floating Sparkles if happy */}
      {happiness > 60 && !isDirty && !isWashing && !isPlaying && (
        <div className="absolute inset-0 pointer-events-none" id="happy-sparkles">
          {stage !== 'EGG' && (
            <>
              <motion.div
                className="absolute top-8 left-12 w-2 h-2 rounded-full bg-yellow-300"
                animate={{ y: [-10, 10, -10], opacity: [0, 1, 0], scale: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <motion.div
                className="absolute top-16 right-12 w-3 h-3 rounded-full bg-green-300"
                animate={{ y: [10, -10, 10], opacity: [0.3, 1, 0.3], scale: [0.8, 1.2, 0.8] }}
                transition={{ duration: 2.5, repeat: Infinity }}
              />
              <motion.div
                className="absolute bottom-16 left-8 w-2 h-2 rounded-full bg-emerald-400"
                animate={{ y: [-15, 10, -15], opacity: [0, 0.9, 0], scale: [0.6, 1.1, 0.6] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
            </>
          )}
        </div>
      )}

      {/* Dirty Fly animation if dirty */}
      {isDirty && !isWashing && (
        <div className="absolute inset-0 pointer-events-none" id="dirty-flies">
          <motion.div
            className="absolute top-20 left-16 w-1 h-1 rounded-full bg-amber-900"
            animate={{ x: [-8, 8, -8], y: [-5, 5, -5] }}
            transition={{ duration: 1.2, repeat: Infinity }}
          />
          <motion.div
            className="absolute top-24 right-16 w-1 h-1 rounded-full bg-amber-900"
            animate={{ x: [8, -8, 8], y: [5, -5, 5] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        </div>
      )}

      {/* Avatar Drawing */}
      <div className="w-48 h-48 md:w-56 md:h-56 relative">
        {renderAvatarContent()}
      </div>
    </div>
  );
}
