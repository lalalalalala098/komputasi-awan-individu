/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Sparkles, Trophy, Flame, Heart, Droplets, Utensils, Star, Trash2 } from "lucide-react";
import { PetState, Inventory } from "../types";
import PetAvatar from "./PetAvatar";

interface PetDashboardProps {
  pet: PetState;
  inventory: Inventory;
  onFeed: (feedType: 'ORGANIC_WASTE' | 'ECO_SEED') => void;
  onWash: () => void;
  onPlay: () => void;
  onEvolve: () => void;
  onRename?: (newName: string) => void;
}

export default function PetDashboard({ pet, inventory, onFeed, onWash, onPlay, onEvolve, onRename }: PetDashboardProps) {
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(pet.name);
  const [expression, setExpression] = useState<'WASH' | 'PLAY' | 'SAD' | 'NORMAL' | 'IDLE'>('NORMAL');

  // Automatic expressions handler: WASH and PLAY run for 3.5s then return to appropriate state.
  useEffect(() => {
    if (expression === 'WASH' || expression === 'PLAY') {
      const timer = setTimeout(() => {
        const { hunger, cleanliness, happiness } = pet;
        if (hunger <= 50 || cleanliness <= 50 || happiness <= 50) {
          setExpression('SAD');
        } else {
          setExpression('NORMAL');
        }
      }, 3500);
      return () => clearTimeout(timer);
    }

    // Set expression to SAD if any of hunger, cleanliness, or happiness is <= 50%
    const { hunger, cleanliness, happiness } = pet;
    if (hunger <= 50 || cleanliness <= 50 || happiness <= 50) {
      if (expression !== 'SAD' && expression !== 'WASH' && expression !== 'PLAY') {
        setExpression('SAD');
      }
    } else {
      if (expression === 'SAD') {
        setExpression('NORMAL');
      }
    }
  }, [expression, pet.hunger, pet.cleanliness, pet.happiness]);

  const handleSaveName = () => {
    if (tempName.trim()) {
      if (onRename) onRename(tempName.trim());
      setIsEditingName(false);
    }
  };
  // Define stats and progress percentage
  const xpPct = Math.min(100, (pet.xp / pet.maxXp) * 100);
  const isEvolvable = 
    (pet.evolutionStage === 'EGG' && pet.level >= 2) ||
    (pet.evolutionStage === 'BABY' && pet.level >= 3) ||
    (pet.evolutionStage === 'TEEN' && pet.level >= 5);

  // State messages based on pet status
  const getPetQuote = () => {
    if (expression === 'WASH') {
      return `Kyaaa! Segar sekali air hujan ini! ✨ Menghilangkan daki-daki sisa kemasan sabun di badanku. Terima kasih ya! 🧼🚿`;
    }
    if (expression === 'PLAY') {
      return `Horeee! Lompat-lompat gembira bersama warga RT! 🪁 Let's dance! Tubuhku yang penuh energi siap mendaur ulang dunia! 🌟🎶`;
    }
    if (expression === 'SAD') {
      return `Hiks... kok aku dianggurin? 🥺 Usap badanku atau ajak aku bermain dong biar aku gembira lagi...`;
    }

    if (pet.evolutionStage === 'EGG') {
      return "Krak... krak telur Eco-Guardian bergetar lembut! Beri makan sampah organik sekitarmu dan terus lakukan barter agar dia cepat menetas.";
    }

    const { hunger, cleanliness, happiness } = pet;
    if (cleanliness < 40) return `Huuu... tubuh ${pet.name} agak gatal karena tumpukan limbah kering. Mandikan dengan air hujan alami ya!`;
    if (hunger < 40) return `${pet.name} kelaparan! Beri dia sisa buah organik segar atau saringan minyak jelantah sisa dapur.`;
    if (happiness < 40) return `${pet.name} kesepian. Yuk barter sampah botol plastik dengan tetangga agar kita bisa bermain bersama!`;
    
    switch (pet.evolutionStage) {
      case 'BABY':
        return `Uwaaa! ${pet.name} sangat senang bersamamu. Lihat tunas daun kecilku tumbuh subur karena kamu rajin mengurangi sampah rumahan!`;
      case 'TEEN':
        return `Hai Kak! Aku sudah tumbuh besar. Terus ajak aku menyalurkan limbah plastik dan kardus ya biar aku bisa mengawal pelestarian RT kita.`;
      case 'GUARDIAN':
        return `Terima kasih Pahlawan Hijau! Berkat kepedulian sosialmu menukar dan mengelola sampah warga, aku sekarang menjadi Penjaga Alam sejati!`;
    }
  };

  const getStageTitle = (stage: string) => {
    switch (stage) {
      case 'EGG': return "Leafy Eco-Egg (Fase Telur)";
      case 'BABY': return "Sprouty Plantlet (Bayi Tunas)";
      case 'TEEN': return "Green Forest Elf (Peri Remaja)";
      case 'GUARDIAN': return "Nature Elder Guardian (Pelindung Hutan)";
      default: return "";
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="pet-dashboard-view">
      {/* Visual Avatar block (Left) */}
      <div className="lg:col-span-5 bg-white rounded-[40px] p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] flex flex-col justify-between text-center relative overflow-hidden">
        {/* Decorative corner leaves */}
        <div className="absolute top-0 left-0 w-16 h-16 bg-[#F0F7F0] rounded-br-full" />
        <div className="absolute bottom-0 right-0 w-16 h-16 bg-[#F0F7F0] rounded-tl-full" />

        {/* Level badge */}
        <div className="flex justify-between items-center relative z-10">
          <div className="flex items-center gap-1.5 bg-[#F0F7F0] text-[#10B981] text-xs font-black px-4 py-2 rounded-2xl border-2 border-[#D1FAE5]">
            <Star className="w-3.5 h-3.5 fill-[#10B981] text-[#10B981]" />
            Lvl {pet.level}
          </div>
          <div className="text-xs text-[#065F46] font-bold font-mono bg-[#E2F0E2] px-3 py-1.5 rounded-xl border border-[#D1FAE5]">
            {getStageTitle(pet.evolutionStage)}
          </div>
        </div>

        {/* Pet Name Editable Block */}
        <div className="mt-4 mb-2 relative z-10 flex flex-col items-center">
          {isEditingName ? (
            <div className="flex items-center gap-2 bg-[#F0F7F0] px-4 py-2 rounded-2xl border-2 border-[#10B981] shadow-sm">
              <input
                type="text"
                value={tempName}
                onChange={(e) => setTempName(e.target.value)}
                maxLength={15}
                placeholder="Nama Pet"
                className="px-2 py-1 text-xs font-black text-center text-[#1A3C34] bg-white rounded-xl focus:outline-none border-2 border-emerald-300 w-32"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveName();
                  if (e.key === 'Escape') setIsEditingName(false);
                }}
              />
              <button
                onClick={handleSaveName}
                className="text-[10px] font-black uppercase text-white bg-emerald-500 hover:bg-emerald-600 px-3 py-1.5 rounded-xl cursor-pointer"
              >
                Simpan
              </button>
            </div>
          ) : (
            <div 
              onClick={() => {
                setTempName(pet.name);
                setIsEditingName(true);
              }}
              className="group flex items-center justify-center gap-2 cursor-pointer bg-emerald-50/50 hover:bg-emerald-50 px-4 py-2 rounded-2xl border-2 border-[#ECFDF5] hover:border-[#10B981]/30 transition-all shadow-sm"
              title="Klik untuk mengubah nama Pet"
            >
              <span className="font-extrabold text-[10px] text-emerald-800 bg-white px-2 py-0.5 rounded-lg uppercase tracking-wider border border-emerald-100/60 leading-none">ID PET</span>
              <span className="font-black text-sm text-[#1A3C34] tracking-tight">{pet.name}</span>
              <span className="text-[10px] opacity-40 group-hover:opacity-100 group-hover:scale-115 duration-150 transform transition-transform">✏️</span>
            </div>
          )}
        </div>

        {/* Monster Canvas Drawing */}
        <div className="my-6 relative bg-gradient-to-b from-[#ECFDF5] to-transparent rounded-[48px] py-6 shadow-inner border border-[#D1FAE5]/40">
          <PetAvatar
            stage={pet.evolutionStage}
            hunger={pet.hunger}
            cleanliness={pet.cleanliness}
            happiness={pet.happiness}
            expression={expression}
          />
        </div>

        {/* Dynamic Bubble Box */}
        <div className="bg-[#ECFDF5] rounded-3xl p-5 border-2 border-[#D1FAE5] relative max-w-sm mx-auto shadow-sm">
          {/* Bubble Tail arrow pointing to the pet */}
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 w-4 h-4 bg-[#ECFDF5] border-t-2 border-l-2 border-[#D1FAE5] rotate-45 transform translate-y-2.5" />
          <p className="text-xs text-[#1A3C34] leading-relaxed font-bold">
            "{getPetQuote()}"
          </p>
        </div>

        {/* Evolve Button overlay wrapper */}
        {isEvolvable && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="mt-4 p-4 bg-gradient-to-r from-[#10B981] to-green-500 rounded-3xl border-2 border-white shadow-lg flex flex-col items-center gap-2 text-white"
          >
            <div className="flex items-center gap-1 font-black text-sm">
              <Sparkles className="w-4 h-4 animate-spin" /> Eco-Guardian Siap Berevolusi!
            </div>
            <p className="text-[10px] opacity-90 leading-tight">Selamat! Level pencapaian milestone telah terpenuhi! Siapkan dirimu melihat wujud barunya!</p>
            <button
              type="button"
              onClick={onEvolve}
              className="py-2.5 px-6 bg-white text-[#10B981] hover:bg-[#F0F7F0] font-black text-xs rounded-xl shadow-md transition-transform hover:scale-105 uppercase tracking-wide cursor-pointer"
            >
              Evolusi Sekarang ➔
            </button>
          </motion.div>
        )}
      </div>

      {/* Pet Stats & Action Hub (Right) */}
      <div className="lg:col-span-7 flex flex-col gap-6">
        {/* Status stats card */}
        <div className="bg-white rounded-[40px] p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] space-y-6">
          <h3 className="text-lg font-black text-[#1A3C34] flex items-center gap-2">
            <Trophy className="text-[#10B981] w-5 h-5" /> Indikator Pertumbuhan Monster
          </h3>

          <div className="space-y-4">
            {/* XP progress bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-bold text-emerald-800">
                <span>Point & EXP (Pengurangan Limbah)</span>
                <span className="font-mono text-[#10B981] font-black">{pet.xp} / {pet.maxXp} EXP</span>
              </div>
              <div className="w-full h-4 bg-[#F0F7F0] rounded-full overflow-hidden p-0.5 border border-[#D1FAE5] shadow-inner animate-pulse">
                <motion.div
                  className="h-full bg-gradient-to-r from-[#10B981] to-emerald-600 rounded-full"
                  style={{ width: `${xpPct}%` }}
                  transition={{ duration: 0.8 }}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {/* Hunger meter */}
              <div className="bg-[#FFFBEB] border-2 border-[#FEF3C7] rounded-[24px] p-4 text-center space-y-2.5 relative shadow-sm">
                <div className="w-9 h-9 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center mx-auto border border-amber-200">
                  <Utensils className="w-4.5 h-4.5" />
                </div>
                <div>
                  <span className="text-[10px] text-amber-800/80 font-black block uppercase tracking-wider">Kekenyangan</span>
                  <span className="text-lg font-black text-amber-900 font-mono">{pet.hunger}%</span>
                </div>
                <div className="w-full bg-[#FEF3C7] h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full"
                    style={{ width: `${pet.hunger}%` }}
                  />
                </div>
              </div>

              {/* Cleanliness meter */}
              <div className="bg-[#ECFDF5] border-2 border-[#D1FAE5] rounded-[24px] p-4 text-center space-y-2.5 relative shadow-sm">
                <div className="w-9 h-9 bg-[#D1FAE5] text-[#10B981] rounded-xl flex items-center justify-center mx-auto border border-[#A7F3D0]">
                  <Droplets className="w-4.5 h-4.5" />
                </div>
                <div>
                  <span className="text-[10px] text-emerald-900/80 font-black block uppercase tracking-wider">Kebersihan</span>
                  <span className="text-lg font-black text-emerald-950 font-mono">{pet.cleanliness}%</span>
                </div>
                <div className="w-full bg-[#D1FAE5] h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#10B981] rounded-full"
                    style={{ width: `${pet.cleanliness}%` }}
                  />
                </div>
              </div>

              {/* Happiness meter */}
              <div className="bg-[#E0F2FE] border-2 border-[#BAE6FD] rounded-[24px] p-4 text-center space-y-2.5 relative shadow-sm">
                <div className="w-9 h-9 bg-sky-100 text-[#0284C7] rounded-xl flex items-center justify-center mx-auto border border-sky-200">
                  <Heart className="w-4.5 h-4.5 fill-sky-100" />
                </div>
                <div>
                  <span className="text-[10px] text-sky-800/80 font-black block uppercase tracking-wider">Keceriaan</span>
                  <span className="text-lg font-black text-sky-950 font-mono">{pet.happiness}%</span>
                </div>
                <div className="w-full bg-[#BAE6FD] h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#0284C7] rounded-full"
                    style={{ width: `${pet.happiness}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Controls Card */}
        <div className="bg-white rounded-[40px] p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] space-y-5">
          <div>
            <h3 className="text-lg font-black text-[#1A3C34] tracking-tight flex items-center gap-2">
              <Flame className="text-[#10B981] w-5 h-5 animate-pulse" /> Interaksi Perawatan & Feeding
            </h3>
            <p className="text-xs text-[#065F46] mt-1 font-medium">
              Gunakan persediaan limbah organik dari tab barter dan gudang pribadimu untuk mendongkrak status & level up Eco-Guardian.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="pet-action-buttons">
            {/* Feed Food Organik Button */}
            <div className="bg-[#F0F7F0] rounded-[28px] p-5 border-2 border-[#D1FAE5] flex flex-col justify-between gap-4 text-left shadow-sm">
              <div>
                <h4 className="font-extrabold text-xs text-[#1A3C34] uppercase tracking-tight">Pakan Sampah Organik</h4>
                <p className="text-[10px] text-emerald-800 font-medium mt-0.5">Ubah sisa dapur basah menjadi pakan sehat berenergi tinggi.</p>
                <div className="mt-3 text-xs font-mono font-bold text-emerald-800 bg-[#ECFDF5] py-1.5 px-3 rounded-xl w-fit border border-[#D1FAE5]">
                  Gudang Organik: {(inventory.ORGANIC / 1000).toFixed(1)} Kg
                </div>
              </div>
              <button
                type="button"
                onClick={() => onFeed('ORGANIC_WASTE')}
                disabled={inventory.ORGANIC < 500}
                className={`py-3 px-5 rounded-2xl text-xs font-black uppercase transition-all shadow-md w-full cursor-pointer flex items-center justify-center gap-1.5 border-b-4 ${
                  inventory.ORGANIC >= 500
                    ? "bg-[#10B981] hover:bg-[#059669] text-white border-[#065F46]"
                    : "bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed"
                }`}
              >
                🍳 Beri Makan (-500g Organik)
              </button>
            </div>

            {/* Feed Super Seeds Fertilizer Button */}
            <div className="bg-[#FFFBEB] rounded-[28px] p-5 border-2 border-[#FEF3C7] flex flex-col justify-between gap-4 text-left shadow-sm">
              <div>
                <h4 className="font-extrabold text-xs text-amber-900 uppercase tracking-tight flex items-center gap-1">
                  🌱 Super Eco-Seeds <span className="p-0.5 bg-amber-100 text-amber-800 text-[8px] font-black rounded uppercase">Reward</span>
                </h4>
                <p className="text-[10px] text-amber-800 font-medium mt-0.5">Bibit khusus hasil barter warga untuk lompatan energi instan!</p>
                <div className="mt-3 text-xs font-mono font-bold text-amber-900 bg-[#FFFBEB] py-1.5 px-3 rounded-xl w-fit border border-[#FEF3C7]">
                  Sediaan Benih: {inventory.ecoTokens >= 150 ? "Tersedia" : "Butuh 150 Token"}
                </div>
              </div>
              <button
                type="button"
                onClick={() => onFeed('ECO_SEED')}
                disabled={inventory.ecoTokens < 150}
                className={`py-3 px-5 rounded-2xl text-xs font-black uppercase transition-all shadow-md w-full cursor-pointer flex items-center justify-center gap-1.5 border-b-4 ${
                  inventory.ecoTokens >= 150
                    ? "bg-[#F59E0B] hover:bg-[#D97706] text-white border-[#B45309]"
                    : "bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed"
                }`}
              >
                🌱 Tanam Benih Super (-150 Token)
              </button>
            </div>

            {/* Wash / Clean pet button */}
            <div className="bg-[#ECFDF5] rounded-[28px] p-5 border-2 border-[#D1FAE5] flex flex-col justify-between gap-4 text-left shadow-sm">
              <div>
                <h4 className="font-extrabold text-xs text-[#1A3C34] uppercase tracking-tight">Mandi Air Hujan Bersih</h4>
                <p className="text-[10px] text-emerald-800 font-medium mt-0.5">Siram tubuh monster untuk mencuci lumpur sisa pemilahan sampah.</p>
                <div className="mt-3 text-xs text-emerald-900 bg-[#ECFDF5] py-1.5 px-3 rounded-xl w-fit font-bold border border-[#D1FAE5]">
                  Status Kebersihan: {pet.cleanliness}% / 100%
                </div>
              </div>
              <button
                type="button"
                onClick={onWash}
                className="py-3 px-5 bg-[#10B981] hover:bg-[#059669] border-[#065F46] border-b-4 text-white font-black uppercase text-xs rounded-2xl shadow-md w-full cursor-pointer"
              >
                🧼 Mandikan Alami (+Clean)
              </button>
            </div>

            {/* Play Community action button */}
            <div className="bg-[#E0F2FE] rounded-[28px] p-5 border-2 border-[#BAE6FD] flex flex-col justify-between gap-4 text-left shadow-sm">
              <div>
                <h4 className="font-extrabold text-xs text-[#1A3C34] uppercase tracking-tight">Sosialisasi Warga RT</h4>
                <p className="text-[10px] text-[#0284C7] font-medium mt-0.5">Ajak tetangga bermain di pekarangan hijau untuk melepaskan penat.</p>
                <div className="mt-3 text-xs text-[#0284C7] bg-[#E0F2FE] py-1.5 px-3 rounded-xl w-fit font-bold border border-[#BAE6FD]">
                  Keceriaan Pet: {pet.happiness}% / 100%
                </div>
              </div>
              <button
                type="button"
                onClick={onPlay}
                className="py-3 px-5 bg-[#0284C7] hover:bg-[#0369A1] border-[#075985] border-b-4 text-white font-black uppercase text-xs rounded-2xl shadow-md w-full cursor-pointer"
              >
                🪁 Bermain Bersama Warga (+Joy)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
