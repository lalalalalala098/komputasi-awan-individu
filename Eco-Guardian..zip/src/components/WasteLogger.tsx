/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, DragEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Upload, Trash2, Camera, Sparkles, Scale, Info, Plus, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { WasteCategory, Inventory, WasteLog } from "../types";

interface WasteLoggerProps {
  inventory: Inventory;
  onAddWaste: (category: WasteCategory, weightGrams: number, points: number, photoUrl?: string) => void;
  wasteLogs: WasteLog[];
}

const CATEGORY_DETAILS = {
  PLASTIC: {
    label: "Botol & Wadah Plastik",
    icon: "🥤",
    desc: "Botol air mineral, botol detergen, wadah makanan (PET/HDPE)",
    pointsPerKg: 100,
    color: "bg-emerald-50 text-emerald-700 border-emerald-200"
  },
  PAPER: {
    label: "Kardus & Kertas Bekas",
    icon: "📦",
    desc: "Kardus coklat, kertas bekas kantor, koran, karton susu",
    pointsPerKg: 80,
    color: "bg-green-50 text-green-700 border-green-200"
  },
  ORGANIC: {
    label: "Sisa Sampah Organik",
    icon: "🍎",
    desc: "Sisa dapur, kulit buah, sisa sayuran, ampas kopi",
    pointsPerKg: 120,
    color: "bg-teal-50 text-teal-700 border-teal-200"
  },
  METAL_GLASS: {
    label: "Kaleng & Kaca Bekas",
    icon: "🥫",
    desc: "Kaleng alumunium, botol kaca marjan, toples selai",
    pointsPerKg: 150,
    color: "bg-emerald-100/50 text-emerald-800 border-emerald-300"
  },
  SPECIAL_WASTE: {
    label: "Minyak Jelantah & E-Waste",
    icon: "🔋",
    desc: "Minyak goreng bekas, baterai, bohlam, casing HP",
    pointsPerKg: 250,
    color: "bg-emerald-900/10 text-emerald-900 border-emerald-400"
  }
};

export default function WasteLogger({ inventory, onAddWaste, wasteLogs }: WasteLoggerProps) {
  const [selectedCategory, setSelectedCategory] = useState<WasteCategory>("PLASTIC");
  const [weight, setWeight] = useState<number>(500); // 500 grams default
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<{
    detectedCategory: WasteCategory;
    confidence: number;
    estimatedWeight: number;
  } | null>(null);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [showWarningToast, setShowWarningToast] = useState(false);
  const [loggedDetails, setLoggedDetails] = useState<{ weight: number; points: number; category: string } | null>(null);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const calculatePoints = (cat: WasteCategory, wtGrams: number) => {
    const pointsPerGram = CATEGORY_DETAILS[cat].pointsPerKg / 1000;
    return Math.round(wtGrams * pointsPerGram);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const processMockFile = (file: File) => {
    setIsAnalyzing(true);
    setAiAnalysisResult(null);
    
    // Create image preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Simulate AI Scan
    setTimeout(() => {
      setIsAnalyzing(false);
      // Auto-detect dynamic category based on file name or random
      const categories: WasteCategory[] = ["PLASTIC", "PAPER", "ORGANIC", "METAL_GLASS", "SPECIAL_WASTE"];
      const detected = categories[Math.floor(Math.random() * categories.length)];
      
      const randomWeight = Math.round((Math.random() * 1200 + 150) / 50) * 50; // Between 150g and 1350g, rounded to 50g
      
      setSelectedCategory(detected);
      setWeight(randomWeight);

      setAiAnalysisResult({
        detectedCategory: detected,
        confidence: Math.round(85 + Math.random() * 14), // 85% to 99%
        estimatedWeight: randomWeight
      });
    }, 1800);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processMockFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processMockFile(e.target.files[0]);
    }
  };

  const handleCustomUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleResetImage = () => {
    setPreviewImage(null);
    setAiAnalysisResult(null);
  };

  const handleLogWaste = () => {
    if (!previewImage) {
      setShowWarningToast(true);
      setTimeout(() => {
        setShowWarningToast(false);
      }, 4000);
      return;
    }
    const finalPoints = calculatePoints(selectedCategory, weight);
    onAddWaste(selectedCategory, weight, finalPoints, previewImage || undefined);
    
    setLoggedDetails({
      weight: weight,
      points: finalPoints,
      category: CATEGORY_DETAILS[selectedCategory].label
    });
    
    setShowSuccessToast(true);
    handleResetImage();
    
    setTimeout(() => {
      setShowSuccessToast(false);
      setLoggedDetails(null);
    }, 3500);
  };

  return (
    <div className="space-y-6" id="waste-logger-panel">
      {/* Toast Notification */}
      <AnimatePresence>
        {showSuccessToast && loggedDetails && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed top-24 left-12 right-12 md:left-auto md:right-6 md:w-96 bg-white border-4 border-[#10B981] rounded-[32px] shadow-2xl p-5 flex items-start gap-4.5 z-50 pointer-events-none"
            id="toast-waste-success"
          >
            <div className="bg-[#ECFDF5] p-2.5 rounded-2xl text-[#10B981] border border-[#D1FAE5]">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-extrabold text-[#1A3C34]">Sampah Berhasil Dicatat!</h4>
              <p className="text-xs text-[#1A3C34]/90 mt-1 leading-relaxed">
                Kamu menambahkan <strong className="text-[#10B981] font-black">{loggedDetails.weight}g {loggedDetails.category}</strong> ke inventori rumah tangga.
              </p>
              <div className="mt-2.5 flex items-center gap-1.5 text-[11px] font-black text-[#10B981] bg-[#ECFDF5] px-3 py-1 rounded-full w-fit border border-[#D1FAE5]">
                <Sparkles className="w-3.5 h-3.5" /> +{loggedDetails.points} Eco-Tokens diperoleh!
              </div>
            </div>
          </motion.div>
        )}

        {showWarningToast && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed top-24 left-12 right-12 md:left-auto md:right-6 md:w-96 bg-white border-4 border-rose-500 rounded-[32px] shadow-2xl p-5 flex items-start gap-4.5 z-50 pointer-events-none"
            id="toast-waste-warning"
          >
            <div className="bg-rose-50 p-2.5 rounded-2xl text-rose-500 border border-rose-200">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-extrabold text-[#1A3C34]">Gambar Sampah Diperlukan!</h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Harap unggah atau seret bukti foto sampah nyata Anda terlebih dahulu sebelum melakukan pencatatan dan klaim token.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Image scan and Category pick */}
        <div className="lg:col-span-7 bg-white rounded-[40px] p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] space-y-6">
          <div>
            <h3 className="text-xl font-black text-[#1A3C34] tracking-tight flex items-center gap-2">
              <Camera className="text-[#10B981] w-5.5 h-5.5" />
              Pindai Bukti Sampah Nyata
            </h3>
            <p className="text-xs text-[#065F46] mt-1 font-medium">
              Fasilitasi interaksi sosial dengan mengunggah foto sampah nyata yang terkumpul di rumahmu untuk di-barter atau diolah.
            </p>
          </div>

          {/* Upload Area */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={previewImage ? undefined : handleCustomUploadClick}
            className={`border-4 border-dashed rounded-[32px] p-8 text-center transition-all cursor-pointer relative ${
              isDragging
                ? "border-[#10B981] bg-[#F0F7F0]"
                : previewImage
                ? "border-[#E2F0E2] bg-[#F4F9F4]"
                : "border-[#E2F0E2] hover:border-[#10B981] hover:bg-[#F0F7F0]/40"
            }`}
            id="waste-upload-zone"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />

            {!previewImage && !isAnalyzing ? (
              <div className="space-y-4 py-6">
                <div className="w-14 h-14 bg-[#F0F7F0] text-[#10B981] rounded-2xl flex items-center justify-center mx-auto shadow-inner border border-[#D1FAE5]">
                  <Upload className="w-6 h-6" />
                </div>
                <div className="space-y-1.5">
                  <p className="font-extrabold text-sm text-[#1A3C34]">
                    Geser & letakkan foto sampahmu, atau <span className="text-[#10B981] underline">pilih file</span>
                  </p>
                  <p className="text-xs text-[#065F46] font-medium">Mendukung gambar JPG, PNG dari kamera handphone</p>
                </div>
              </div>
            ) : isAnalyzing ? (
              <div className="space-y-4 py-8">
                <div className="w-12 h-12 border-4 border-[#10B981] border-t-transparent rounded-full animate-spin mx-auto" />
                <div className="space-y-1.5">
                  <p className="font-black text-sm text-[#10B981] animate-pulse">Menghubungkan ke AI Vision...</p>
                  <p className="text-xs text-[#065F46] font-medium">Mendeteksi jenis plastik, kertas, sisa makanan secara otomatis</p>
                </div>
              </div>
            ) : (
              <div className="relative">
                <img
                  src={previewImage}
                  alt="Waste Preview"
                  className="max-h-52 rounded-2xl mx-auto object-cover border-4 border-[#E2F0E2] shadow-md"
                />
                
                {/* AI Detection Overlay */}
                {aiAnalysisResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-4 bg-[#10B981] text-white border-2 border-[#065F46] border-b-4 rounded-[24px] p-4 text-left flex flex-col gap-3.5 shadow-lg"
                  >
                    <div className="flex items-start gap-3">
                      <div className="bg-white/20 p-2 rounded-xl text-white">
                        <Sparkles className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-black text-xs uppercase tracking-wider opacity-90">Pilihan Hasil Prediksi & Koreksi AI</h4>
                        <p className="text-[11px] text-emerald-50 font-medium">
                          Silakan ganti jenis dan geser berat aktual di bawah bila hasil pemindai AI kurang tepat!
                        </p>
                      </div>
                    </div>

                    {/* Interactive Selection of Category Inside AI Box */}
                    <div className="bg-[#065F46]/40 p-3 rounded-xl border border-white/10 space-y-2">
                      <span className="text-[10px] font-black uppercase text-emerald-100 tracking-wider block">Kategori Sampah Sebenarnya:</span>
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5">
                        {Object.entries(CATEGORY_DETAILS).map(([key, details]) => (
                          <button
                            key={key}
                            type="button"
                            onClick={() => {
                              setSelectedCategory(key as WasteCategory);
                              setAiAnalysisResult(prev => prev ? { ...prev, detectedCategory: key as WasteCategory } : null);
                            }}
                            className={`px-1.5 py-1 rounded-xl text-center transition-all border font-black text-[9px] cursor-pointer ${
                              selectedCategory === key
                                ? "bg-white text-[#065F46] border-white shadow-sm"
                                : "bg-transparent text-white/80 border-white/20 hover:border-white/50"
                            }`}
                          >
                            <span className="block text-sm">{details.icon}</span>
                            <span className="block leading-none text-[8px] truncate">{details.label.split(' ')[0]}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Interactive Weight Adjustment Inside AI Box */}
                    <div className="bg-[#065F46]/40 p-3 rounded-xl border border-white/10 space-y-2">
                      <div className="flex justify-between items-baseline">
                        <span className="text-[10px] font-black uppercase text-emerald-100 tracking-wider">Perkiraan Berat Bersih:</span>
                        <span className="text-xs font-black text-white font-mono bg-[#065F46]/80 px-2.5 py-0.5 rounded-lg">
                          {weight >= 1000 ? `${(weight / 1000).toFixed(1)} Kg` : `${weight} gr`}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="50"
                        max="5000"
                        step="50"
                        value={weight}
                        onChange={(e) => {
                          const wt = parseInt(e.target.value);
                          setWeight(wt);
                          setAiAnalysisResult(prev => prev ? { ...prev, estimatedWeight: wt } : null);
                        }}
                        className="w-full h-1.5 bg-emerald-950/40 rounded-lg appearance-none cursor-pointer accent-white"
                      />
                      <div className="flex gap-1">
                        {[100, 500, 1000, 2500, 5000].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => {
                              setWeight(preset);
                              setAiAnalysisResult(prev => prev ? { ...prev, estimatedWeight: preset } : null);
                            }}
                            className={`flex-1 text-[9px] font-extrabold py-1 rounded-lg border transition-all cursor-pointer ${
                              weight === preset
                                ? "bg-white text-[#065F46] border-white"
                                : "bg-transparent text-white/80 border-white/20 hover:border-white/40"
                            }`}
                          >
                            {preset >= 1000 ? `${preset / 1000}Kg` : `${preset}g`}
                          </button>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}

                <button
                  type="button"
                  onClick={handleResetImage}
                  className="absolute -top-3 -right-3 bg-red-500 text-white p-2.5 rounded-full hover:bg-red-600 shadow-md transition-transform hover:scale-105"
                  title="Hapus gambar"
                >
                  <Trash2 className="w-4.5 h-4.5" />
                </button>
              </div>
            )}
          </div>

          {/* Category selection */}
          <div className="space-y-3">
            <label className="text-xs font-black text-[#065F46] uppercase tracking-wider block">Kategori Sampah Secara Manual:</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="waste-category-list">
              {Object.entries(CATEGORY_DETAILS).map(([key, details]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    setSelectedCategory(key as WasteCategory);
                    // Clear search overlay if manual select changes, to prevent confusion
                    setAiAnalysisResult(null);
                  }}
                  className={`flex items-start gap-3 p-3.5 rounded-[24px] border-2 text-left transition-all ${
                    selectedCategory === key
                      ? "border-[#10B981] bg-[#F0F7F0]/60 shadow-sm"
                      : "border-[#E2F0E2] hover:border-[#10B981] hover:bg-[#F4F9F4]"
                  }`}
                >
                  <span className="text-2xl mt-0.5">{details.icon}</span>
                  <div>
                    <span className="font-extrabold text-xs text-[#1A3C34] block leading-tight">{details.label}</span>
                    <span className="text-[11px] text-[#065F46] font-medium block line-clamp-1 mt-1">{details.desc}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Weight measurement & Action */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Weight & Eco Card */}
          <div className="bg-white rounded-[40px] p-8 border-4 border-[#E2F0E2] shadow-xl shadow-[#00000005] flex-1 space-y-6">
            <h3 className="text-lg font-black text-[#1A3C34] flex items-center gap-2">
              <Scale className="text-[#10B981] w-5 h-5" /> Estimasi Kuantitas
            </h3>

            {/* Weight Slider */}
            <div className="space-y-5">
              <div className="flex justify-between items-baseline">
                <span className="text-xs font-bold text-[#065F46] uppercase tracking-wider">Berat Log:</span>
                <span className="text-3xl font-black text-[#10B981] font-mono">
                  {weight >= 1000 ? `${(weight / 1000).toFixed(1)} kg` : `${weight} gr`}
                </span>
              </div>

              <input
                type="range"
                min="50"
                max="5000"
                step="50"
                value={weight}
                onChange={(e) => setWeight(parseInt(e.target.value))}
                className="w-full h-2.5 bg-[#F0F7F0] rounded-lg appearance-none cursor-pointer accent-[#10B981] border border-[#D1FAE5]"
              />

              {/* Weight Presets */}
              <div className="flex justify-between gap-2">
                {[100, 500, 1000, 2500, 5000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setWeight(preset)}
                    className={`flex-1 text-[11px] py-2 font-black rounded-xl border-2 transition-all ${
                      weight === preset
                        ? "bg-[#10B981] border-[#065F46] border-b-4 text-white"
                        : "bg-[#F0F7F0] border-[#E2F0E2] text-[#065F46] hover:bg-[#F4F9F4]"
                    }`}
                  >
                    {preset >= 1000 ? `${preset / 1000}Kg` : `${preset}g`}
                  </button>
                ))}
              </div>
            </div>

            {/* Calculations widget */}
            <div className="bg-[#F0F7F0] rounded-[24px] p-5 border-2 border-[#D1FAE5] space-y-3 shadow-inner">
              <div className="flex justify-between text-xs text-[#065F46] font-bold border-b-2 border-[#D1FAE5]/60 pb-2.5">
                <span>Nilai Tukar Barter:</span>
                <span className="font-extrabold text-[#1A3C34]">{CATEGORY_DETAILS[selectedCategory].pointsPerKg} Token/Kg</span>
              </div>
              <div className="flex justify-between items-center text-sm font-bold">
                <span className="text-[#065F46]">Estimasi Token Diperoleh:</span>
                <span className="font-black text-[#10B981] flex items-center gap-1.5 font-mono text-lg">
                  <Sparkles className="w-5 h-5 fill-[#ECFDF5]" />
                  +{calculatePoints(selectedCategory, weight)}
                </span>
              </div>
            </div>

            {/* Safe guidelines */}
            <div className="bg-[#FFFBEB] rounded-2xl p-4 border-2 border-[#FEF3C7] flex gap-2.5 text-xs text-amber-955 leading-relaxed">
              <Info className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
              <p className="font-medium">
                <strong className="text-amber-900">Aturan Kebersihan:</strong> Pastikan sampah telah dibilas dan dikeringkan di rumah Anda sebelum melakukan barter dengan tetangga demi kenyamanan lingkungan sosial.
              </p>
            </div>

            <button
              type="button"
              disabled={isAnalyzing}
              onClick={handleLogWaste}
              className={`w-full py-4 px-6 font-black rounded-2xl transition-all flex items-center justify-center gap-2 uppercase text-xs tracking-wider border-b-4 ${
                isAnalyzing
                  ? "bg-slate-300 border-slate-400 text-slate-500 cursor-not-allowed opacity-75"
                  : !previewImage
                  ? "bg-amber-50 hover:bg-amber-100/80 text-amber-800 border-amber-300 shadow-sm cursor-pointer"
                  : "bg-[#10B981] hover:bg-[#059669] text-white border-[#065F46] shadow-lg shadow-[#10b98133] cursor-pointer"
              }`}
            >
              <Plus className="w-5 h-5 stroke-[3px]" /> 
              {!previewImage ? "Catat Sampah & Klaim Token" : isAnalyzing ? "Sedang Menganalisis..." : "Catat Sampah & Klaim Token"}
            </button>
          </div>

          {/* Local Inventory Card */}
          <div 
            onClick={() => setIsHistoryOpen(true)}
            className="group cursor-pointer hover:scale-[1.01] active:scale-[0.99] transition-all bg-[#065F46] hover:bg-[#045c41] text-[#ECFDF5] rounded-[40px] p-8 shadow-xl border-4 border-[#047857] hover:border-[#10B981]/50 space-y-5 relative overflow-hidden"
          >
            {/* Background glowing aura */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#10B981]/15 rounded-full blur-2xl group-hover:bg-[#10B981]/25 transition-colors" />

            <div className="flex justify-between items-start relative z-10">
              <div>
                <h4 className="font-black text-white tracking-tight text-xs uppercase opacity-95 flex items-center gap-1.5">
                  Gudang Penyimpanan Rumah Tangga 🏢
                </h4>
                <p className="text-[11px] font-medium opacity-85 mt-1">Sediaan sampah nyata siap barter dengan tetangga</p>
              </div>
              <span className="bg-[#10B981] text-white border border-[#047857] text-[10px] font-black px-3 py-1 rounded-xl uppercase tracking-wider animate-pulse whitespace-nowrap">
                Lihat Riwayat 📜
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs font-mono relative z-10">
              <div className="bg-[#046A4E] p-3 rounded-2xl flex justify-between items-center border border-[#047857] group-hover:bg-[#035942] transition-colors">
                <span className="opacity-90 font-sans font-bold">🥤 Plastik:</span>
                <span className="font-black text-white">{(inventory.PLASTIC / 1000).toFixed(1)} Kg</span>
              </div>
              <div className="bg-[#046A4E] p-3 rounded-2xl flex justify-between items-center border border-[#047857] group-hover:bg-[#035942] transition-colors">
                <span className="opacity-90 font-sans font-bold">📦 Kertas:</span>
                <span className="font-black text-white">{(inventory.PAPER / 1000).toFixed(1)} Kg</span>
              </div>
              <div className="bg-[#046A4E] p-3 rounded-2xl flex justify-between items-center border border-[#047857] group-hover:bg-[#035942] transition-colors">
                <span className="opacity-90 font-sans font-bold">🍎 Organik:</span>
                <span className="font-black text-white">{(inventory.ORGANIC / 1000).toFixed(1)} Kg</span>
              </div>
              <div className="bg-[#046A4E] p-3 rounded-2xl flex justify-between items-center border border-[#047857] group-hover:bg-[#035942] transition-colors">
                <span className="opacity-90 font-sans font-bold">🥫 Logam/Kaca:</span>
                <span className="font-black text-white">{(inventory.METAL_GLASS / 1000).toFixed(1)} Kg</span>
              </div>
              <div className="col-span-2 bg-[#046A4E] p-3 rounded-2xl flex justify-between items-center border border-[#047857] group-hover:bg-[#035942] transition-colors">
                <span className="opacity-90 font-sans font-bold">🔋 Jelantah/Minyak/E-Waste:</span>
                <span className="font-black text-white">{(inventory.SPECIAL_WASTE / 1000).toFixed(1)} Kg</span>
              </div>
            </div>

            <div className="pt-2 border-t border-[#047857] flex items-center justify-center gap-1.5 text-[10px] font-black uppercase text-emerald-300 tracking-wider relative z-10">
              <span>🔔 KLIK DI SINI UNTUK LIHAT RIWAYAT CATATAN & STATUS</span>
            </div>
          </div>
        </div>
      </div>

      {/* History Log Modal (AnimatePresence) */}
      <AnimatePresence>
        {isHistoryOpen && (
          <div className="fixed inset-0 z-50 overflow-y-auto" id="gudang-history-modal">
            <div className="flex min-h-screen items-center justify-center p-4 text-center">
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsHistoryOpen(false)}
                className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
              />

              {/* Modal box */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative transform overflow-hidden rounded-[36px] bg-white border-4 border-[#E2F0E2] text-left shadow-2xl transition-all w-full max-w-2xl max-h-[85vh] flex flex-col z-10"
              >
                {/* Header */}
                <div className="bg-[#F4F9F4] px-6 py-5 border-b-2 border-[#E2F0E2] flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-black text-[#1A3C34] tracking-tight">📜 Riwayat Catatan Penyimpanan</h3>
                    <p className="text-xs text-[#065F46] font-bold uppercase tracking-wider mt-0.5">Semua data sampah tersimpan & status olah</p>
                  </div>
                  <button
                    onClick={() => setIsHistoryOpen(false)}
                    className="p-2 bg-white hover:bg-red-50 text-[#1A3C34] hover:text-red-500 rounded-2xl border-2 border-[#E2F0E2] hover:border-red-200 transition-all cursor-pointer font-bold text-xs"
                    title="Tutup"
                  >
                    ✖
                  </button>
                </div>

                {/* Body list */}
                <div className="p-6 overflow-y-auto space-y-3.5 flex-1 max-h-[480px]">
                  {wasteLogs && wasteLogs.length > 0 ? (
                    wasteLogs.map((log) => {
                      const details = CATEGORY_DETAILS[log.category];
                      const isExpanded = expandedLogId === log.id;
                      
                      // Custom Environmental Lore Map for detailed inspection
                      const loreMap = {
                        PLASTIC: {
                          title: "Aksi Nyata Anti-Plastik 🌊",
                          desc: "Mengamankan ekosistem dari pencemaran mikroplastik. Botol mineral premium ini dilarang keras dibakar! Sangat cocok ditukarkan kepada Pakar Cabai Bu Retno sebagai wadah semai hidroponik, atau Dek Susi kumpulkan ke Bank Sampah RT.",
                          impact: "Mereduksi Emisi Gas Karbon s/d ~1.5 Kg CO₂ equivalen",
                          tip: "💡 Barter ke Bu Retno atau Dek Susi"
                        },
                        PAPER: {
                          title: "Konservasi Serat Selulosa 🌳",
                          desc: "Kardus keras dan kertas sisa ini sangat bernilai tinggi. Kak Agus menggunakannya kembali sebagai bahan mentah merakit kotak tisu anyaman tebal bernilai ekonomi tinggi.",
                          impact: "Menyelamatkan sediaan serat selulosa kertas RT",
                          tip: "💡 Barter ke Kak Agus"
                        },
                        ORGANIC: {
                          title: "Pemulihan Karbon & Kompos Tanah 🪱",
                          desc: "Sisa dapur basah sayuran & buah ini kaya nitrogen aktif! Dapat dijadikan bubur maggot atau dimasukkan ke tong komposter pupuk cacing Bu Retno.",
                          impact: "Mencegah pembusukan anaerobik pelepas gas metana",
                          tip: "💡 Barter ke Bu Retno"
                        },
                        METAL_GLASS: {
                          title: "Sirkularitas Logam & Beling Alumunium 💎",
                          desc: "Kaleng alumunium bekas minuman & kaca marjan dapat didaur ulang selamanya! Sangat dianjurkan dibarter dengan Kak Agus atau Dek Susi demi mengurangi polusi.",
                          impact: "Menghemat energi manufaktur peleburan logam baru s/d 95%",
                          tip: "💡 Barter ke Kak Agus atau Dek Susi"
                        },
                        SPECIAL_WASTE: {
                          title: "Perlindungan Sanitasi Air Tanah RT 🛢️",
                          desc: "Minyak goreng bekas jelantah membahayakan pipa got! Pak Budi menyaringnya untuk anyaman lilin RT atau dikumpulkan warga untuk bahan baku biodiesel ramah lingkungan.",
                          impact: "Mengamankan 100 Liter Air Tanah dari toksisitas karsinogenik",
                          tip: "💡 Barter ke Pak Budi"
                        }
                      };
                      
                      const lore = loreMap[log.category] || {
                        title: "Verifikasi Sampah Berkelanjutan 🍃",
                        desc: "Sampah telah dibilas bersih dan dicatat ke dalam server penyimpanan lokal RT untuk diproses bersama-sama menuju misi Eco-Ranger.",
                        impact: "Mencegah penumpukan sampah di TPA umum",
                        tip: "💡 Barter dengan tetangga terdekat Anda"
                      };

                      return (
                        <div 
                          key={log.id}
                          className={`border-4 rounded-[28px] p-4 transition-all flex flex-col gap-3.5 relative overflow-hidden select-none ${
                            isExpanded 
                              ? "bg-[#F4F9F4]/70 border-[#10B981] shadow-md shadow-[#10b98115]" 
                              : "bg-slate-50 hover:bg-[#F4F9F4]/40 border-slate-100 hover:border-[#10B981]/20 cursor-pointer"
                          }`}
                          onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                        >
                          {/* Main Row Information */}
                          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                            <div className="flex items-center gap-3">
                              <div className="text-3xl bg-white p-2.5 rounded-2xl border border-slate-100 shadow-sm shrink-0">
                                {details?.icon || "📦"}
                              </div>
                              <div>
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-lg border uppercase tracking-wider ${
                                    log.category === 'PLASTIC' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                                    log.category === 'PAPER' ? 'bg-amber-100 text-amber-700 border-amber-200' :
                                    log.category === 'ORGANIC' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                                    log.category === 'METAL_GLASS' ? 'bg-purple-100 text-purple-700 border-purple-200' :
                                    'bg-red-100 text-red-700 border-red-200'
                                  }`}>
                                    {details?.label || log.category}
                                  </span>
                                  <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                                    <Clock className="w-3 h-3" /> {log.timestamp}
                                  </span>
                                </div>
                                <p className="text-sm font-black text-[#1A3C34] mt-1 flex items-center gap-1.5">
                                  <span>Jumlah: {log.weightGrams >= 1000 ? `${(log.weightGrams / 1000).toFixed(1)} Kg` : `${log.weightGrams} gr`}</span>
                                  {log.photoUrl && <span className="text-[10px] bg-emerald-100 text-[#065F46] font-extrabold px-1.5 py-0.5 rounded-md">📸 Ada Foto</span>}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center justify-between md:justify-end gap-4 border-t md:border-t-0 pt-2.5 md:pt-0 border-dashed border-slate-200">
                              <div className="text-left md:text-right">
                                <span className="text-[9px] font-black text-slate-400 uppercase block tracking-wider">Klaim Eco-Tokens</span>
                                <span className="text-xs font-black text-[#10B981] font-mono whitespace-nowrap">
                                  {log.points > 0 ? `+${log.points} Token` : "0 Token (Simpan)"}
                                </span>
                              </div>
                              
                              <div className="text-right flex items-center gap-2">
                                <span className={`inline-block text-[10px] font-black px-3 py-1 rounded-xl uppercase tracking-wider border ${
                                  log.status === 'Tersimpan' 
                                    ? 'bg-blue-50 text-blue-800 border-blue-200' 
                                    : log.status === 'Diolah' 
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                                    : 'bg-amber-50 text-amber-800 border-amber-200'
                                }`}>
                                  {log.status === 'Tersimpan' ? '📥 Tersimpan' : log.status === 'Diolah' ? '♻️ Diolah RT' : log.status === 'Disetorkan' ? '🏦 Disetor' : '🤝 Dibarter'}
                                </span>
                                <span className="text-slate-400 text-xs font-bold transition-transform group-hover/item:translate-x-0.5">
                                  {isExpanded ? "▲" : "▼"}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Expanded Detail Panel */}
                          <AnimatePresence>
                            {isExpanded && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.2 }}
                                className="border-t-2 border-dashed border-slate-200 pt-3.5 mt-1 space-y-3 relative z-10"
                                onClick={(e) => e.stopPropagation()} // Prevent collapse when clicking details
                              >
                                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                                  {/* Left Thumbnail View */}
                                  <div className="md:col-span-4 flex flex-col items-center justify-center bg-white border border-slate-200/60 p-2.5 rounded-2xl shadow-sm">
                                    {log.photoUrl ? (
                                      <div className="relative group/photo w-full aspect-video md:aspect-square max-h-[140px] rounded-xl overflow-hidden border border-slate-100 flex items-center justify-center bg-slate-50">
                                        <img 
                                          src={log.photoUrl} 
                                          alt="Bukti Foto Aktivitas" 
                                          className="w-full h-full object-cover transition-transform duration-300 group-hover/photo:scale-105"
                                          referrerPolicy="no-referrer"
                                        />
                                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/photo:opacity-100 transition-opacity flex items-center justify-center p-2 text-center text-[10px] text-white font-black uppercase">
                                          Sertifikat Bukti Fisik
                                        </div>
                                      </div>
                                    ) : (
                                      <div className="w-full aspect-video md:aspect-square max-h-[140px] rounded-xl bg-slate-100/80 flex flex-col items-center justify-center text-center p-3 gap-1.5 border border-slate-200/60">
                                        <span className="text-2xl">📸</span>
                                        <p className="text-[10px] font-black text-[#1A3C34] uppercase">Gambar Default Pelaporan</p>
                                        <p className="text-[8px] text-slate-500 font-medium">Data diinput secara manual oleh warganet</p>
                                      </div>
                                    )}
                                    <div className="text-[9px] font-mono text-slate-400 font-black mt-2 text-center select-all truncate w-full px-1">
                                      ID: #HIJAU-{log.id.replace('log-', '').substring(0, 8).toUpperCase()}
                                    </div>
                                  </div>

                                  {/* Right Text Fields */}
                                  <div className="md:col-span-8 flex flex-col justify-between space-y-2.5">
                                    <div>
                                      <h5 className="font-extrabold text-xs text-[#1A3C34] flex items-center gap-1">
                                        <span>{lore.title}</span>
                                      </h5>
                                      <p className="text-[11px] text-[#065F46] mt-1 font-medium leading-relaxed">
                                        {lore.desc}
                                      </p>
                                    </div>

                                    <div className="bg-[#ECFDF5] p-2.5 border border-[#D1FAE5] rounded-xl space-y-1.5">
                                      <p className="text-[10px] text-[#065F46] font-bold flex items-center gap-1">
                                        <span className="text-xs">🍀</span> <strong>Dampak Hijau:</strong> {lore.impact}
                                      </p>
                                      <p className="text-[10px] text-emerald-800 font-extrabold">
                                        {lore.tip}
                                      </p>
                                    </div>

                                    <div className="flex flex-wrap gap-2 text-[9px] text-[#1A3C34]/80 font-black uppercase tracking-wider bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
                                      <span>✅ VALIDASI: OTOMATIS PEMINDAI AI KELURAHAN HIJAU</span>
                                      <span className="text-slate-300">|</span>
                                      <span>📍 LOKASI AKTUAL: BUBUTAN, SURABAYA</span>
                                    </div>
                                  </div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>

                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-12 space-y-3">
                      <div className="text-5xl">📭</div>
                      <h4 className="font-black text-[#1A3C34] text-sm">Gudang Kosong Melompong</h4>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto">
                        Anda belum pernah mencatat aktivitas sampah nyata. Silakan unggah foto sampah pertama Anda di sebelah kiri untuk melihat riwayat aktivitas ini!
                      </p>
                    </div>
                  )}
                </div>

                {/* Footer and summary stats info */}
                <div className="bg-slate-50 px-6 py-4 border-t-2 border-[#E2F0E2] flex flex-col sm:flex-row justify-between items-center gap-3">
                  <div className="text-xs font-medium text-slate-500 text-left">
                    💡 Total catatan tersimpan di perangkat lokal.
                  </div>
                  <button
                    onClick={() => setIsHistoryOpen(false)}
                    className="w-full sm:w-auto px-5 py-2.5 bg-[#10B981] hover:bg-[#059669] text-white border-b-4 border-[#065F46] text-xs font-black rounded-xl transition-all cursor-pointer uppercase tracking-wider"
                  >
                    Selesai & Tutup
                  </button>
                </div>
              </motion.div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
